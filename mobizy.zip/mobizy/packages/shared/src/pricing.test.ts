import { test } from 'node:test';
import assert from 'node:assert/strict';
import { calculatePricing, checkVoucher, type VoucherRule } from './pricing.ts';

const base: VoucherRule = {
  code: 'X', discount_type: 'percentage', discount_value: 10, min_purchase: 0, max_discount: null,
  usage_limit: null, used_count: 0, is_active: true, valid_from: null, valid_until: null,
};

test('no voucher: tax on subtotal', () => {
  const r = calculatePricing({ lines: [{ unitPrice: 10000, quantity: 3 }], taxRate: 0.11 });
  assert.deepEqual(r, { subtotal: 30000, discountAmount: 0, taxableAmount: 30000, taxAmount: 3300, total: 33300, itemCount: 3 });
});

test('percentage is capped by max_discount', () => {
  const r = calculatePricing({ lines: [{ unitPrice: 100000, quantity: 1 }], taxRate: 0, voucher: { ...base, discount_value: 50, max_discount: 20000 } });
  assert.equal(r.discountAmount, 20000);
  assert.equal(r.total, 80000);
});

test('fixed discount never exceeds subtotal', () => {
  const r = calculatePricing({ lines: [{ unitPrice: 5000, quantity: 1 }], taxRate: 0.1, voucher: { ...base, discount_type: 'fixed', discount_value: 9000 } });
  assert.equal(r.discountAmount, 5000);
  assert.equal(r.total, 0);
});

test('bogo frees the cheapest unit', () => {
  const r = calculatePricing({ lines: [{ unitPrice: 20000, quantity: 1 }, { unitPrice: 8000, quantity: 2 }], taxRate: 0, voucher: { ...base, discount_type: 'bogo', discount_value: 0 } });
  assert.equal(r.discountAmount, 8000);
});

test('voucher checks', () => {
  const ctx = { subtotal: 1000, unitCount: 1, now: new Date('2026-10-24') };
  assert.equal(checkVoucher({ ...base, is_active: false }, ctx).ok, false);
  assert.equal(checkVoucher({ ...base, valid_until: '2026-01-01' }, ctx).ok, false);
  assert.equal(checkVoucher({ ...base, usage_limit: 5, used_count: 5 }, ctx).ok, false);
  assert.equal(checkVoucher({ ...base, min_purchase: 5000 }, ctx).ok, false);
  assert.equal(checkVoucher({ ...base, discount_type: 'bogo' }, ctx).ok, false);
  assert.equal(checkVoucher(base, ctx).ok, true);
});
