/**
 * Price + discount calculation. Used by the UI to show a live total and by the
 * API as the single source of truth when an order is saved. The API never trusts
 * totals sent by the browser; it recomputes them with this function.
 *
 * All amounts are whole currency units (IDR has no minor unit), so results are
 * rounded with Math.round.
 */

export type DiscountType = 'percentage' | 'fixed' | 'bogo';

export interface VoucherRule {
  code: string;
  discount_type: DiscountType;
  discount_value: number;
  min_purchase: number;
  max_discount: number | null;
  usage_limit: number | null;
  used_count: number;
  is_active: boolean;
  valid_from: string | Date | null;
  valid_until: string | Date | null;
}

export interface PricingLine {
  unitPrice: number;
  quantity: number;
}

export interface PricingResult {
  subtotal: number;
  discountAmount: number;
  taxableAmount: number;
  taxAmount: number;
  total: number;
  itemCount: number;
}

export type VoucherCheck =
  | { ok: true }
  | { ok: false; reason: 'inactive' | 'not_started' | 'expired' | 'exhausted' | 'min_purchase' | 'bogo_items'; message: string };

const rp = (n: number) => `Rp ${Math.round(n).toLocaleString('id-ID')}`;

export function sumSubtotal(lines: PricingLine[]): number {
  return lines.reduce((s, l) => s + l.unitPrice * l.quantity, 0);
}

export function countUnits(lines: PricingLine[]): number {
  return lines.reduce((s, l) => s + l.quantity, 0);
}

export function checkVoucher(
  v: VoucherRule,
  ctx: { subtotal: number; unitCount: number; now?: Date },
): VoucherCheck {
  const now = ctx.now ?? new Date();
  if (!v.is_active) return { ok: false, reason: 'inactive', message: 'Voucher tidak aktif' };
  if (v.valid_from && new Date(v.valid_from) > now)
    return { ok: false, reason: 'not_started', message: 'Voucher belum berlaku' };
  if (v.valid_until && new Date(v.valid_until) < now)
    return { ok: false, reason: 'expired', message: 'Voucher sudah kedaluwarsa' };
  if (v.usage_limit !== null && v.used_count >= v.usage_limit)
    return { ok: false, reason: 'exhausted', message: 'Batas penggunaan voucher sudah habis' };
  if (ctx.subtotal < v.min_purchase)
    return { ok: false, reason: 'min_purchase', message: `Min. belanja ${rp(v.min_purchase)}` };
  if (v.discount_type === 'bogo' && ctx.unitCount < 2)
    return { ok: false, reason: 'bogo_items', message: 'Voucher Beli 1 Gratis 1 butuh minimal 2 item di keranjang' };
  return { ok: true };
}

export function computeDiscount(v: VoucherRule | null, lines: PricingLine[]): number {
  if (!v) return 0;
  const subtotal = sumSubtotal(lines);
  let raw = 0;
  if (v.discount_type === 'bogo') {
    // cheapest single unit is free
    const prices = lines.flatMap((l) => Array.from({ length: l.quantity }, () => l.unitPrice));
    if (prices.length >= 2) raw = Math.min(...prices);
  } else if (v.discount_type === 'percentage') {
    raw = subtotal * (v.discount_value / 100);
    if (v.max_discount && raw > v.max_discount) raw = v.max_discount;
  } else {
    raw = v.discount_value;
  }
  return Math.min(Math.round(raw), subtotal);
}

export function calculatePricing(input: {
  lines: PricingLine[];
  taxRate: number;
  voucher?: VoucherRule | null;
}): PricingResult {
  const subtotal = sumSubtotal(input.lines);
  const discountAmount = computeDiscount(input.voucher ?? null, input.lines);
  const taxableAmount = Math.max(0, subtotal - discountAmount);
  const taxAmount = Math.round(taxableAmount * input.taxRate);
  return {
    subtotal,
    discountAmount,
    taxableAmount,
    taxAmount,
    total: taxableAmount + taxAmount,
    itemCount: countUnits(input.lines),
  };
}
