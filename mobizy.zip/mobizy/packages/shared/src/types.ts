import type { UserRole } from './roles.ts';
import type { DiscountType } from './pricing.ts';

// JSON shapes returned by the API. Field names are snake_case on purpose:
// they mirror the database tables (snake_case columns).

export interface SessionUser {
  id: string;
  email: string;
  display_name: string;
  role: UserRole;
  store_id: string;
  store_name: string;
}

export interface Category { id: string; name: string; icon: string; sort_order: number; created_at: string }

export interface Product {
  id: string; name: string; description: string; price: number; cost: number; stock: number;
  category_id: string | null; barcode: string; image_url: string; is_active: boolean;
  created_at: string; updated_at: string;
}

export interface Voucher {
  id: string; code: string; name: string; description: string; discount_type: DiscountType;
  discount_value: number; min_purchase: number; max_discount: number | null; usage_limit: number | null;
  used_count: number; is_active: boolean; valid_from: string; valid_until: string | null; created_at: string;
}

export interface Order {
  id: string; order_number: number; subtotal: number; tax_rate: number; tax_amount: number;
  discount: number; discount_amount: number; total: number; payment_method: string;
  amount_paid: number; change_due: number; status: string; customer_name: string; notes: string;
  item_count: number; voucher_id: string | null; correction_type: string; correction_reason: string;
  corrected_order_id: string | null; scheduled_time: string | null; created_at: string;
}

export interface OrderItem {
  id: string; order_id: string; product_id: string | null; product_name: string;
  unit_price: number; quantity: number; subtotal: number; created_at: string;
}

export interface StoreSettings {
  id: string; slug: string; store_name: string; currency: string; currency_symbol: string;
  tax_rate: number; receipt_footer: string; qris_url: string | null; created_at: string;
}

export interface Comment { id: string; product_id: string | null; author_name: string; content: string; rating: number; created_at: string }

export interface Expense { id: string; category: string; description: string; amount: number; expense_date: string; created_at: string }

export interface StaffUser { id: string; email: string; display_name: string; role: UserRole; is_active: boolean; created_at: string }

export interface ApiErrorBody { error: { code: string; message: string; details?: unknown } }
