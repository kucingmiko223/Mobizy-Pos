import { z } from 'zod';

const money = z.number().finite().min(0).max(1_000_000_000_000);
const text = (max: number) => z.string().trim().max(max);

export const passwordSchema = z.string().min(10, 'Password minimal 10 karakter').max(200);

export const registerStoreSchema = z.object({
  store_name: text(120).min(2),
  slug: z.string().trim().toLowerCase().regex(/^[a-z0-9](?:[a-z0-9-]{1,38})[a-z0-9]$/, 'Slug 3-40 karakter: huruf kecil, angka, strip'),
  display_name: text(80).min(1),
  email: z.string().trim().toLowerCase().email().max(200),
  password: passwordSchema,
});

export const registerCustomerSchema = z.object({
  store_slug: z.string().trim().toLowerCase().min(3).max(40),
  display_name: text(80).min(1),
  email: z.string().trim().toLowerCase().email().max(200),
  password: passwordSchema,
});

export const loginSchema = z.object({
  email: z.string().trim().toLowerCase().email().max(200),
  password: z.string().min(1).max(200),
});

export const createStaffSchema = z.object({
  display_name: text(80).min(1),
  email: z.string().trim().toLowerCase().email().max(200),
  password: passwordSchema,
  role: z.enum(['admin', 'cashier']),
});

export const updateStaffSchema = z.object({
  display_name: text(80).min(1).optional(),
  role: z.enum(['admin', 'cashier']).optional(),
  is_active: z.boolean().optional(),
  password: passwordSchema.optional(),
});

export const categorySchema = z.object({
  name: text(80).min(1),
  icon: text(40).default('Tag'),
  sort_order: z.number().int().min(0).max(10000).default(0),
});

export const productSchema = z.object({
  name: text(160).min(1),
  description: text(2000).default(''),
  price: money,
  cost: money.default(0),
  stock: z.number().int().min(0).max(10_000_000),
  category_id: z.string().uuid().nullable().default(null),
  barcode: text(64).default(''),
  image_url: text(1000).default(''),
  is_active: z.boolean().default(true),
});

export const voucherBaseSchema = z.object({
    code: z.string().trim().toUpperCase().regex(/^[A-Z0-9_-]{3,32}$/, 'Kode 3-32 karakter: huruf, angka, _ atau -'),
    name: text(120).min(1),
    description: text(500).default(''),
    discount_type: z.enum(['percentage', 'fixed', 'bogo']),
    discount_value: money.default(0),
    min_purchase: money.default(0),
    max_discount: money.nullable().default(null),
    usage_limit: z.number().int().min(1).nullable().default(null),
    is_active: z.boolean().default(true),
    valid_from: z.string().datetime({ offset: true }).optional(),
    valid_until: z.string().datetime({ offset: true }).nullable().default(null),
});

export const voucherSchema = voucherBaseSchema.refine(
  (v) => v.discount_type !== 'percentage' || v.discount_value <= 100,
  { message: 'Persentase maksimal 100', path: ['discount_value'] },
);

export const PAYMENT_METHODS = ['cash', 'card', 'qris', 'transfer'] as const;

export const checkoutSchema = z.object({
  items: z.array(z.object({ product_id: z.string().uuid(), quantity: z.number().int().min(1).max(10000) })).min(1).max(200),
  payment_method: z.enum(PAYMENT_METHODS),
  /** Only used for cash. The server rejects it if it is lower than the real total. */
  amount_paid: money.optional(),
  customer_name: text(120).default(''),
  notes: text(1000).default(''),
  voucher_code: z.string().trim().toUpperCase().max(32).optional(),
  scheduled_time: z.string().datetime({ offset: true }).nullable().optional(),
});

export const validateVoucherSchema = z.object({
  code: z.string().trim().toUpperCase().min(1).max(32),
  items: checkoutSchema.shape.items,
});

export const correctionSchema = z.object({
  type: z.enum(['void', 'refund', 'adjust']),
  reason: text(500).min(1, 'Alasan wajib diisi'),
});

export const storeSettingsSchema = z.object({
  store_name: text(120).min(2).optional(),
  currency: text(8).optional(),
  currency_symbol: text(8).optional(),
  tax_rate: z.number().min(0).max(1).optional(),
  receipt_footer: text(500).optional(),
  qris_url: text(2000).nullable().optional(),
});

export const commentSchema = z.object({
  product_id: z.string().uuid().nullable().default(null),
  content: text(2000).min(1),
  rating: z.number().int().min(1).max(5).default(5),
  author_name: text(80).optional(),
});

export const expenseSchema = z.object({
  category: text(40).min(1),
  description: text(500).default(''),
  amount: money,
  expense_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
});

export type CheckoutInput = z.infer<typeof checkoutSchema>;
export type ProductInput = z.infer<typeof productSchema>;
export type VoucherInput = z.infer<typeof voucherSchema>;
