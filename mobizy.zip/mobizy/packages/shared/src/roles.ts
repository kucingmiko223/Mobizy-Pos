export const ROLES = ['owner', 'admin', 'cashier', 'customer'] as const;
export type UserRole = (typeof ROLES)[number];

/** Roles that work inside the store (see orders, manage stock...). */
export const STAFF_ROLES: readonly UserRole[] = ['owner', 'admin', 'cashier'];
/** Roles that can change catalogue, vouchers, settings, expenses. */
export const MANAGER_ROLES: readonly UserRole[] = ['owner', 'admin'];

export const isStaff = (r: UserRole) => STAFF_ROLES.includes(r);
export const isManager = (r: UserRole) => MANAGER_ROLES.includes(r);
