# API reference

Base path `/api`. JSON in, JSON out. Auth is an HttpOnly cookie (`mobizy_sid`) set by login/register.
Errors: `{ "error": { "code": "insufficient_stock", "message": "...", "details": {...} } }`.

| Method | Path | Roles | Notes |
|---|---|---|---|
| POST | /auth/register | public | Creates store + owner. Disable with `ALLOW_PUBLIC_SIGNUP=false` |
| POST | /auth/register-customer | public | `store_slug` required |
| POST | /auth/login, /auth/logout | public | Login is rate limited |
| GET | /auth/me | any | Current user |
| POST | /auth/change-password | any | Signs out other devices |
| GET/POST/PATCH | /users, /users/:id | owner, admin | Staff accounts; only the owner can create or change admins |
| GET/PATCH | /store | any / owner, admin | Name, currency, tax rate, QRIS, receipt footer |
| GET/POST/PATCH/DELETE | /categories | any / owner, admin | |
| GET/POST/PATCH/DELETE | /products | any / owner, admin | `cost` is hidden from non-managers; `?include_inactive=1` for managers |
| GET/POST/PATCH/DELETE | /vouchers | owner, admin | |
| POST | /vouchers/validate | staff | `{code, items:[{product_id, quantity}]}` |
| GET | /orders, /orders/items, /orders/:id | staff | `from`, `to` (ISO), `status`, `limit` |
| POST | /orders | staff | Checkout. Send product ids + quantities only; totals are computed by the server |
| POST | /orders/:id/correct | staff (void/refund: owner, admin) | `{type: void\|refund\|adjust, reason}`; restocks once |
| GET/POST/DELETE | /comments | any / any / owner, admin | |
| GET/POST/DELETE | /expenses | owner, admin | |
| GET | /health | public | DB ping |

Checkout runs in one transaction: it locks the product rows, checks stock, locks the voucher, recomputes prices, discount,
tax and total with `calculatePricing` from `@mobizy/shared`, decrements stock, takes the next per-store order number and writes
the order and its items. The database also refuses negative stock (`CHECK (stock >= 0)`).
