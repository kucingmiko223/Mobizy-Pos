# Security notes

- Sign-in: scrypt password hashes, random 256-bit session tokens stored only as SHA-256 hashes, HttpOnly + SameSite=Lax cookie (`Secure` in production), sessions revoked on password change or deactivation.
- The browser never talks to the database. There is no public database key.
- Tenant isolation: every table has `store_id`, every query filters on the session's store, and ids sent by the client (category, product, voucher) are checked to belong to that store.
- Money and stock rules run on the server in transactions; the DB has CHECK constraints as a last line.
- Role checks happen on the server for each route. The UI hiding buttons is cosmetic.
- CSRF: SameSite cookies plus an Origin check on state-changing requests.
- Cost price is not sent to cashiers or customers.
- No default or shared passwords: seed and create-store scripts generate random ones and print them once.

## Business rules

- Customers get a read-only menu and can leave reviews. They cannot check out; self-ordering needs its own flow (pending orders, staff confirmation).
- Void and refund are limited to owner/admin (a cashier voiding their own cash sale is the classic till fraud). Relax it in `routes/orders.ts` if you want.
- A void/refund can happen once per order, so stock is restored only once.
- "Buy 1 get 1" needs two units in the cart (2 of the same item counts).
- Voucher usage is not given back when an order is voided.
- Money is rounded to whole currency units (IDR).

## Known limits

In-memory rate limiter, no email verification or password reset, no audit log table, no Postgres RLS.
