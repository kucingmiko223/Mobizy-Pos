// Creates an EMPTY store (no products, no sample data) plus its owner login.
// Use this for a real deployment. Required: STORE_NAME, STORE_SLUG, OWNER_EMAIL, OWNER_NAME.
// OWNER_PASSWORD is optional: if unset a random one is generated and printed once.
import { randomBytes } from 'node:crypto';
import { eq } from 'drizzle-orm';
import { registerStoreSchema } from '@mobizy/shared';
import { db, pg, stores, users } from '../src/db/client.ts';
import { hashPassword } from '../src/lib/password.ts';

const password = process.env.OWNER_PASSWORD || randomBytes(12).toString('base64url');
const parsed = registerStoreSchema.safeParse({
  store_name: process.env.STORE_NAME,
  slug: process.env.STORE_SLUG,
  display_name: process.env.OWNER_NAME,
  email: process.env.OWNER_EMAIL,
  password,
});
if (!parsed.success) {
  console.error('Invalid input. Set STORE_NAME, STORE_SLUG, OWNER_NAME, OWNER_EMAIL (and optionally OWNER_PASSWORD):');
  console.error(parsed.error.flatten().fieldErrors);
  process.exit(1);
}
const input = parsed.data;

const [existing] = await db.select({ id: stores.id }).from(stores).where(eq(stores.slug, input.slug));
if (existing) {
  console.error(`Store "${input.slug}" already exists.`);
  await pg.end();
  process.exit(1);
}

await db.transaction(async (tx) => {
  const [store] = await tx.insert(stores).values({ slug: input.slug, store_name: input.store_name }).returning();
  await tx.insert(users).values({
    store_id: store.id, email: input.email, display_name: input.display_name, role: 'owner',
    password_hash: await hashPassword(input.password),
  });
});

console.log(`\nStore "${input.slug}" created.\n\n  Owner  ${input.email}${process.env.OWNER_PASSWORD ? '' : `   password: ${password}`}\n`);
await pg.end();
