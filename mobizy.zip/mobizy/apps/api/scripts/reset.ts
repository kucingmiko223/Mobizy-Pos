// Wipes EVERYTHING in the database (all schemas' tables in `public`, including _migrations) so the next
// `npm run db:migrate` builds a brand-new empty database. Development only.
// Safety: refuses NODE_ENV=production, and requires RESET_CONFIRM=<database name> so a wrong DATABASE_URL can't wipe the wrong DB.
import postgres from 'postgres';

const url = process.env.DATABASE_URL;
if (!url) throw new Error('DATABASE_URL is required');
if (process.env.NODE_ENV === 'production') {
  console.error('Refusing to reset a production database.');
  process.exit(1);
}
const dbName = new URL(url).pathname.replace(/^\//, '');
if (process.env.RESET_CONFIRM !== dbName) {
  console.error(`This deletes all data in database "${dbName}".\nRe-run with RESET_CONFIRM=${dbName} to continue.`);
  process.exit(1);
}

const sql = postgres(url, { max: 1, onnotice: () => {} });
try {
  await sql.unsafe('DROP SCHEMA public CASCADE; CREATE SCHEMA public;');
  console.log(`Database "${dbName}" is now empty. Run: npm run db:migrate`);
} finally {
  await sql.end();
}
