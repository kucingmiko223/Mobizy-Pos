// Creates a demo store with an owner + cashier login and sample data.
// Passwords are random unless you set SEED_OWNER_PASSWORD. They are printed ONCE here and never stored in plain text.
import { randomBytes } from 'node:crypto';
import { eq } from 'drizzle-orm';
import { categories, db, pg, products, stores, users, vouchers } from '../src/db/client.ts';
import { env } from '../src/env.ts';
import { hashPassword } from '../src/lib/password.ts';

if (env.NODE_ENV === 'production' && process.env.SEED_ALLOW_PRODUCTION !== '1') {
  console.error('Refusing to seed demo data in production. Set SEED_ALLOW_PRODUCTION=1 if you really mean it.');
  process.exit(1);
}

const slug = process.env.SEED_STORE_SLUG ?? 'demo';
const ownerEmail = (process.env.SEED_OWNER_EMAIL ?? 'owner@demo.mobizy.local').toLowerCase();
const cashierEmail = (process.env.SEED_CASHIER_EMAIL ?? 'kasir@demo.mobizy.local').toLowerCase();
const rand = () => randomBytes(12).toString('base64url');
const ownerPw = process.env.SEED_OWNER_PASSWORD || rand();
const cashierPw = rand();

const [existing] = await db.select().from(stores).where(eq(stores.slug, slug));
if (existing) {
  console.log(`Store "${slug}" already exists, nothing to do.`);
  await pg.end();
  process.exit(0);
}

await db.transaction(async (tx) => {
  const [store] = await tx.insert(stores).values({ slug, store_name: 'Toko Demo', tax_rate: 0.11 }).returning();
  await tx.insert(users).values([
    { store_id: store.id, email: ownerEmail, display_name: 'Pemilik Demo', role: 'owner', password_hash: await hashPassword(ownerPw) },
    { store_id: store.id, email: cashierEmail, display_name: 'Kasir Demo', role: 'cashier', password_hash: await hashPassword(cashierPw) },
  ]);
  const cats = await tx.insert(categories).values([
    { store_id: store.id, name: 'Minuman', icon: 'Coffee', sort_order: 1 },
    { store_id: store.id, name: 'Makanan', icon: 'Utensils', sort_order: 2 },
    { store_id: store.id, name: 'Camilan', icon: 'Cookie', sort_order: 3 },
  ]).returning();
  const [drink, food, snack] = cats;
  await tx.insert(products).values([
    { store_id: store.id, name: 'Kopi Susu', price: 18000, cost: 7000, stock: 50, category_id: drink.id },
    { store_id: store.id, name: 'Es Teh Manis', price: 8000, cost: 2000, stock: 80, category_id: drink.id },
    { store_id: store.id, name: 'Nasi Goreng', price: 28000, cost: 12000, stock: 30, category_id: food.id },
    { store_id: store.id, name: 'Mie Ayam', price: 24000, cost: 10000, stock: 30, category_id: food.id },
    { store_id: store.id, name: 'Pisang Goreng', price: 12000, cost: 4000, stock: 40, category_id: snack.id },
    { store_id: store.id, name: 'Kentang Goreng', price: 15000, cost: 5000, stock: 40, category_id: snack.id },
  ]);
  await tx.insert(vouchers).values([
    { store_id: store.id, code: 'HEMAT10', name: 'Diskon 10%', discount_type: 'percentage', discount_value: 10, max_discount: 20000 },
    { store_id: store.id, code: 'POTONG5K', name: 'Potongan Rp 5.000', discount_type: 'fixed', discount_value: 5000, min_purchase: 30000 },
    { store_id: store.id, code: 'BELI1GRATIS1', name: 'Beli 1 Gratis 1', discount_type: 'bogo', discount_value: 0 },
  ]);
});

console.log(`
Demo store created: "${slug}"

  Owner    ${ownerEmail}   password: ${ownerPw}
  Cashier  ${cashierEmail}   password: ${cashierPw}

Save these now; they cannot be shown again. Change them after first login.
`);
await pg.end();
