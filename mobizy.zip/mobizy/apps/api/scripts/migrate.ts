// Applies migrations/*.sql in filename order. Safe to run repeatedly.
import { readdirSync, readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import postgres from 'postgres';

const url = process.env.DATABASE_URL;
if (!url) throw new Error('DATABASE_URL is required');
const dir = join(dirname(fileURLToPath(import.meta.url)), '..', 'migrations');
const sql = postgres(url, { max: 1, onnotice: () => {} });

try {
  await sql`CREATE TABLE IF NOT EXISTS _migrations (name text PRIMARY KEY, applied_at timestamptz NOT NULL DEFAULT now())`;
  const files = readdirSync(dir).filter((f) => f.endsWith('.sql')).sort();
  for (const file of files) {
    await sql.begin(async (tx) => {
      await tx`SELECT pg_advisory_xact_lock(727274)`; // one migrator at a time
      const [done] = await tx`SELECT 1 FROM _migrations WHERE name = ${file}`;
      if (done) return;
      await tx.unsafe(readFileSync(join(dir, file), 'utf8'));
      await tx`INSERT INTO _migrations (name) VALUES (${file})`;
      console.log(`applied ${file}`);
    });
  }
  console.log('migrations up to date');
} finally {
  await sql.end();
}
