import { defineConfig } from 'tsup';

export default defineConfig({
  entry: ['src/index.ts', 'scripts/migrate.ts'],
  format: ['esm'],
  target: 'node20',
  clean: true,
  sourcemap: true,
  // the shared package ships TypeScript source, so bundle it into the server
  noExternal: ['@mobizy/shared'],
});
