import { getConnInfo } from '@hono/node-server/conninfo';
import { createMiddleware } from 'hono/factory';
import type { Context } from 'hono';
import { env } from '../env.ts';
import { HttpError } from '../lib/errors.ts';

export function clientIp(c: Context): string {
  if (env.TRUST_PROXY) {
    const fwd = c.req.header('x-forwarded-for');
    if (fwd) return fwd.split(',')[0].trim();
  }
  try { return getConnInfo(c).remote.address ?? 'unknown'; } catch { return 'unknown'; }
}

/** Fixed-window limiter, in memory. Fine for one instance; use Redis if you run several. */
export function rateLimit(opts: { name: string; windowMs: number; max: number }) {
  const hits = new Map<string, { n: number; reset: number }>();
  setInterval(() => { const now = Date.now(); for (const [k, v] of hits) if (v.reset < now) hits.delete(k); }, 60_000).unref();
  return createMiddleware(async (c, next) => {
    if (env.NODE_ENV === 'test') return next();
    const key = `${opts.name}:${clientIp(c)}`;
    const now = Date.now();
    const cur = hits.get(key);
    if (!cur || cur.reset < now) hits.set(key, { n: 1, reset: now + opts.windowMs });
    else if (++cur.n > opts.max) {
      c.header('Retry-After', String(Math.ceil((cur.reset - now) / 1000)));
      throw new HttpError(429, 'rate_limited', 'Terlalu banyak percobaan, coba lagi nanti');
    }
    await next();
  });
}
