import { createMiddleware } from 'hono/factory';
import { env } from '../env.ts';
import { HttpError } from '../lib/errors.ts';

/**
 * CSRF defence in depth (cookies are already SameSite=Lax): for state-changing
 * requests, a browser-supplied Origin must be this site or an allow-listed one.
 */
export const originCheck = createMiddleware(async (c, next) => {
  if (['GET', 'HEAD', 'OPTIONS'].includes(c.req.method)) return next();
  const origin = c.req.header('origin');
  if (!origin) return next(); // non-browser client (curl, server-to-server)
  let host = '';
  try { host = new URL(origin).host; } catch { throw new HttpError(403, 'bad_origin', 'Origin tidak valid'); }
  const own = (env.TRUST_PROXY && c.req.header('x-forwarded-host')) || c.req.header('host');
  if (origin && (host === own || env.CORS_ORIGINS.includes(origin))) return next();
  throw new HttpError(403, 'bad_origin', 'Origin tidak diizinkan');
});
