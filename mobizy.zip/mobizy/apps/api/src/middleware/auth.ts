import { getCookie } from 'hono/cookie';
import { createMiddleware } from 'hono/factory';
import type { UserRole } from '@mobizy/shared';
import { HttpError } from '../lib/errors.ts';
import { COOKIE, findUserBySession, type AuthUser } from '../lib/session.ts';

export type AppEnv = { Variables: { user: AuthUser } };

export const requireAuth = createMiddleware<AppEnv>(async (c, next) => {
  const token = getCookie(c, COOKIE);
  const user = token ? await findUserBySession(token) : null;
  if (!user) throw new HttpError(401, 'unauthenticated', 'Silakan login terlebih dahulu');
  c.set('user', user);
  await next();
});

export const requireRole = (...roles: readonly UserRole[]) =>
  createMiddleware<AppEnv>(async (c, next) => {
    if (!roles.includes(c.get('user').role)) {
      throw new HttpError(403, 'forbidden', 'Anda tidak punya akses untuk aksi ini');
    }
    await next();
  });
