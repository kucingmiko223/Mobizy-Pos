import { and, eq, ne } from 'drizzle-orm';
import { Hono } from 'hono';
import { MANAGER_ROLES, createStaffSchema, updateStaffSchema } from '@mobizy/shared';
import { db, users } from '../db/client.ts';
import { HttpError } from '../lib/errors.ts';
import { body, idParam } from '../lib/http.ts';
import { hashPassword } from '../lib/password.ts';
import { endSessions } from '../lib/session.ts';
import { requireAuth, requireRole, type AppEnv } from '../middleware/auth.ts';

export const userRoutes = new Hono<AppEnv>();
userRoutes.use(requireAuth, requireRole(...MANAGER_ROLES));

const cols = { id: users.id, email: users.email, display_name: users.display_name, role: users.role, is_active: users.is_active, created_at: users.created_at };

userRoutes.get('/', async (c) => {
  const rows = await db.select(cols).from(users).where(eq(users.store_id, c.get('user').storeId)).orderBy(users.created_at);
  return c.json(rows);
});

userRoutes.post('/', async (c) => {
  const me = c.get('user');
  const input = await body(c, createStaffSchema);
  if (input.role === 'admin' && me.role !== 'owner') throw new HttpError(403, 'forbidden', 'Hanya pemilik yang bisa menambah admin');
  try {
    const [u] = await db.insert(users).values({
      store_id: me.storeId, email: input.email, display_name: input.display_name, role: input.role,
      password_hash: await hashPassword(input.password),
    }).returning(cols);
    return c.json(u, 201);
  } catch (e) {
    if ((e as { code?: string; cause?: { code?: string } })?.code === '23505' || (e as { cause?: { code?: string } })?.cause?.code === '23505')
      throw new HttpError(409, 'email_taken', 'Email sudah terdaftar');
    throw e;
  }
});

userRoutes.patch('/:id', async (c) => {
  const me = c.get('user');
  const id = idParam(c);
  const input = await body(c, updateStaffSchema);
  const [target] = await db.select().from(users).where(and(eq(users.id, id), eq(users.store_id, me.storeId)));
  if (!target) throw new HttpError(404, 'not_found', 'Pengguna tidak ditemukan');
  if (target.role === 'owner') throw new HttpError(403, 'forbidden', 'Akun pemilik tidak bisa diubah di sini');
  if (target.role === 'customer') throw new HttpError(403, 'forbidden', 'Akun pelanggan dikelola pelanggan sendiri');
  if ((target.role === 'admin' || input.role === 'admin') && me.role !== 'owner')
    throw new HttpError(403, 'forbidden', 'Hanya pemilik yang bisa mengubah admin');
  const patch: Partial<typeof users.$inferInsert> = {};
  if (input.display_name !== undefined) patch.display_name = input.display_name;
  if (input.role !== undefined) patch.role = input.role;
  if (input.is_active !== undefined) patch.is_active = input.is_active;
  if (input.password) patch.password_hash = await hashPassword(input.password);
  if (Object.keys(patch).length === 0) return c.json({ ok: true });
  const [u] = await db.update(users).set(patch).where(and(eq(users.id, id), eq(users.store_id, me.storeId), ne(users.role, 'owner'))).returning(cols);
  if (input.is_active === false || input.password) await endSessions(id);
  return c.json(u);
});
