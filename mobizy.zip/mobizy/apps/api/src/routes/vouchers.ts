import { and, desc, eq } from 'drizzle-orm';
import { Hono } from 'hono';
import { MANAGER_ROLES, STAFF_ROLES, checkVoucher, computeDiscount, sumSubtotal, countUnits, validateVoucherSchema, voucherBaseSchema, voucherSchema } from '@mobizy/shared';
import { db, products, vouchers } from '../db/client.ts';
import { HttpError } from '../lib/errors.ts';
import { body, idParam, pub } from '../lib/http.ts';
import { requireAuth, requireRole, type AppEnv } from '../middleware/auth.ts';
import { inArray } from 'drizzle-orm';

export const voucherRoutes = new Hono<AppEnv>();
voucherRoutes.use(requireAuth);

export const toRule = (v: typeof vouchers.$inferSelect) => ({
  code: v.code, discount_type: v.discount_type, discount_value: v.discount_value, min_purchase: v.min_purchase,
  max_discount: v.max_discount, usage_limit: v.usage_limit, used_count: v.used_count, is_active: v.is_active,
  valid_from: v.valid_from, valid_until: v.valid_until,
});

voucherRoutes.get('/', requireRole(...MANAGER_ROLES), async (c) => {
  const rows = await db.select().from(vouchers).where(eq(vouchers.store_id, c.get('user').storeId)).orderBy(desc(vouchers.created_at));
  return c.json(rows.map(pub));
});

/** Cashier asks "does this code work for this cart?". Prices come from the DB, not the browser. */
voucherRoutes.post('/validate', requireRole(...STAFF_ROLES), async (c) => {
  const me = c.get('user');
  const { code, items } = await body(c, validateVoucherSchema);
  const [v] = await db.select().from(vouchers).where(and(eq(vouchers.store_id, me.storeId), eq(vouchers.code, code)));
  if (!v) throw new HttpError(422, 'voucher_not_found', 'Voucher tidak ditemukan');
  const prods = await db.select().from(products).where(and(eq(products.store_id, me.storeId), inArray(products.id, items.map((i) => i.product_id))));
  const byId = new Map(prods.map((p) => [p.id, p]));
  const lines = items.map((i) => ({ unitPrice: byId.get(i.product_id)?.price ?? 0, quantity: i.quantity }));
  const check = checkVoucher(toRule(v), { subtotal: sumSubtotal(lines), unitCount: countUnits(lines) });
  if (!check.ok) throw new HttpError(422, `voucher_${check.reason}`, check.message);
  return c.json({ voucher: pub(v), discount_amount: computeDiscount(toRule(v), lines) });
});

voucherRoutes.post('/', requireRole(...MANAGER_ROLES), async (c) => {
  const input = await body(c, voucherSchema);
  const { valid_from, valid_until, ...rest } = input;
  const [row] = await db.insert(vouchers).values({
    ...rest, store_id: c.get('user').storeId,
    valid_from: valid_from ? new Date(valid_from) : new Date(),
    valid_until: valid_until ? new Date(valid_until) : null,
  }).returning().catch((e) => { throw dupCode(e); });
  return c.json(pub(row), 201);
});

voucherRoutes.patch('/:id', requireRole(...MANAGER_ROLES), async (c) => {
  const input = await body(c, voucherBaseSchema.partial());
  if (input.discount_type === 'percentage' && (input.discount_value ?? 0) > 100) throw new HttpError(422, 'validation_error', 'Persentase maksimal 100');
  const { valid_from, valid_until, ...rest } = input;
  const patch = {
    ...rest,
    ...(valid_from !== undefined ? { valid_from: new Date(valid_from) } : {}),
    ...(valid_until !== undefined ? { valid_until: valid_until ? new Date(valid_until) : null } : {}),
  };
  if (Object.keys(patch).length === 0) throw new HttpError(400, 'empty_patch', 'Tidak ada perubahan');
  const [row] = await db.update(vouchers).set(patch)
    .where(and(eq(vouchers.id, idParam(c)), eq(vouchers.store_id, c.get('user').storeId))).returning()
    .catch((e) => { throw dupCode(e); });
  if (!row) throw new HttpError(404, 'not_found', 'Voucher tidak ditemukan');
  return c.json(pub(row));
});

voucherRoutes.delete('/:id', requireRole(...MANAGER_ROLES), async (c) => {
  const rows = await db.delete(vouchers).where(and(eq(vouchers.id, idParam(c)), eq(vouchers.store_id, c.get('user').storeId))).returning({ id: vouchers.id });
  if (!rows.length) throw new HttpError(404, 'not_found', 'Voucher tidak ditemukan');
  return c.json({ ok: true });
});

function dupCode(e: unknown) {
  const code = (e as { code?: string; cause?: { code?: string } })?.code ?? (e as { cause?: { code?: string } })?.cause?.code;
  return code === '23505' ? new HttpError(409, 'code_taken', 'Kode voucher sudah dipakai') : e;
}
