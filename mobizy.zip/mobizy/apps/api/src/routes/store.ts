import { eq } from 'drizzle-orm';
import { Hono } from 'hono';
import { MANAGER_ROLES, storeSettingsSchema } from '@mobizy/shared';
import { db, stores } from '../db/client.ts';
import { body } from '../lib/http.ts';
import { requireAuth, requireRole, type AppEnv } from '../middleware/auth.ts';

export const storeRoutes = new Hono<AppEnv>();
storeRoutes.use(requireAuth);

const cols = {
  id: stores.id, slug: stores.slug, store_name: stores.store_name, currency: stores.currency,
  currency_symbol: stores.currency_symbol, tax_rate: stores.tax_rate, receipt_footer: stores.receipt_footer,
  qris_url: stores.qris_url, created_at: stores.created_at,
};

storeRoutes.get('/', async (c) => {
  const [s] = await db.select(cols).from(stores).where(eq(stores.id, c.get('user').storeId));
  return c.json(s);
});

storeRoutes.patch('/', requireRole(...MANAGER_ROLES), async (c) => {
  const input = await body(c, storeSettingsSchema);
  const patch = Object.fromEntries(Object.entries(input).filter(([, v]) => v !== undefined));
  if (Object.keys(patch).length === 0) {
    const [s] = await db.select(cols).from(stores).where(eq(stores.id, c.get('user').storeId));
    return c.json(s);
  }
  const [s] = await db.update(stores).set(patch).where(eq(stores.id, c.get('user').storeId)).returning(cols);
  return c.json(s);
});
