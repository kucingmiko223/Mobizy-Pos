import { and, desc, eq, gte, lte } from 'drizzle-orm';
import { Hono } from 'hono';
import { MANAGER_ROLES, commentSchema } from '@mobizy/shared';
import { comments, db, products } from '../db/client.ts';
import { HttpError } from '../lib/errors.ts';
import { body, idParam, pub, rangeQuery } from '../lib/http.ts';
import { requireAuth, requireRole, type AppEnv } from '../middleware/auth.ts';

export const commentRoutes = new Hono<AppEnv>();
commentRoutes.use(requireAuth);

commentRoutes.get('/', async (c) => {
  const me = c.get('user');
  const { from, to } = rangeQuery(c);
  const rows = await db.select().from(comments)
    .where(and(eq(comments.store_id, me.storeId), from && gte(comments.created_at, from), to && lte(comments.created_at, to)))
    .orderBy(desc(comments.created_at)).limit(2000);
  return c.json(rows.map(({ user_id: _u, ...r }) => pub(r)));
});

commentRoutes.post('/', async (c) => {
  const me = c.get('user');
  const input = await body(c, commentSchema);
  if (input.product_id) {
    const [p] = await db.select({ id: products.id }).from(products).where(and(eq(products.id, input.product_id), eq(products.store_id, me.storeId)));
    if (!p) throw new HttpError(422, 'invalid_product', 'Produk tidak valid');
  }
  // the author is the signed-in user; a browser can't post as somebody else
  const [row] = await db.insert(comments).values({
    store_id: me.storeId, user_id: me.id, product_id: input.product_id, content: input.content,
    rating: input.rating, author_name: input.author_name || me.display_name,
  }).returning();
  const { user_id: _u, ...rest } = pub(row);
  return c.json(rest, 201);
});

commentRoutes.delete('/:id', requireRole(...MANAGER_ROLES), async (c) => {
  const rows = await db.delete(comments).where(and(eq(comments.id, idParam(c)), eq(comments.store_id, c.get('user').storeId))).returning({ id: comments.id });
  if (!rows.length) throw new HttpError(404, 'not_found', 'Ulasan tidak ditemukan');
  return c.json({ ok: true });
});
