import { and, desc, eq, gte, inArray, lte, sql } from 'drizzle-orm';
import { Hono } from 'hono';
import { z } from 'zod';
import { STAFF_ROLES, calculatePricing, checkVoucher, checkoutSchema, correctionSchema, countUnits, isManager, sumSubtotal } from '@mobizy/shared';
import { db, order_items, orders, products, stores, vouchers } from '../db/client.ts';
import { HttpError } from '../lib/errors.ts';
import { body, idParam, pub, rangeQuery } from '../lib/http.ts';
import { requireAuth, requireRole, type AppEnv } from '../middleware/auth.ts';
import { toRule } from './vouchers.ts';

export const orderRoutes = new Hono<AppEnv>();
orderRoutes.use(requireAuth, requireRole(...STAFF_ROLES));

const statusQuery = z.enum(['completed', 'voided', 'refunded']).optional();
const limitQuery = z.coerce.number().int().min(1).max(10000).default(1000);

orderRoutes.get('/', async (c) => {
  const me = c.get('user');
  const { from, to } = rangeQuery(c);
  const status = statusQuery.parse(c.req.query('status'));
  const limit = limitQuery.parse(c.req.query('limit'));
  const rows = await db.select().from(orders)
    .where(and(eq(orders.store_id, me.storeId), from && gte(orders.created_at, from), to && lte(orders.created_at, to), status && eq(orders.status, status)))
    .orderBy(desc(orders.created_at)).limit(limit);
  return c.json(rows.map(pub));
});

/** Line items for every order in a date range (used by dashboard + analytics). */
orderRoutes.get('/items', async (c) => {
  const me = c.get('user');
  const { from, to } = rangeQuery(c);
  const status = statusQuery.parse(c.req.query('status'));
  const rows = await db.select({ item: order_items }).from(order_items)
    .innerJoin(orders, eq(orders.id, order_items.order_id))
    .where(and(eq(orders.store_id, me.storeId), from && gte(orders.created_at, from), to && lte(orders.created_at, to), status && eq(orders.status, status)))
    .limit(100000);
  return c.json(rows.map((r) => pub(r.item)));
});

orderRoutes.get('/:id', async (c) => {
  const me = c.get('user');
  const id = idParam(c);
  const [order] = await db.select().from(orders).where(and(eq(orders.id, id), eq(orders.store_id, me.storeId)));
  if (!order) throw new HttpError(404, 'not_found', 'Pesanan tidak ditemukan');
  const items = await db.select().from(order_items).where(eq(order_items.order_id, id)).orderBy(order_items.created_at);
  return c.json({ order: pub(order), items: items.map(pub) });
});

/**
 * Checkout. Everything happens in ONE transaction:
 *  - product rows are locked (FOR UPDATE, in id order so two carts can't deadlock)
 *  - stock is checked against the locked rows, so parallel sales cannot oversell
 *  - the voucher row is locked, so usage_limit cannot be exceeded
 *  - prices, discount, tax and total are recomputed here; the browser only sends product ids + quantities
 */
orderRoutes.post('/', async (c) => {
  const me = c.get('user');
  const input = await body(c, checkoutSchema);

  const qty = new Map<string, number>();
  for (const it of input.items) qty.set(it.product_id, (qty.get(it.product_id) ?? 0) + it.quantity);
  const ids = [...qty.keys()].sort();

  const result = await db.transaction(async (tx) => {
    const prods = await tx.select().from(products)
      .where(and(eq(products.store_id, me.storeId), inArray(products.id, ids)))
      .orderBy(products.id).for('update');
    if (prods.length !== ids.length) throw new HttpError(422, 'product_not_found', 'Ada produk yang tidak ditemukan');
    for (const p of prods) {
      const q = qty.get(p.id)!;
      if (!p.is_active) throw new HttpError(409, 'product_inactive', `${p.name} sudah tidak dijual`, { product_id: p.id });
      if (p.stock < q) throw new HttpError(409, 'insufficient_stock', `Stok ${p.name} tidak cukup (sisa ${p.stock})`, { product_id: p.id, available: p.stock });
    }
    const lines = prods.map((p) => ({ unitPrice: p.price, quantity: qty.get(p.id)! }));
    const subtotal = sumSubtotal(lines);

    let voucher: typeof vouchers.$inferSelect | null = null;
    if (input.voucher_code) {
      [voucher] = await tx.select().from(vouchers)
        .where(and(eq(vouchers.store_id, me.storeId), eq(vouchers.code, input.voucher_code))).for('update');
      if (!voucher) throw new HttpError(422, 'voucher_not_found', 'Voucher tidak ditemukan');
      const check = checkVoucher(toRule(voucher), { subtotal, unitCount: countUnits(lines) });
      if (!check.ok) throw new HttpError(422, `voucher_${check.reason}`, check.message);
    }

    const [store] = await tx.select({ tax_rate: stores.tax_rate }).from(stores).where(eq(stores.id, me.storeId));
    const pricing = calculatePricing({ lines, taxRate: store.tax_rate, voucher: voucher ? toRule(voucher) : null });

    const isCash = input.payment_method === 'cash';
    const paid = isCash ? input.amount_paid ?? 0 : pricing.total;
    if (isCash && paid < pricing.total) throw new HttpError(422, 'insufficient_payment', 'Uang yang dibayarkan kurang', { total: pricing.total });

    for (const p of prods) {
      const q = qty.get(p.id)!;
      const upd = await tx.update(products)
        .set({ stock: sql`${products.stock} - ${q}`, updated_at: new Date() })
        .where(and(eq(products.id, p.id), eq(products.store_id, me.storeId), gte(products.stock, q)))
        .returning({ id: products.id });
      if (!upd.length) throw new HttpError(409, 'insufficient_stock', `Stok ${p.name} tidak cukup`);
    }
    if (voucher) await tx.update(vouchers).set({ used_count: sql`${vouchers.used_count} + 1` }).where(eq(vouchers.id, voucher.id));

    // per-store sequential number; this UPDATE takes the store row lock, so keep it as late as possible
    const [{ n }] = await tx.update(stores).set({ order_counter: sql`${stores.order_counter} + 1` })
      .where(eq(stores.id, me.storeId)).returning({ n: stores.order_counter });

    const [order] = await tx.insert(orders).values({
      store_id: me.storeId, order_number: n,
      subtotal: pricing.subtotal, tax_rate: store.tax_rate, tax_amount: pricing.taxAmount,
      discount: pricing.discountAmount, discount_amount: pricing.discountAmount, total: pricing.total,
      payment_method: input.payment_method, amount_paid: paid, change_due: isCash ? paid - pricing.total : 0,
      status: 'completed', customer_name: input.customer_name, notes: input.notes,
      item_count: pricing.itemCount, voucher_id: voucher?.id ?? null, correction_type: 'none',
      scheduled_time: input.scheduled_time ? new Date(input.scheduled_time) : null, created_by: me.id,
    }).returning();

    const items = await tx.insert(order_items).values(prods.map((p) => ({
      store_id: me.storeId, order_id: order.id, product_id: p.id, product_name: p.name,
      unit_price: p.price, quantity: qty.get(p.id)!, subtotal: p.price * qty.get(p.id)!,
    }))).returning();
    return { order, items };
  });

  return c.json({ order: pub(result.order), items: result.items.map(pub) }, 201);
});

/** void / refund (managers only): restock once. adjust (any staff): note only. */
orderRoutes.post('/:id/correct', async (c) => {
  const me = c.get('user');
  const id = idParam(c);
  const { type, reason } = await body(c, correctionSchema);
  if (type !== 'adjust' && !isManager(me.role)) throw new HttpError(403, 'forbidden', 'Void/refund hanya untuk pemilik atau admin');

  const updated = await db.transaction(async (tx) => {
    const [order] = await tx.select().from(orders).where(and(eq(orders.id, id), eq(orders.store_id, me.storeId))).for('update');
    if (!order) throw new HttpError(404, 'not_found', 'Pesanan tidak ditemukan');
    if (order.status !== 'completed') throw new HttpError(409, 'already_corrected', 'Pesanan ini sudah di-void atau di-refund');

    if (type === 'adjust') {
      const [o] = await tx.update(orders).set({ correction_type: 'adjust', correction_reason: reason }).where(eq(orders.id, id)).returning();
      return o;
    }
    const [o] = await tx.update(orders)
      .set({ status: type === 'void' ? 'voided' : 'refunded', correction_type: type, correction_reason: reason })
      .where(eq(orders.id, id)).returning();
    const items = await tx.select().from(order_items).where(eq(order_items.order_id, id));
    for (const it of items) {
      if (!it.product_id) continue;
      await tx.update(products).set({ stock: sql`${products.stock} + ${it.quantity}`, updated_at: new Date() })
        .where(and(eq(products.id, it.product_id), eq(products.store_id, me.storeId)));
    }
    return o;
  });
  return c.json(pub(updated));
});
