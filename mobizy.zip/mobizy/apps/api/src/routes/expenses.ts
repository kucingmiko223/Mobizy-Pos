import { and, desc, eq, gte, lte } from 'drizzle-orm';
import { Hono } from 'hono';
import { MANAGER_ROLES, expenseSchema } from '@mobizy/shared';
import { db, expenses } from '../db/client.ts';
import { HttpError } from '../lib/errors.ts';
import { body, idParam, pub, rangeQuery } from '../lib/http.ts';
import { requireAuth, requireRole, type AppEnv } from '../middleware/auth.ts';

export const expenseRoutes = new Hono<AppEnv>();
expenseRoutes.use(requireAuth, requireRole(...MANAGER_ROLES));

expenseRoutes.get('/', async (c) => {
  const me = c.get('user');
  const { from, to } = rangeQuery(c);
  const rows = await db.select().from(expenses)
    .where(and(eq(expenses.store_id, me.storeId), from && gte(expenses.expense_date, from.toISOString().slice(0, 10)), to && lte(expenses.expense_date, to.toISOString().slice(0, 10))))
    .orderBy(desc(expenses.expense_date), desc(expenses.created_at)).limit(5000);
  return c.json(rows.map(pub));
});
expenseRoutes.post('/', async (c) => {
  const input = await body(c, expenseSchema);
  const [row] = await db.insert(expenses).values({ ...input, store_id: c.get('user').storeId }).returning();
  return c.json(pub(row), 201);
});
expenseRoutes.delete('/:id', async (c) => {
  const rows = await db.delete(expenses).where(and(eq(expenses.id, idParam(c)), eq(expenses.store_id, c.get('user').storeId))).returning({ id: expenses.id });
  if (!rows.length) throw new HttpError(404, 'not_found', 'Pengeluaran tidak ditemukan');
  return c.json({ ok: true });
});
