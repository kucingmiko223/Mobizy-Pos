import { eq } from 'drizzle-orm';
import { Hono } from 'hono';
import { getCookie } from 'hono/cookie';
import { z } from 'zod';
import { loginSchema, passwordSchema, registerCustomerSchema, registerStoreSchema, type SessionUser } from '@mobizy/shared';
import { db, stores, users } from '../db/client.ts';
import { env } from '../env.ts';
import { HttpError } from '../lib/errors.ts';
import { body } from '../lib/http.ts';
import { DUMMY_HASH, hashPassword, verifyPassword } from '../lib/password.ts';
import { COOKIE, endSession, endSessions, startSession, type AuthUser } from '../lib/session.ts';
import { requireAuth, type AppEnv } from '../middleware/auth.ts';
import { rateLimit } from '../middleware/rate-limit.ts';

export const authRoutes = new Hono<AppEnv>();

const toSessionUser = (u: AuthUser): SessionUser => ({
  id: u.id, email: u.email, display_name: u.display_name, role: u.role, store_id: u.storeId, store_name: u.storeName,
});

function isUniqueViolation(e: unknown, constraintHint?: string) {
  const err = e as { code?: string; constraint_name?: string; cause?: { code?: string; constraint_name?: string } };
  const code = err?.code ?? err?.cause?.code;
  const name = err?.constraint_name ?? err?.cause?.constraint_name ?? '';
  return code === '23505' && (!constraintHint || name.includes(constraintHint));
}

authRoutes.post('/register', rateLimit({ name: 'register', windowMs: 3_600_000, max: 10 }), async (c) => {
  if (!env.ALLOW_PUBLIC_SIGNUP) throw new HttpError(403, 'signup_disabled', 'Pendaftaran toko baru dinonaktifkan');
  const input = await body(c, registerStoreSchema);
  const password_hash = await hashPassword(input.password);
  try {
    const user = await db.transaction(async (tx) => {
      const [store] = await tx.insert(stores).values({ slug: input.slug, store_name: input.store_name }).returning();
      const [u] = await tx.insert(users).values({
        store_id: store.id, email: input.email, display_name: input.display_name, role: 'owner', password_hash,
      }).returning();
      return { ...u, storeName: store.store_name };
    });
    await startSession(c, user.id);
    return c.json({ user: toSessionUser({ id: user.id, email: user.email, display_name: user.display_name, role: user.role, storeId: user.store_id, storeName: user.storeName }) }, 201);
  } catch (e) {
    if (isUniqueViolation(e, 'slug')) throw new HttpError(409, 'slug_taken', 'Alamat toko sudah dipakai');
    if (isUniqueViolation(e)) throw new HttpError(409, 'email_taken', 'Email sudah terdaftar');
    throw e;
  }
});

authRoutes.post('/register-customer', rateLimit({ name: 'register-customer', windowMs: 3_600_000, max: 20 }), async (c) => {
  if (!env.ALLOW_PUBLIC_SIGNUP) throw new HttpError(403, 'signup_disabled', 'Pendaftaran dinonaktifkan');
  const input = await body(c, registerCustomerSchema);
  const [store] = await db.select().from(stores).where(eq(stores.slug, input.store_slug)).limit(1);
  if (!store) throw new HttpError(404, 'store_not_found', 'Toko tidak ditemukan');
  try {
    const [u] = await db.insert(users).values({
      store_id: store.id, email: input.email, display_name: input.display_name, role: 'customer',
      password_hash: await hashPassword(input.password),
    }).returning();
    await startSession(c, u.id);
    return c.json({ user: toSessionUser({ id: u.id, email: u.email, display_name: u.display_name, role: u.role, storeId: store.id, storeName: store.store_name }) }, 201);
  } catch (e) {
    if (isUniqueViolation(e)) throw new HttpError(409, 'email_taken', 'Email sudah terdaftar');
    throw e;
  }
});

authRoutes.post('/login', rateLimit({ name: 'login', windowMs: 15 * 60_000, max: 20 }), async (c) => {
  const { email, password } = await body(c, loginSchema);
  const [row] = await db
    .select({ u: users, storeName: stores.store_name })
    .from(users)
    .innerJoin(stores, eq(stores.id, users.store_id))
    .where(eq(users.email, email))
    .limit(1);
  const ok = await verifyPassword(password, row?.u.password_hash ?? DUMMY_HASH);
  if (!row || !ok || !row.u.is_active) throw new HttpError(401, 'bad_credentials', 'Email atau password salah');
  await startSession(c, row.u.id);
  return c.json({
    user: toSessionUser({ id: row.u.id, email: row.u.email, display_name: row.u.display_name, role: row.u.role, storeId: row.u.store_id, storeName: row.storeName }),
  });
});

authRoutes.post('/logout', async (c) => {
  await endSession(c, getCookie(c, COOKIE));
  return c.json({ ok: true });
});

authRoutes.get('/me', requireAuth, (c) => c.json({ user: toSessionUser(c.get('user')) }));

authRoutes.post('/change-password', requireAuth, rateLimit({ name: 'chpw', windowMs: 15 * 60_000, max: 10 }), async (c) => {
  const { current_password, new_password } = await body(c, z.object({ current_password: z.string().min(1), new_password: passwordSchema }));
  const me = c.get('user');
  const [row] = await db.select({ h: users.password_hash }).from(users).where(eq(users.id, me.id));
  if (!row || !(await verifyPassword(current_password, row.h))) throw new HttpError(401, 'bad_credentials', 'Password saat ini salah');
  await db.update(users).set({ password_hash: await hashPassword(new_password) }).where(eq(users.id, me.id));
  await endSessions(me.id, getCookie(c, COOKIE)); // sign out every other device
  return c.json({ ok: true });
});
