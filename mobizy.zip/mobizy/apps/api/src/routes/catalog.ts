// categories + products
import { and, asc, eq } from 'drizzle-orm';
import { Hono } from 'hono';
import { MANAGER_ROLES, categorySchema, isManager, productSchema } from '@mobizy/shared';
import { categories, db, products } from '../db/client.ts';
import { HttpError } from '../lib/errors.ts';
import { body, idParam, pub } from '../lib/http.ts';
import { requireAuth, requireRole, type AppEnv } from '../middleware/auth.ts';

export const categoryRoutes = new Hono<AppEnv>();
categoryRoutes.use(requireAuth);

categoryRoutes.get('/', async (c) => {
  const rows = await db.select().from(categories).where(eq(categories.store_id, c.get('user').storeId)).orderBy(asc(categories.sort_order), asc(categories.name));
  return c.json(rows.map(pub));
});
categoryRoutes.post('/', requireRole(...MANAGER_ROLES), async (c) => {
  const input = await body(c, categorySchema);
  const [row] = await db.insert(categories).values({ ...input, store_id: c.get('user').storeId }).returning();
  return c.json(pub(row), 201);
});
categoryRoutes.patch('/:id', requireRole(...MANAGER_ROLES), async (c) => {
  const input = await body(c, categorySchema.partial());
  const [row] = await db.update(categories).set(input).where(and(eq(categories.id, idParam(c)), eq(categories.store_id, c.get('user').storeId))).returning();
  if (!row) throw new HttpError(404, 'not_found', 'Kategori tidak ditemukan');
  return c.json(pub(row));
});
categoryRoutes.delete('/:id', requireRole(...MANAGER_ROLES), async (c) => {
  const rows = await db.delete(categories).where(and(eq(categories.id, idParam(c)), eq(categories.store_id, c.get('user').storeId))).returning({ id: categories.id });
  if (!rows.length) throw new HttpError(404, 'not_found', 'Kategori tidak ditemukan');
  return c.json({ ok: true });
});

export const productRoutes = new Hono<AppEnv>();
productRoutes.use(requireAuth);

async function assertCategory(storeId: string, categoryId: string | null | undefined) {
  if (!categoryId) return;
  const [cat] = await db.select({ id: categories.id }).from(categories).where(and(eq(categories.id, categoryId), eq(categories.store_id, storeId)));
  if (!cat) throw new HttpError(422, 'invalid_category', 'Kategori tidak valid');
}

productRoutes.get('/', async (c) => {
  const me = c.get('user');
  const manager = isManager(me.role);
  const includeInactive = manager && c.req.query('include_inactive') === '1';
  const rows = await db.select().from(products)
    .where(and(eq(products.store_id, me.storeId), includeInactive ? undefined : eq(products.is_active, true)))
    .orderBy(asc(products.name));
  // purchase cost is business-sensitive: managers only
  return c.json(rows.map((r) => (manager ? pub(r) : (({ cost: _c, ...rest }) => rest)(pub(r)))));
});
productRoutes.post('/', requireRole(...MANAGER_ROLES), async (c) => {
  const me = c.get('user');
  const input = await body(c, productSchema);
  await assertCategory(me.storeId, input.category_id);
  const [row] = await db.insert(products).values({ ...input, store_id: me.storeId }).returning();
  return c.json(pub(row), 201);
});
productRoutes.patch('/:id', requireRole(...MANAGER_ROLES), async (c) => {
  const me = c.get('user');
  const input = await body(c, productSchema.partial());
  await assertCategory(me.storeId, input.category_id);
  const [row] = await db.update(products).set({ ...input, updated_at: new Date() })
    .where(and(eq(products.id, idParam(c)), eq(products.store_id, me.storeId))).returning();
  if (!row) throw new HttpError(404, 'not_found', 'Produk tidak ditemukan');
  return c.json(pub(row));
});
productRoutes.delete('/:id', requireRole(...MANAGER_ROLES), async (c) => {
  const rows = await db.delete(products).where(and(eq(products.id, idParam(c)), eq(products.store_id, c.get('user').storeId))).returning({ id: products.id });
  if (!rows.length) throw new HttpError(404, 'not_found', 'Produk tidak ditemukan');
  return c.json({ ok: true });
});
