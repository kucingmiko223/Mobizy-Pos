import { drizzle } from 'drizzle-orm/postgres-js';
import postgres from 'postgres';
import { env } from '../env.ts';
import * as schema from './schema.ts';

export const pg = postgres(env.DATABASE_URL, { max: 10, idle_timeout: 20, onnotice: () => {} });
export const db = drizzle(pg, { schema });
export type Tx = Parameters<Parameters<typeof db.transaction>[0]>[0];
export * from './schema.ts';
