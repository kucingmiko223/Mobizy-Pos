// Keep in sync with migrations/*.sql (those files are what actually creates the tables).
// Property names are snake_case on purpose so rows serialize to the same JSON the UI already used.
import { sql } from 'drizzle-orm';
import { boolean, date, index, integer, numeric, pgTable, text, timestamp, unique, uuid } from 'drizzle-orm/pg-core';

const money = (name: string) => numeric(name, { precision: 14, scale: 2, mode: 'number' });
const ts = (name: string) => timestamp(name, { withTimezone: true, mode: 'date' });
const id = () => uuid('id').primaryKey().defaultRandom();
const storeId = () => uuid('store_id').notNull().references(() => stores.id, { onDelete: 'cascade' });

export const stores = pgTable('stores', {
  id: id(),
  slug: text('slug').notNull().unique(),
  store_name: text('store_name').notNull(),
  currency: text('currency').notNull().default('IDR'),
  currency_symbol: text('currency_symbol').notNull().default('Rp'),
  tax_rate: numeric('tax_rate', { precision: 5, scale: 4, mode: 'number' }).notNull().default(0),
  receipt_footer: text('receipt_footer').notNull().default('Terima kasih sudah berbelanja!'),
  qris_url: text('qris_url'),
  order_counter: integer('order_counter').notNull().default(0),
  created_at: ts('created_at').notNull().defaultNow(),
});

export const users = pgTable('users', {
  id: id(),
  store_id: storeId(),
  email: text('email').notNull().unique(),
  display_name: text('display_name').notNull(),
  role: text('role', { enum: ['owner', 'admin', 'cashier', 'customer'] }).notNull(),
  password_hash: text('password_hash').notNull(),
  is_active: boolean('is_active').notNull().default(true),
  created_at: ts('created_at').notNull().defaultNow(),
});

export const sessions = pgTable('sessions', {
  id: text('id').primaryKey(),
  user_id: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  expires_at: ts('expires_at').notNull(),
  created_at: ts('created_at').notNull().defaultNow(),
});

export const categories = pgTable('categories', {
  id: id(),
  store_id: storeId(),
  name: text('name').notNull(),
  icon: text('icon').notNull().default('Tag'),
  sort_order: integer('sort_order').notNull().default(0),
  created_at: ts('created_at').notNull().defaultNow(),
}, (t) => [index('categories_store_idx').on(t.store_id)]);

export const products = pgTable('products', {
  id: id(),
  store_id: storeId(),
  name: text('name').notNull(),
  description: text('description').notNull().default(''),
  price: money('price').notNull().default(0),
  cost: money('cost').notNull().default(0),
  stock: integer('stock').notNull().default(0),
  category_id: uuid('category_id').references(() => categories.id, { onDelete: 'set null' }),
  barcode: text('barcode').notNull().default(''),
  image_url: text('image_url').notNull().default(''),
  is_active: boolean('is_active').notNull().default(true),
  created_at: ts('created_at').notNull().defaultNow(),
  updated_at: ts('updated_at').notNull().defaultNow(),
}, (t) => [index('products_store_idx').on(t.store_id, t.is_active)]);

export const vouchers = pgTable('vouchers', {
  id: id(),
  store_id: storeId(),
  code: text('code').notNull(),
  name: text('name').notNull(),
  description: text('description').notNull().default(''),
  discount_type: text('discount_type', { enum: ['percentage', 'fixed', 'bogo'] }).notNull().default('percentage'),
  discount_value: money('discount_value').notNull().default(0),
  min_purchase: money('min_purchase').notNull().default(0),
  max_discount: money('max_discount'),
  usage_limit: integer('usage_limit'),
  used_count: integer('used_count').notNull().default(0),
  is_active: boolean('is_active').notNull().default(true),
  valid_from: ts('valid_from').notNull().defaultNow(),
  valid_until: ts('valid_until'),
  created_at: ts('created_at').notNull().defaultNow(),
}, (t) => [unique('vouchers_store_id_code_key').on(t.store_id, t.code)]);

export const orders = pgTable('orders', {
  id: id(),
  store_id: storeId(),
  order_number: integer('order_number').notNull(),
  subtotal: money('subtotal').notNull().default(0),
  tax_rate: numeric('tax_rate', { precision: 5, scale: 4, mode: 'number' }).notNull().default(0),
  tax_amount: money('tax_amount').notNull().default(0),
  discount: money('discount').notNull().default(0),
  discount_amount: money('discount_amount').notNull().default(0),
  total: money('total').notNull().default(0),
  payment_method: text('payment_method', { enum: ['cash', 'card', 'qris', 'transfer'] }).notNull().default('cash'),
  amount_paid: money('amount_paid').notNull().default(0),
  change_due: money('change_due').notNull().default(0),
  status: text('status', { enum: ['completed', 'voided', 'refunded'] }).notNull().default('completed'),
  customer_name: text('customer_name').notNull().default(''),
  notes: text('notes').notNull().default(''),
  item_count: integer('item_count').notNull().default(0),
  voucher_id: uuid('voucher_id').references(() => vouchers.id, { onDelete: 'set null' }),
  correction_type: text('correction_type', { enum: ['none', 'void', 'refund', 'adjust'] }).notNull().default('none'),
  correction_reason: text('correction_reason').notNull().default(''),
  corrected_order_id: uuid('corrected_order_id'),
  scheduled_time: ts('scheduled_time'),
  created_by: uuid('created_by').references(() => users.id, { onDelete: 'set null' }),
  created_at: ts('created_at').notNull().defaultNow(),
}, (t) => [
  unique('orders_store_id_order_number_key').on(t.store_id, t.order_number),
  index('orders_store_created_idx').on(t.store_id, t.created_at),
]);

export const order_items = pgTable('order_items', {
  id: id(),
  store_id: storeId(),
  order_id: uuid('order_id').notNull().references(() => orders.id, { onDelete: 'cascade' }),
  product_id: uuid('product_id').references(() => products.id, { onDelete: 'set null' }),
  product_name: text('product_name').notNull(),
  unit_price: money('unit_price').notNull(),
  quantity: integer('quantity').notNull(),
  subtotal: money('subtotal').notNull(),
  created_at: ts('created_at').notNull().defaultNow(),
}, (t) => [index('order_items_order_idx').on(t.order_id)]);

export const comments = pgTable('comments', {
  id: id(),
  store_id: storeId(),
  product_id: uuid('product_id').references(() => products.id, { onDelete: 'cascade' }),
  user_id: uuid('user_id').references(() => users.id, { onDelete: 'set null' }),
  author_name: text('author_name').notNull().default('Anonymous'),
  content: text('content').notNull(),
  rating: integer('rating').notNull().default(5),
  created_at: ts('created_at').notNull().defaultNow(),
});

export const expenses = pgTable('expenses', {
  id: id(),
  store_id: storeId(),
  category: text('category').notNull().default('other'),
  description: text('description').notNull().default(''),
  amount: money('amount').notNull().default(0),
  expense_date: date('expense_date', { mode: 'string' }).notNull().default(sql`CURRENT_DATE`),
  created_at: ts('created_at').notNull().defaultNow(),
});
