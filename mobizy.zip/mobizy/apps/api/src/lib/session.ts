import { createHash, randomBytes } from 'node:crypto';
import { and, eq, gt, lt, ne } from 'drizzle-orm';
import type { Context } from 'hono';
import { deleteCookie, setCookie } from 'hono/cookie';
import { db, sessions, stores, users } from '../db/client.ts';
import { env, isProd } from '../env.ts';
import type { UserRole } from '@mobizy/shared';

export const COOKIE = 'mobizy_sid';
const hash = (token: string) => createHash('sha256').update(token).digest('hex');

export interface AuthUser {
  id: string;
  email: string;
  display_name: string;
  role: UserRole;
  storeId: string;
  storeName: string;
}

export async function startSession(c: Context, userId: string) {
  const token = randomBytes(32).toString('base64url');
  const expires = new Date(Date.now() + env.SESSION_TTL_DAYS * 86_400_000);
  await db.insert(sessions).values({ id: hash(token), user_id: userId, expires_at: expires });
  // opportunistic cleanup of this user's dead sessions
  await db.delete(sessions).where(and(eq(sessions.user_id, userId), lt(sessions.expires_at, new Date())));
  setCookie(c, COOKIE, token, {
    httpOnly: true,
    secure: isProd,
    sameSite: 'Lax',
    path: '/',
    expires,
  });
}

export async function endSession(c: Context, token: string | undefined) {
  if (token) await db.delete(sessions).where(eq(sessions.id, hash(token)));
  deleteCookie(c, COOKIE, { path: '/' });
}

/** Log a user out everywhere, optionally keeping the session behind `keepToken`. */
export async function endSessions(userId: string, keepToken?: string) {
  const cond = keepToken
    ? and(eq(sessions.user_id, userId), ne(sessions.id, hash(keepToken)))
    : eq(sessions.user_id, userId);
  await db.delete(sessions).where(cond);
}

export async function findUserBySession(token: string): Promise<AuthUser | null> {
  const [row] = await db
    .select({
      id: users.id, email: users.email, display_name: users.display_name, role: users.role,
      storeId: users.store_id, storeName: stores.store_name,
    })
    .from(sessions)
    .innerJoin(users, eq(users.id, sessions.user_id))
    .innerJoin(stores, eq(stores.id, users.store_id))
    .where(and(eq(sessions.id, hash(token)), gt(sessions.expires_at, new Date()), eq(users.is_active, true)))
    .limit(1);
  return row ?? null;
}
