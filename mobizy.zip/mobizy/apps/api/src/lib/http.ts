import type { Context } from 'hono';
import { z } from 'zod';
import { HttpError } from './errors.ts';

export async function body<S extends z.ZodTypeAny>(c: Context, schema: S): Promise<z.infer<S>> {
  let raw: unknown;
  try { raw = await c.req.json(); } catch { throw new HttpError(400, 'invalid_json', 'Body harus berupa JSON'); }
  return schema.parse(raw);
}

export function idParam(c: Context, name = 'id'): string {
  const r = z.string().uuid().safeParse(c.req.param(name));
  if (!r.success) throw new HttpError(404, 'not_found', 'Data tidak ditemukan');
  return r.data;
}

const rangeSchema = z.object({
  from: z.string().datetime({ offset: true }).optional(),
  to: z.string().datetime({ offset: true }).optional(),
});
export function rangeQuery(c: Context) {
  const r = rangeSchema.safeParse(c.req.query());
  if (!r.success) throw r.error;
  return { from: r.data.from ? new Date(r.data.from) : undefined, to: r.data.to ? new Date(r.data.to) : undefined };
}

/** Never send the tenant column to the browser. */
export function pub<T extends { store_id?: unknown }>(row: T): Omit<T, 'store_id'> {
  const { store_id: _s, ...rest } = row;
  return rest;
}
