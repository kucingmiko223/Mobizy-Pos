import { sql } from 'drizzle-orm';
import { Hono } from 'hono';
import { cors } from 'hono/cors';
import { logger } from 'hono/logger';
import { secureHeaders } from 'hono/secure-headers';
import { ZodError } from 'zod';
import { db } from './db/client.ts';
import { env } from './env.ts';
import { HttpError } from './lib/errors.ts';
import { originCheck } from './middleware/origin.ts';
import { authRoutes } from './routes/auth.ts';
import { categoryRoutes, productRoutes } from './routes/catalog.ts';
import { commentRoutes } from './routes/comments.ts';
import { expenseRoutes } from './routes/expenses.ts';
import { orderRoutes } from './routes/orders.ts';
import { storeRoutes } from './routes/store.ts';
import { userRoutes } from './routes/users.ts';
import { voucherRoutes } from './routes/vouchers.ts';

export const app = new Hono();

if (env.NODE_ENV !== 'test') app.use(logger());
app.use(secureHeaders());
app.use('/api/*', cors({ origin: (o) => (env.CORS_ORIGINS.includes(o) ? o : null), credentials: true }));
app.use('/api/*', originCheck);

app.get('/api/health', async (c) => {
  await db.execute(sql`select 1`);
  return c.json({ ok: true });
});

app.route('/api/auth', authRoutes);
app.route('/api/users', userRoutes);
app.route('/api/store', storeRoutes);
app.route('/api/categories', categoryRoutes);
app.route('/api/products', productRoutes);
app.route('/api/vouchers', voucherRoutes);
app.route('/api/orders', orderRoutes);
app.route('/api/comments', commentRoutes);
app.route('/api/expenses', expenseRoutes);

app.notFound((c) => c.json({ error: { code: 'not_found', message: 'Endpoint tidak ditemukan' } }, 404));

app.onError((err, c) => {
  if (err instanceof HttpError) {
    return c.json({ error: { code: err.code, message: err.message, details: err.details } }, err.status);
  }
  if (err instanceof ZodError) {
    return c.json({ error: { code: 'validation_error', message: err.issues[0]?.message ?? 'Data tidak valid', details: err.flatten() } }, 400);
  }
  console.error(err);
  return c.json({ error: { code: 'internal_error', message: 'Terjadi kesalahan pada server' } }, 500);
});
