import { serve } from '@hono/node-server';
import { app } from './app.ts';
import { pg } from './db/client.ts';
import { env } from './env.ts';

const server = serve({ fetch: app.fetch, port: env.PORT }, (info) => {
  console.log(`Mobizy API listening on :${info.port} (${env.NODE_ENV})`);
});

const shutdown = async () => {
  server.close();
  await pg.end({ timeout: 5 });
  process.exit(0);
};
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);
