// Integration tests: need a real, MIGRATED Postgres in DATABASE_URL (use a throwaway database!).
//   DATABASE_URL=postgres://... npm run db:migrate -w @mobizy/api && npm test -w @mobizy/api
import assert from 'node:assert/strict';
import { after, before, describe, test } from 'node:test';
import { app } from '../src/app.ts';
import { pg } from '../src/db/client.ts';

const J = { 'content-type': 'application/json' };

async function call(path: string, init: RequestInit & { cookie?: string } = {}) {
  const { cookie, ...rest } = init;
  const res = await app.request(`/api${path}`, { ...rest, headers: { ...J, ...(cookie ? { cookie } : {}), ...(rest.headers as object) } });
  return { res, json: (await res.json().catch(() => null)) as any, cookie: res.headers.get('set-cookie')?.split(';')[0] ?? cookie };
}
async function newStore(tag: string) {
  const r = await call('/auth/register', { method: 'POST', body: JSON.stringify({
    store_name: `Store ${tag}`, slug: `t-${tag}-${Date.now().toString(36)}`, display_name: 'Owner',
    email: `${tag}-${Date.now()}@test.local`, password: 'correct-horse-battery' }) });
  assert.equal(r.res.status, 201);
  return r.cookie!;
}
async function product(cookie: string, stock: number, price = 10000) {
  const r = await call('/products', { method: 'POST', cookie, body: JSON.stringify({ name: 'P', price, stock }) });
  assert.equal(r.res.status, 201);
  return r.json.id as string;
}

describe('security + money rules', () => {
  after(() => pg.end());

  test('anonymous requests are rejected', async () => {
    assert.equal((await call('/products')).res.status, 401);
    assert.equal((await call('/orders')).res.status, 401);
  });

  test('a store cannot see or sell another store\'s products', async () => {
    const a = await newStore('a'), b = await newStore('b');
    const pid = await product(a, 5);
    assert.deepEqual((await call('/products', { cookie: b })).json, []);
    const r = await call('/orders', { method: 'POST', cookie: b, body: JSON.stringify({ items: [{ product_id: pid, quantity: 1 }], payment_method: 'card' }) });
    assert.equal(r.res.status, 422);
  });

  test('server ignores client totals and computes its own', async () => {
    const c = await newStore('price');
    const pid = await product(c, 10, 10000);
    const r = await call('/orders', { method: 'POST', cookie: c, body: JSON.stringify({ items: [{ product_id: pid, quantity: 2 }], payment_method: 'card', total: 1, subtotal: 1 }) });
    assert.equal(r.res.status, 201);
    assert.equal(r.json.order.total, 20000);
  });

  test('parallel checkouts cannot oversell', async () => {
    const c = await newStore('race');
    const pid = await product(c, 3);
    const body = JSON.stringify({ items: [{ product_id: pid, quantity: 1 }], payment_method: 'card' });
    const results = await Promise.all(Array.from({ length: 10 }, () => call('/orders', { method: 'POST', cookie: c, body })));
    assert.equal(results.filter((r) => r.res.status === 201).length, 3);
    assert.equal(results.filter((r) => r.res.status === 409).length, 7);
    const prods = (await call('/products', { cookie: c })).json;
    assert.equal(prods[0].stock, 0);
  });

  test('voucher usage_limit holds under parallel use', async () => {
    const c = await newStore('vou');
    const pid = await product(c, 50);
    await call('/vouchers', { method: 'POST', cookie: c, body: JSON.stringify({ code: 'ONCE', name: 'Once', discount_type: 'fixed', discount_value: 1000, usage_limit: 1 }) });
    const body = JSON.stringify({ items: [{ product_id: pid, quantity: 1 }], payment_method: 'card', voucher_code: 'ONCE' });
    const results = await Promise.all(Array.from({ length: 5 }, () => call('/orders', { method: 'POST', cookie: c, body })));
    assert.equal(results.filter((r) => r.res.status === 201).length, 1);
  });

  test('void restocks exactly once', async () => {
    const c = await newStore('void');
    const pid = await product(c, 5);
    const o = await call('/orders', { method: 'POST', cookie: c, body: JSON.stringify({ items: [{ product_id: pid, quantity: 2 }], payment_method: 'card' }) });
    const id = o.json.order.id;
    const first = await call(`/orders/${id}/correct`, { method: 'POST', cookie: c, body: JSON.stringify({ type: 'void', reason: 'salah input' }) });
    const second = await call(`/orders/${id}/correct`, { method: 'POST', cookie: c, body: JSON.stringify({ type: 'void', reason: 'lagi' }) });
    assert.equal(first.res.status, 200);
    assert.equal(second.res.status, 409);
    assert.equal((await call('/products', { cookie: c })).json[0].stock, 5);
  });

  test('cash payment below total is refused', async () => {
    const c = await newStore('cash');
    const pid = await product(c, 5, 10000);
    const r = await call('/orders', { method: 'POST', cookie: c, body: JSON.stringify({ items: [{ product_id: pid, quantity: 1 }], payment_method: 'cash', amount_paid: 5000 }) });
    assert.equal(r.res.status, 422);
  });
});
