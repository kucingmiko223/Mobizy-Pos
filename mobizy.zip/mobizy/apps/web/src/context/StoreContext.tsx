import { createContext, useContext, useState, useEffect, useCallback, type ReactNode } from 'react';
import { api } from '@/lib/api';
import { useAuth } from '@/context/AuthContext';
import type { Product, Category, StoreSettings, CartItem, Voucher } from '@/types';

interface StoreContextValue {
  products: Product[];
  categories: Category[];
  settings: StoreSettings | null;
  vouchers: Voucher[];
  cart: CartItem[];
  loading: boolean;
  addToCart: (product: Product) => void;
  removeFromCart: (productId: string) => void;
  updateQuantity: (productId: string, delta: number) => void;
  setQuantity: (productId: string, qty: number) => void;
  clearCart: () => void;
  cartCount: number;
  cartSubtotal: number;
  refreshProducts: () => Promise<void>;
  refreshSettings: () => Promise<void>;
  refreshVouchers: () => Promise<void>;
}

const StoreContext = createContext<StoreContextValue | null>(null);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [settings, setSettings] = useState<StoreSettings | null>(null);
  const [vouchers, setVouchers] = useState<Voucher[]>([]);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [loading, setLoading] = useState(true);

  const { role } = useAuth();
  const isManager = role === 'owner' || role === 'admin';

  const fetchProducts = useCallback(async () => {
    try {
      setProducts(await api.get<Product[]>('/products'));
    } catch (e) {
      console.error('Error fetching products:', e);
    }
  }, []);

  const fetchCategories = useCallback(async () => {
    try {
      setCategories(await api.get<Category[]>('/categories'));
    } catch (e) {
      console.error('Error fetching categories:', e);
    }
  }, []);

  const fetchSettings = useCallback(async () => {
    try {
      setSettings(await api.get<StoreSettings>('/store'));
    } catch (e) {
      console.error('Error fetching settings:', e);
    }
  }, []);

  const fetchVouchers = useCallback(async () => {
    if (!isManager) return; // only owners/admins may list vouchers
    try {
      setVouchers(await api.get<Voucher[]>('/vouchers'));
    } catch (e) {
      console.error('Error fetching vouchers:', e);
    }
  }, [isManager]);

  useEffect(() => {
    (async () => {
      await Promise.all([fetchProducts(), fetchCategories(), fetchSettings(), fetchVouchers()]);
      setLoading(false);
    })();
  }, [fetchProducts, fetchCategories, fetchSettings, fetchVouchers]);

  const addToCart = useCallback((product: Product) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { product, quantity: 1 }];
    });
  }, []);

  const removeFromCart = useCallback((productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  }, []);

  const updateQuantity = useCallback((productId: string, delta: number) => {
    setCart((prev) => {
      return prev
        .map((item) => {
          if (item.product.id === productId) {
            const newQty = item.quantity + delta;
            return newQty <= 0 ? null : { ...item, quantity: newQty };
          }
          return item;
        })
        .filter((item): item is CartItem => item !== null);
    });
  }, []);

  const setQuantity = useCallback((productId: string, qty: number) => {
    setCart((prev) => {
      if (qty <= 0) return prev.filter((item) => item.product.id !== productId);
      return prev.map((item) =>
        item.product.id === productId ? { ...item, quantity: qty } : item
      );
    });
  }, []);

  const clearCart = useCallback(() => setCart([]), []);

  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const cartSubtotal = cart.reduce(
    (sum, item) => sum + item.product.price * item.quantity,
    0
  );

  const value: StoreContextValue = {
    products,
    categories,
    settings,
    vouchers,
    cart,
    loading,
    addToCart,
    removeFromCart,
    updateQuantity,
    setQuantity,
    clearCart,
    cartCount,
    cartSubtotal,
    refreshProducts: fetchProducts,
    refreshSettings: fetchSettings,
    refreshVouchers: fetchVouchers,
  };

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore() {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error('useStore must be used within StoreProvider');
  return ctx;
}
