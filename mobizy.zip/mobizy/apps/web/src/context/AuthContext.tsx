import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import type { SessionUser, UserRole } from '@mobizy/shared';
import { api, ApiError, setUnauthorizedHandler } from '@/lib/api';

interface AuthContextValue {
  user: SessionUser | null;
  role: UserRole | null;
  displayName: string;
  loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  registerStore: (input: { store_name: string; slug: string; display_name: string; email: string; password: string }) => Promise<void>;
  registerCustomer: (input: { store_slug: string; display_name: string; email: string; password: string }) => Promise<void>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<SessionUser | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setUnauthorizedHandler(() => setUser(null));
    api.get<{ user: SessionUser }>('/auth/me')
      .then((r) => setUser(r.user))
      .catch((e) => { if (!(e instanceof ApiError && e.status === 401)) console.error(e); })
      .finally(() => setLoading(false));
    return () => setUnauthorizedHandler(null);
  }, []);

  const login = useCallback(async (email: string, password: string) => {
    const r = await api.post<{ user: SessionUser }>('/auth/login', { email, password });
    setUser(r.user);
  }, []);
  const registerStore = useCallback<AuthContextValue['registerStore']>(async (input) => {
    setUser((await api.post<{ user: SessionUser }>('/auth/register', input)).user);
  }, []);
  const registerCustomer = useCallback<AuthContextValue['registerCustomer']>(async (input) => {
    setUser((await api.post<{ user: SessionUser }>('/auth/register-customer', input)).user);
  }, []);
  const signOut = useCallback(async () => {
    try { await api.post('/auth/logout'); } finally { setUser(null); }
  }, []);

  const value = useMemo<AuthContextValue>(() => ({
    user, role: user?.role ?? null, displayName: user?.display_name ?? '', loading, login, registerStore, registerCustomer, signOut,
  }), [user, loading, login, registerStore, registerCustomer, signOut]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
