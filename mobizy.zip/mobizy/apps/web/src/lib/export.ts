export interface ExportColumn {
  header: string;
  key: string;
  width?: number;
}

type CellValue = string | number | null;

function escapeCSVCell(val: CellValue): string {
  if (val === null || val === undefined) return '';
  const str = String(val);
  if (str.includes(',') || str.includes('"') || str.includes('\n')) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

export function exportToCSV(
  filename: string,
  columns: ExportColumn[],
  rows: Record<string, CellValue>[],
): void {
  const headerLine = columns.map((c) => escapeCSVCell(c.header)).join(',');
  const dataLines = rows.map((row) =>
    columns.map((c) => escapeCSVCell(row[c.key] ?? '')).join(','),
  );
  const csv = '\uFEFF' + [headerLine, ...dataLines].join('\n');
  downloadBlob(csv, 'text/csv;charset=utf-8;', withExt(filename, '.csv'));
}

interface ExcelSheet {
  title: string;
  subtitle?: string;
  columns: ExportColumn[];
  rows: Record<string, CellValue>[];
  summaryRows?: { label: string; value: number }[];
}

export function exportToExcel(
  filename: string,
  sheets: ExcelSheet[],
): void {
  const styleHeader = 'font-weight:bold;background-color:#0d9488;color:#FFFFFF;border:1px solid #0a7c6f;font-size:11pt;';
  const styleTitle = 'font-weight:bold;font-size:14pt;color:#1e293b;';
  const styleSubtitle = 'font-size:10pt;color:#64748b;';
  const styleCell = 'border:1px solid #e2e8f0;font-size:10pt;';
  const styleNumber = 'border:1px solid #e2e8f0;font-size:10pt;text-align:right;mso-number-format:"#,##0";';
  const styleTotal = 'font-weight:bold;border:1px solid #94a3b8;background-color:#f1f5f9;font-size:10pt;';
  const styleTotalNum = 'font-weight:bold;border:1px solid #94a3b8;background-color:#f1f5f9;font-size:10pt;text-align:right;mso-number-format:"#,##0";';

  const sheetsXml = sheets.map((sheet, idx) => {
    const colSpec = sheet.columns
      .map((c) => `<Column ss:Width="${Math.round((c.width || 120) * 0.75)}"/>`)
      .join('');

    const headerCells = sheet.columns
      .map((c) => `<Cell ss:StyleID="header"><Data ss:Type="String">${escapeXml(c.header)}</Data></Cell>`)
      .join('');

    const totalCols = sheet.columns.length;

    const titleRow = `<Row><Cell ss:MergeAcross="${totalCols - 1}" ss:StyleID="title"><Data ss:Type="String">${escapeXml(sheet.title)}</Data></Cell></Row>`;
    const subtitleRow = sheet.subtitle
      ? `<Row><Cell ss:MergeAcross="${totalCols - 1}" ss:StyleID="subtitle"><Data ss:Type="String">${escapeXml(sheet.subtitle)}</Data></Cell></Row>`
      : '';
    const blankRow = `<Row><Cell ss:MergeAcross="${totalCols - 1}"><Data ss:Type="String"></Data></Cell></Row>`;
    const headerRow = `<Row>${headerCells}</Row>`;

    const dataRows = sheet.rows.map((row) => {
      const cells = sheet.columns.map((c) => {
        const val = row[c.key];
        if (val === null || val === undefined || val === '') {
          return `<Cell ss:StyleID="cell"><Data ss:Type="String"></Data></Cell>`;
        }
        if (typeof val === 'number') {
          return `<Cell ss:StyleID="number"><Data ss:Type="Number">${val}</Data></Cell>`;
        }
        const numCheck = String(val).replace(/[.,\s]/g, '');
        if (/^\d+$/.test(numCheck) && String(val).match(/\d/)) {
          return `<Cell ss:StyleID="cell"><Data ss:Type="String">${escapeXml(String(val))}</Data></Cell>`;
        }
        return `<Cell ss:StyleID="cell"><Data ss:Type="String">${escapeXml(String(val))}</Data></Cell>`;
      }).join('');
      return `<Row>${cells}</Row>`;
    }).join('');

    const summaryRows = (sheet.summaryRows || []).map((s) => {
      const labelCell = `<Cell ss:MergeAcross="${totalCols - 2}" ss:StyleID="total"><Data ss:Type="String">${escapeXml(s.label)}</Data></Cell>`;
      const valueCell = `<Cell ss:StyleID="totalNum"><Data ss:Type="Number">${s.value}</Data></Cell>`;
      return `<Row>${labelCell}${valueCell}</Row>`;
    }).join('');

    return `<Worksheet ss:Name="${escapeXml(sheet.title.substring(0, 31))}"><Table>${colSpec}${titleRow}${subtitleRow}${blankRow}${headerRow}${dataRows}${summaryRows}</Table></Worksheet>`;
  }).join('');

  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:o="urn:schemas-microsoft-com:office:office"
 xmlns:x="urn:schemas-microsoft-com:office:excel"
 xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:html="http://www.w3.org/TR/REC-html40">
 <Styles>
  <Style ss:ID="title"><Font ss:Bold="1" ss:Size="14" ss:Color="#1E293B"/></Style>
  <Style ss:ID="subtitle"><Font ss:Size="10" ss:Color="#64748B"/></Style>
  <Style ss:ID="header"><Borders><Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#0A7C6F"/></Borders><Font ss:Bold="1" ss:Color="#FFFFFF" ss:Size="11"/><Interior ss:Color="#0D9488" ss:Pattern="Solid"/></Style>
  <Style ss:ID="cell"><Borders><Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#E2E8F0"/></Borders><Font ss:Size="10"/></Style>
  <Style ss:ID="number"><Alignment ss:Horizontal="Right"/><Borders><Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#E2E8F0"/></Borders><Font ss:Size="10"/><NumberFormat ss:Format="#,##0"/></Style>
  <Style ss:ID="total"><Borders><Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#94A3B8"/></Borders><Font ss:Bold="1" ss:Size="10"/><Interior ss:Color="#F1F5F9" ss:Pattern="Solid"/></Style>
  <Style ss:ID="totalNum"><Alignment ss:Horizontal="Right"/><Borders><Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#94A3B8"/></Borders><Font ss:Bold="1" ss:Size="10"/><Interior ss:Color="#F1F5F9" ss:Pattern="Solid"/><NumberFormat ss:Format="#,##0"/></Style>
 </Styles>
 ${sheetsXml}
</Workbook>`;

  downloadBlob(xml, 'application/vnd.ms-excel;charset=utf-8;', withExt(filename, '.xls'));
}

function escapeXml(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

function downloadBlob(content: string, mimeType: string, filename: string): void {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

function withExt(name: string, ext: string): string {
  return name.toLowerCase().endsWith(ext) ? name : name + ext;
}
