// Small vibration on tap. Works on Android browsers; iPhone Safari ignores it. Respects reduced-motion.
const reduced = () => typeof window !== 'undefined' && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;

export function haptic(pattern: number | number[] = 10): void {
  try {
    if (reduced()) return;
    navigator.vibrate?.(pattern);
  } catch {
    // vibration is optional; never break a sale because of it
  }
}

export const hapticSuccess = () => haptic([18, 40, 18]);
