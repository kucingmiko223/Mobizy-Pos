export function formatCurrency(amount: number, symbol: string = 'Rp'): string {
  const rounded = Math.round(amount);
  return `${symbol} ${rounded.toLocaleString('id-ID')}`;
}

export function formatCurrencyDetailed(amount: number, symbol: string = 'Rp'): string {
  return `${symbol} ${amount.toLocaleString('id-ID', { minimumFractionDigits: 0, maximumFractionDigits: 2 })}`;
}

export function formatDateTime(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleString('id-ID', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
    hour12: false,
  });
}

export function formatTime(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleTimeString('id-ID', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  });
}

export function formatDate(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleDateString('id-ID', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
}

export function formatHour(hour: number): string {
  return `${hour.toString().padStart(2, '0')}:00`;
}
