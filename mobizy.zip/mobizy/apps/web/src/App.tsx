import { useState } from 'react';
import {
  Store,
  ShoppingCart,
  Receipt,
  LayoutDashboard,
  Package,
  Settings,
  BarChart3,
  MessageSquare,
  TicketPercent,
  Calculator,
  LogOut,
  Shield,
  Users,
  User as UserIcon,
} from 'lucide-react';
import { AuthProvider, useAuth } from '@/context/AuthContext';
import { StoreProvider, useStore } from '@/context/StoreContext';
import { LoginScreen } from '@/features/auth/LoginScreen';
import { CashierScreen } from '@/features/pos/CashierScreen';
import { CartPanel } from '@/features/pos/CartPanel';
import { CheckoutModal } from '@/features/pos/CheckoutModal';
import { ReceiptModal } from '@/features/pos/ReceiptModal';
import { OrderHistory } from '@/features/orders/OrderHistory';
import { Dashboard } from '@/features/dashboard/Dashboard';
import { Analytics } from '@/features/analytics/Analytics';
import { Comments } from '@/features/comments/Comments';
import { ProductManagement } from '@/features/products/ProductManagement';
import { SettingsView } from '@/features/settings/SettingsView';
import { VoucherManagement } from '@/features/vouchers/VoucherManagement';
import { Accounting } from '@/features/accounting/Accounting';
import { TeamManagement } from '@/features/team/TeamManagement';
import { RevenueDetail } from '@/features/orders/RevenueDetail';
import { MobizyLogo } from '@/components/ui/MobizyLogo';
import { formatCurrency } from '@/lib/format';
import type { ViewType, Order, OrderItem, UserRole } from '@/types';

interface NavItem {
  id: ViewType;
  label: string;
  icon: typeof Store;
  group: string;
  roles: UserRole[];
  desc: string;
}

const navItems: NavItem[] = [
  { id: 'cashier', label: 'Kasir', icon: ShoppingCart, group: 'sales', roles: ['owner', 'admin', 'cashier', 'customer'], desc: 'Transaksi & checkout' },
  { id: 'orders', label: 'Pesanan', icon: Receipt, group: 'sales', roles: ['owner', 'admin', 'cashier'], desc: 'Riwayat & koreksi tagihan' },
  { id: 'dashboard', label: 'Dasbor', icon: LayoutDashboard, group: 'reports', roles: ['owner', 'admin', 'cashier'], desc: 'Ringkasan penjualan harian' },
  { id: 'analytics', label: 'Analitik', icon: BarChart3, group: 'reports', roles: ['owner', 'admin'], desc: 'Grafik & tren produk' },
  { id: 'accounting', label: 'Akuntansi', icon: Calculator, group: 'reports', roles: ['owner', 'admin'], desc: 'Pengeluaran & laba rugi' },
  { id: 'vouchers', label: 'Voucher', icon: TicketPercent, group: 'catalog', roles: ['owner', 'admin'], desc: 'Diskon & promo Beli 1 Gratis 1' },
  { id: 'comments', label: 'Ulasan', icon: MessageSquare, group: 'catalog', roles: ['owner', 'admin', 'cashier', 'customer'], desc: 'Feedback dari pelanggan' },
  { id: 'products', label: 'Produk', icon: Package, group: 'catalog', roles: ['owner', 'admin'], desc: 'Kelola katalog & stok' },
  { id: 'team', label: 'Tim', icon: Users, group: 'admin', roles: ['owner', 'admin'], desc: 'Akun kasir & admin' },
  { id: 'settings', label: 'Pengaturan', icon: Settings, group: 'admin', roles: ['owner', 'admin'], desc: 'Pajak, mata uang, QRIS' },
];

const groupLabels: Record<string, string> = {
  sales: 'Penjualan',
  reports: 'Laporan',
  catalog: 'Katalog',
  admin: 'Administrasi',
};

function AppContent() {
  const { role, displayName, signOut } = useAuth();
  const { settings, cartCount, cartSubtotal, loading } = useStore();
  const [view, setView] = useState<ViewType>('cashier');
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [cartDrawerOpen, setCartDrawerOpen] = useState(false);
  const [receiptOrder, setReceiptOrder] = useState<Order | null>(null);
  const [receiptItems, setReceiptItems] = useState<OrderItem[]>([]);
  const [receiptOpen, setReceiptOpen] = useState(false);
  const [showRevenueDetail, setShowRevenueDetail] = useState(false);

  const symbol = settings?.currency_symbol || 'Rp';
  const taxRate = settings?.tax_rate || 0;
  const cartTotal = cartSubtotal + cartSubtotal * taxRate;

  const handleCheckoutComplete = (order: Order, items: OrderItem[]) => {
    setCheckoutOpen(false);
    setCartDrawerOpen(false);
    setReceiptOrder(order);
    setReceiptItems(items);
    setReceiptOpen(true);
  };

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center bg-slate-100">
        <div className="flex flex-col items-center gap-3">
          <MobizyLogo size="lg" />
          <div className="h-1 w-24 overflow-hidden rounded-full bg-slate-200">
            <div className="h-full w-1/2 animate-pulse rounded-full bg-blue-600" />
          </div>
          <p className="text-sm font-medium text-slate-500">Memuat MobizyPOS...</p>
        </div>
      </div>
    );
  }

  const userRole = role || 'cashier';
  const isManager = userRole === 'owner' || userRole === 'admin';
  const isCustomer = userRole === 'customer';
  const visibleNavItems = navItems
    .filter((item) => item.roles.includes(userRole))
    // customers can browse the menu but not ring up sales
    .map((item) => (isCustomer && item.id === 'cashier' ? { ...item, label: 'Menu', desc: 'Lihat daftar produk' } : item));
  const groups = ['sales', 'reports', 'catalog', 'admin'];

  return (
    <div className="flex h-screen flex-col overflow-hidden bg-slate-100 lg:flex-row">
      {/* Desktop sidebar */}
      <aside className="hidden flex-col border-r border-slate-200 bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900 py-4 lg:flex lg:w-72">
        <div className="mb-6 flex items-center gap-3 px-5">
          <MobizyLogo size="md" />
          <div>
            <p className="text-base font-bold text-white">MobizyPOS</p>
            <p className="text-xs text-slate-400">Satu untuk semua UMKM</p>
          </div>
        </div>

        <nav className="flex flex-1 flex-col gap-1 overflow-y-auto px-3">
          {groups.map((group) => {
            const groupItems = visibleNavItems.filter((item) => item.group === group);
            if (groupItems.length === 0) return null;
            return (
              <div key={group} className="mb-2">
                <p className="mb-1.5 px-3 text-[10px] font-bold uppercase tracking-wider text-slate-500">{groupLabels[group]}</p>
                {groupItems.map((item) => {
                  const Icon = item.icon;
                  const isActive = view === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => setView(item.id)}
                      className={`group relative mb-1 flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left transition-all ${
                        isActive
                          ? 'bg-blue-600 text-white shadow-md'
                          : 'text-slate-400 hover:bg-slate-800/80 hover:text-slate-200'
                      }`}
                    >
                      {isActive && <div className="absolute left-0 h-full w-1 rounded-r-full bg-blue-400" />}
                      <div className="relative flex-shrink-0">
                        <Icon
                          className={`h-5 w-5 transition-all ${isActive ? 'scale-110 text-white' : 'text-slate-500 group-hover:text-slate-300'}`}
                          strokeWidth={1.5}
                        />
                        {item.id === 'cashier' && cartCount > 0 && (
                          <span key={cartCount} className="absolute -right-2 -top-2 flex h-4 min-w-4 items-center justify-center rounded-full bg-amber-400 px-1 text-xs font-bold text-slate-900 animate-bounce-in">
                            {cartCount}
                          </span>
                        )}
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className={`text-sm font-semibold ${isActive ? 'text-white' : 'text-slate-300 group-hover:text-slate-100'}`}>
                          {item.label}
                        </p>
                        <p className={`truncate text-[11px] leading-tight ${isActive ? 'text-blue-200' : 'text-slate-500'}`}>
                          {item.desc}
                        </p>
                      </div>
                    </button>
                  );
                })}
              </div>
            );
          })}
        </nav>

        {/* User info & logout */}
        <div className="border-t border-slate-800 px-3 pt-3">
          <div className="mb-2 flex items-center gap-2.5 rounded-xl bg-slate-800/50 px-3 py-2.5">
            <div className={`flex h-9 w-9 items-center justify-center rounded-lg ${isManager ? 'bg-blue-500/20' : userRole === 'customer' ? 'bg-teal-500/20' : 'bg-slate-600'}`}>
              {isManager ? <Shield className="h-4 w-4 text-blue-400" /> : userRole === 'customer' ? <ShoppingCart className="h-4 w-4 text-teal-400" /> : <UserIcon className="h-4 w-4 text-slate-300" />}
            </div>
            <div className="min-w-0 flex-1">
              <p className="truncate text-xs font-semibold text-white">{displayName}</p>
              <p className="text-[10px] capitalize text-slate-400">{userRole}</p>
            </div>
            <button
              onClick={() => signOut()}
              className="rounded-lg p-1.5 text-slate-400 transition hover:bg-slate-700 hover:text-white"
              title="Keluar"
            >
              <LogOut className="h-4 w-4" />
            </button>
          </div>
          <p className="px-3 text-[10px] text-slate-600">MobizyPOS</p>
        </div>
      </aside>

      {/* Main content area */}
      <div className="flex flex-1 flex-col overflow-hidden">
        {/* Mobile top bar */}
        <div className="flex items-center justify-between border-b border-slate-200 bg-gradient-to-r from-slate-900 to-slate-800 px-4 py-2.5 lg:hidden">
          <div className="flex items-center gap-2">
            <MobizyLogo size="sm" />
            <span className="text-sm font-bold text-white">MobizyPOS</span>
          </div>
          <div className="flex items-center gap-2">
            <span className={`flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-medium ${isManager ? 'bg-blue-500/20 text-blue-300' : userRole === 'customer' ? 'bg-teal-500/20 text-teal-300' : 'bg-slate-700 text-slate-300'}`}>
              {isManager ? <Shield className="h-3 w-3" /> : userRole === 'customer' ? <ShoppingCart className="h-3 w-3" /> : <UserIcon className="h-3 w-3" />}
              {userRole}
            </span>
            <button
              onClick={() => signOut()}
              className="rounded-lg p-1 text-slate-400 transition hover:bg-slate-700 hover:text-white"
            >
              <LogOut className="h-4 w-4" />
            </button>
          </div>
        </div>

        <main className="flex flex-1 overflow-hidden">
          {view === 'cashier' && (
            <>
              <CashierScreen readOnly={isCustomer} />
              {!isCustomer && (
                <div className="hidden w-80 flex-col border-l border-slate-200 bg-white xl:flex xl:w-96">
                  <CartPanel onCheckout={() => setCheckoutOpen(true)} />
                </div>
              )}
              {!isCustomer && cartCount > 0 && (
                <button
                  onClick={() => setCartDrawerOpen(true)}
                  className="fixed bottom-16 left-3 right-3 z-30 flex items-center justify-between rounded-2xl bg-blue-600 px-4 py-3 text-white shadow-xl transition active:scale-[0.98] animate-slide-in-up lg:hidden"
                >
                  <span className="flex items-center gap-2">
                    <ShoppingCart className="h-5 w-5" />
                    <span key={cartCount} className="rounded-full bg-white/20 px-2 py-0.5 text-xs font-bold animate-bounce-in">{cartCount}</span>
                  </span>
                  <span className="text-sm font-bold">Lihat Keranjang · {formatCurrency(cartTotal, symbol)}</span>
                </button>
              )}
            </>
          )}
          {view === 'orders' && <OrderHistory />}
          {view === 'analytics' && isManager && <Analytics />}
          {view === 'accounting' && isManager && (
            showRevenueDetail
              ? <RevenueDetail onBack={() => setShowRevenueDetail(false)} />
              : <Accounting onShowRevenueDetail={() => setShowRevenueDetail(true)} />
          )}
          {view === 'vouchers' && isManager && <VoucherManagement />}
          {view === 'comments' && <Comments role={userRole} />}
          {view === 'dashboard' && (
            showRevenueDetail
              ? <RevenueDetail onBack={() => setShowRevenueDetail(false)} />
              : <Dashboard onShowRevenueDetail={() => setShowRevenueDetail(true)} />
          )}
          {view === 'products' && isManager && <ProductManagement />}
          {view === 'settings' && isManager && <SettingsView />}
          {view === 'team' && isManager && <TeamManagement />}
        </main>

        {/* Mobile bottom navigation */}
        <nav className="flex items-center justify-around overflow-x-auto border-t border-slate-200 bg-white px-1 py-1.5 lg:hidden">
          {visibleNavItems.map((item) => {
            const Icon = item.icon;
            const isActive = view === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setView(item.id)}
                title={item.desc}
                className={`flex flex-1 flex-col items-center gap-0.5 whitespace-nowrap rounded-lg py-1.5 transition ${
                  isActive ? 'text-blue-600' : 'text-slate-400'
                }`}
              >
                <div className="relative">
                  <Icon
                    className={`h-5 w-5 transition-transform ${isActive ? 'scale-110' : ''}`}
                    strokeWidth={1.5}
                  />
                  {item.id === 'cashier' && cartCount > 0 && (
                    <span key={cartCount} className="absolute -right-2 -top-2 flex h-4 min-w-4 items-center justify-center rounded-full bg-amber-400 px-1 text-xs font-bold text-slate-900 animate-bounce-in">
                      {cartCount}
                    </span>
                  )}
                </div>
                <span className="text-[10px] font-medium">{item.label}</span>
              </button>
            );
          })}
        </nav>
      </div>

      {/* Mobile cart drawer */}
      {cartDrawerOpen && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div className="absolute inset-0 bg-slate-900/50 backdrop-blur-sm animate-fade-in" onClick={() => setCartDrawerOpen(false)} />
          <div className="absolute bottom-0 left-0 right-0 max-h-[85vh] rounded-t-2xl bg-white shadow-2xl animate-slide-in-up">
            <div className="flex justify-center pt-2">
              <div className="h-1 w-10 rounded-full bg-slate-300" />
            </div>
            <CartPanel onCheckout={() => setCheckoutOpen(true)} onClose={() => setCartDrawerOpen(false)} />
          </div>
        </div>
      )}

      {/* Modals */}
      <CheckoutModal open={checkoutOpen} onClose={() => setCheckoutOpen(false)} onComplete={handleCheckoutComplete} />
      <ReceiptModal open={receiptOpen} order={receiptOrder} items={receiptItems} onClose={() => setReceiptOpen(false)} />
    </div>
  );
}

function AppInner() {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center bg-slate-100">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-blue-500/30 border-t-blue-500" />
      </div>
    );
  }

  if (!user) {
    return <LoginScreen />;
  }

  return (
    <StoreProvider key={user.id}>
      <AppContent />
    </StoreProvider>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppInner />
    </AuthProvider>
  );
}

export default App;
