type LogoSize = 'sm' | 'md' | 'lg' | 'xl';

const sizeMap: Record<LogoSize, { svg: string }> = {
  sm: { svg: 'h-7 w-7' },
  md: { svg: 'h-9 w-9' },
  lg: { svg: 'h-12 w-12' },
  xl: { svg: 'h-16 w-16' },
};

export function MobizyLogo({ size = 'md', className = '' }: { size?: LogoSize; className?: string }) {
  const s = sizeMap[size];
  return (
    <svg
      viewBox="0 0 48 48"
      fill="none"
      className={`${s.svg} ${className}`}
      aria-label="MobizyPOS"
    >
      <defs>
        <linearGradient id="mobizy-stroke" x1="0" y1="0" x2="48" y2="48" gradientUnits="userSpaceOnUse">
          <stop stopColor="#3B82F6" />
          <stop offset="1" stopColor="#1D4ED8" />
        </linearGradient>
      </defs>
      {/* Left leg of M */}
      <path d="M8 40 L8 10 L24 28 L40 10 L40 40" stroke="url(#mobizy-stroke)" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" />
      {/* Cash accent — a horizontal line through the middle suggesting a banknote band */}
      <path d="M12 34 L36 34" stroke="#F59E0B" strokeWidth="2.5" strokeLinecap="round" opacity="0.8" />
      {/* Small dot accent at center bottom — abstract coin */}
      <circle cx="24" cy="40" r="2.5" fill="#F59E0B" />
    </svg>
  );
}
