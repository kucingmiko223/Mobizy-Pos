import { useEffect, useState, useMemo } from 'react';
import {
  TrendingUp, TrendingDown,
  BarChart3,
  Package, Clock, CreditCard, Banknote, Smartphone, Building,
  Star, Receipt, Wallet, Percent, Tags,
  QrCode, ArrowUpRight, ArrowDownRight, Trophy, Flame,
} from 'lucide-react';
import { api } from '@/lib/api';
import type { Order, OrderItem, Comment, Product, Category } from '@/types';
import { useStore } from '@/context/StoreContext';
import { formatCurrency, formatHour } from '@/lib/format';

interface ProductStat {
  name: string;
  qty: number;
  revenue: number;
  cost: number;
  profit: number;
  margin: number;
  avgRating: number;
  reviewCount: number;
}

interface CategoryStat {
  name: string;
  qty: number;
  revenue: number;
  profit: number;
}

interface HourlyStat {
  hour: number;
  revenue: number;
  count: number;
}

interface PaymentStat {
  method: string;
  count: number;
  revenue: number;
}

interface ReviewTrendDay {
  label: string;
  revenue: number;
  avgRating: number;
  reviewCount: number;
}

type DateRange = 'today' | '7d' | '30d' | 'all';

function smoothPath(points: { x: number; y: number }[]): string {
  if (points.length < 2) return '';
  let path = `M ${points[0].x} ${points[0].y}`;
  for (let i = 0; i < points.length - 1; i++) {
    const p0 = points[i];
    const p1 = points[i + 1];
    const cpX = (p0.x + p1.x) / 2;
    path += ` C ${cpX} ${p0.y} ${cpX} ${p1.y} ${p1.x} ${p1.y}`;
  }
  return path;
}

export function Analytics() {
  const { settings } = useStore();
  const [loading, setLoading] = useState(true);
  const [productStats, setProductStats] = useState<ProductStat[]>([]);
  const [categoryStats, setCategoryStats] = useState<CategoryStat[]>([]);
  const [hourlyStats, setHourlyStats] = useState<HourlyStat[]>([]);
  const [paymentStats, setPaymentStats] = useState<PaymentStat[]>([]);
  const [reviewTrend, setReviewTrend] = useState<ReviewTrendDay[]>([]);
  const [sentimentData, setSentimentData] = useState({ positive: 0, neutral: 0, negative: 0, avgRating: 0, total: 0, starCounts: [0, 0, 0, 0, 0] });
  const [totalRevenue, setTotalRevenue] = useState(0);
  const [totalProfit, setTotalProfit] = useState(0);
  const [totalItems, setTotalItems] = useState(0);
  const [totalOrders, setTotalOrders] = useState(0);
  const [totalDiscount, setTotalDiscount] = useState(0);
  const [avgOrderValue, setAvgOrderValue] = useState(0);
  const [dateRange, setDateRange] = useState<DateRange>('30d');

  const symbol = settings?.currency_symbol || 'Rp';

  const dateFilter = useMemo(() => {
    if (dateRange === 'all') return null;
    const now = new Date();
    if (dateRange === 'today') {
      const start = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      return start.toISOString();
    }
    const days = dateRange === '7d' ? 7 : 30;
    now.setDate(now.getDate() - days);
    return now.toISOString();
  }, [dateRange]);

  useEffect(() => {
    (async () => {
      setLoading(true);

      const from = dateFilter ?? undefined;
      let orders: Order[];
      try {
        orders = await api.get<Order[]>('/orders', { from, limit: 2000 });
      } catch (e) {
        console.error(e);
        setLoading(false);
        return;
      }

      const validOrders = orders.filter((o) => o.correction_type === 'none' || !o.correction_type);
      const orderIds = validOrders.map((o) => o.id);

      const comments = await api.get<Comment[]>('/comments', { from }).catch(() => [] as Comment[]);

      const allComments = comments || [];
      const positive = allComments.filter((c) => c.rating >= 4).length;
      const neutral = allComments.filter((c) => c.rating === 3).length;
      const negative = allComments.filter((c) => c.rating <= 2).length;
      const avgR = allComments.length > 0 ? allComments.reduce((s, c) => s + c.rating, 0) / allComments.length : 0;
      const starCounts = [0, 0, 0, 0, 0];
      for (const c of allComments) {
        const idx = Math.min(Math.max(Math.floor(c.rating), 1), 5) - 1;
        starCounts[idx]++;
      }
      setSentimentData({ positive, neutral, negative, avgRating: avgR, total: allComments.length, starCounts });

      const now = new Date();
      const trend: ReviewTrendDay[] = [];
      for (let i = 6; i >= 0; i--) {
        const dayStart = new Date(now);
        dayStart.setDate(dayStart.getDate() - i);
        dayStart.setHours(0, 0, 0, 0);
        const dayEnd = new Date(dayStart);
        dayEnd.setDate(dayEnd.getDate() + 1);
        const dayOrders = validOrders.filter((o) => { const d = new Date(o.created_at); return d >= dayStart && d < dayEnd; });
        const dayRev = dayOrders.reduce((s, o) => s + Number(o.total), 0);
        const dayComments = allComments.filter((c) => { const d = new Date(c.created_at); return d >= dayStart && d < dayEnd; });
        const dayAvgR = dayComments.length > 0 ? dayComments.reduce((s, c) => s + c.rating, 0) / dayComments.length : 0;
        trend.push({
          label: dayStart.toLocaleDateString('id-ID', { weekday: 'short' }),
          revenue: dayRev,
          avgRating: dayAvgR,
          reviewCount: dayComments.length,
        });
      }
      setReviewTrend(trend);

      if (orderIds.length === 0) {
        setProductStats([]); setCategoryStats([]); setHourlyStats([]); setPaymentStats([]);
        setTotalRevenue(0); setTotalProfit(0); setTotalItems(0); setTotalOrders(0);
        setTotalDiscount(0); setAvgOrderValue(0); setLoading(false); return;
      }

      let items: OrderItem[];
      try {
        const validIds = new Set(orderIds);
        items = (await api.get<OrderItem[]>('/orders/items', { from })).filter((i) => validIds.has(i.order_id));
      } catch (e) {
        console.error(e);
        setLoading(false);
        return;
      }

      // include inactive products so old sales still resolve their cost and category
      const products = await api.get<Product[]>('/products', { include_inactive: 1 }).catch(() => null);
      const categories = await api.get<Category[]>('/categories').catch(() => null);

      const productReviews: Record<string, { ratings: number[]; count: number }> = {};
      for (const c of allComments) {
        if (c.product_id) {
          if (!productReviews[c.product_id]) productReviews[c.product_id] = { ratings: [], count: 0 };
          productReviews[c.product_id].ratings.push(c.rating);
          productReviews[c.product_id].count++;
        }
      }

      const costMap: Record<string, number> = {};
      if (products) for (const p of products) costMap[p.id] = Number(p.cost);
      const prodToCat: Record<string, string> = {};
      if (products) for (const p of products) if (p.category_id) prodToCat[p.id] = p.category_id;
      const catNameMap: Record<string, string> = {};
      if (categories) for (const c of categories) catNameMap[c.id] = c.name;

      const stats: Record<string, ProductStat> = {};
      let revenue = 0, itemsSold = 0, totalCost = 0;

      for (const item of items) {
        const name = item.product_name;
        if (!stats[name]) stats[name] = { name, qty: 0, revenue: 0, cost: 0, profit: 0, margin: 0, avgRating: 0, reviewCount: 0 };
        stats[name].qty += item.quantity;
        stats[name].revenue += Number(item.subtotal);
        revenue += Number(item.subtotal);
        itemsSold += item.quantity;
        if (item.product_id && costMap[item.product_id] !== undefined) {
          const c = costMap[item.product_id] * item.quantity;
          stats[name].cost += c;
          totalCost += c;
        }
        if (item.product_id && productReviews[item.product_id]) {
          const pr = productReviews[item.product_id];
          stats[name].avgRating = pr.ratings.reduce((s, r) => s + r, 0) / pr.ratings.length;
          stats[name].reviewCount = pr.count;
        }
      }

      for (const key of Object.keys(stats)) {
        const s = stats[key];
        s.profit = s.revenue - s.cost;
        s.margin = s.revenue > 0 ? (s.profit / s.revenue) * 100 : 0;
      }

      const catStats: Record<string, CategoryStat> = {};
      for (const item of items) {
        if (item.product_id && prodToCat[item.product_id]) {
          const catName = catNameMap[prodToCat[item.product_id]];
          if (!catName) continue;
          if (!catStats[catName]) catStats[catName] = { name: catName, qty: 0, revenue: 0, profit: 0 };
          catStats[catName].qty += item.quantity;
          catStats[catName].revenue += Number(item.subtotal);
          if (item.product_id && costMap[item.product_id] !== undefined) {
            catStats[catName].profit += Number(item.subtotal) - costMap[item.product_id] * item.quantity;
          }
        }
      }

      const hourly: Record<number, HourlyStat> = {};
      for (let h = 0; h < 24; h++) hourly[h] = { hour: h, revenue: 0, count: 0 };
      for (const order of validOrders) {
        const h = new Date(order.created_at).getHours();
        hourly[h].revenue += Number(order.total);
        hourly[h].count += 1;
      }

      const payments: Record<string, PaymentStat> = {};
      for (const order of validOrders) {
        const m = order.payment_method;
        if (!payments[m]) payments[m] = { method: m, count: 0, revenue: 0 };
        payments[m].count += 1;
        payments[m].revenue += Number(order.total);
      }

      const totalDisc = validOrders.reduce((s, o) => s + Number(o.discount_amount || o.discount || 0), 0);
      const totalRev = validOrders.reduce((s, o) => s + Number(o.total), 0);

      const sorted = Object.values(stats).sort((a, b) => b.qty - a.qty);
      setProductStats(sorted);
      setCategoryStats(Object.values(catStats).sort((a, b) => b.revenue - a.revenue));
      setHourlyStats(Object.values(hourly));
      setPaymentStats(Object.values(payments).sort((a, b) => b.revenue - a.revenue));
      setTotalRevenue(totalRev);
      setTotalItems(itemsSold);
      setTotalOrders(validOrders.length);
      setTotalDiscount(totalDisc);
      setAvgOrderValue(validOrders.length > 0 ? totalRev / validOrders.length : 0);
      setTotalProfit(totalRev - totalCost);
      setLoading(false);
    })();
  }, [dateFilter]);

  if (loading) {
    return (
      <div className="flex flex-1 items-center justify-center text-slate-400">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-teal-500/30 border-t-teal-500" />
      </div>
    );
  }

  const bestSellers = productStats.slice(0, 5);
  const worstSellers = productStats.length > 5 ? productStats.slice(-5).reverse() : [];
  const maxQty = Math.max(...productStats.map((p) => p.qty), 1);
  const maxCatRevenue = Math.max(...categoryStats.map((c) => c.revenue), 1);
  const maxHourRevenue = Math.max(...hourlyStats.map((h) => h.revenue), 1);
  const activeHours = hourlyStats.filter((h) => h.count > 0);
  const peakHour = activeHours.length > 0 ? activeHours.reduce((max, h) => h.revenue > max.revenue ? h : max) : null;
  const maxTrendRevenue = Math.max(...reviewTrend.map((d) => d.revenue), 1);

  const rangeLabels: { id: DateRange; label: string }[] = [
    { id: 'today', label: 'Hari Ini' },
    { id: '7d', label: '7 Hari' },
    { id: '30d', label: '30 Hari' },
    { id: 'all', label: 'Semua' },
  ];

  const paymentIcons: Record<string, typeof Banknote> = {
    cash: Banknote, card: CreditCard, qris: QrCode, transfer: Building, mobile: Smartphone,
  };
  const paymentColors: Record<string, string> = {
    cash: '#0d9488', card: '#2563eb', qris: '#0891b2', transfer: '#d97706', mobile: '#06b6d4',
  };

  const summaryCards = [
    { label: 'Total Pendapatan', value: formatCurrency(totalRevenue, symbol), icon: Wallet },
    { label: 'Total Keuntungan', value: formatCurrency(totalProfit, symbol), icon: TrendingUp },
    { label: 'Item Terjual', value: totalItems.toLocaleString('id-ID'), icon: Package },
    { label: 'Total Pesanan', value: totalOrders.toLocaleString('id-ID'), icon: Receipt },
    { label: 'Rata-rata/Pesanan', value: formatCurrency(avgOrderValue, symbol), icon: Tags },
    { label: 'Total Diskon', value: formatCurrency(totalDiscount, symbol), icon: Percent },
  ];

  const sentimentTotal = sentimentData.total || 1;
  const maxStarCount = Math.max(...sentimentData.starCounts, 1);

  const gaugeRadius = 52;
  const gaugeCircumference = 2 * Math.PI * gaugeRadius;
  const gaugePct = sentimentData.avgRating / 5;
  const gaugeOffset = gaugeCircumference * (1 - gaugePct);

  const donutSegments = paymentStats.map((p, i) => {
    const pct = totalOrders > 0 ? (p.count / totalOrders) * 100 : 0;
    return { ...p, pct };
  });
  let cumulativePct = 0;
  const donutPaths = donutSegments.map((seg) => {
    const startAngle = (cumulativePct / 100) * 360;
    cumulativePct += seg.pct;
    const endAngle = (cumulativePct / 100) * 360;
    const largeArc = seg.pct > 50 ? 1 : 0;
    const r = 60;
    const cx = 80, cy = 80;
    const startX = cx + r * Math.cos((startAngle - 90) * Math.PI / 180);
    const startY = cy + r * Math.sin((startAngle - 90) * Math.PI / 180);
    const endX = cx + r * Math.cos((endAngle - 90) * Math.PI / 180);
    const endY = cy + r * Math.sin((endAngle - 90) * Math.PI / 180);
    return {
      d: `M ${cx} ${cy} L ${startX} ${startY} A ${r} ${r} 0 ${largeArc} 1 ${endX} ${endY} Z`,
      color: paymentColors[seg.method] || '#64748b',
      method: seg.method,
      pct: seg.pct,
      count: seg.count,
      revenue: seg.revenue,
    };
  });

  // Trading-style trend chart
  const trendW = 100;
  const trendH = 100;
  const trendPadding = 8;
  const trendPoints = reviewTrend.map((d, i) => ({
    x: (i / (reviewTrend.length - 1)) * trendW,
    y: trendH - trendPadding - (d.revenue / maxTrendRevenue) * (trendH - trendPadding * 2),
    ...d,
  }));
  const trendLinePath = smoothPath(trendPoints);
  const trendAreaPath = `${trendLinePath} L ${trendW} ${trendH} L 0 ${trendH} Z`;

  // Trend direction
  const firstRev = reviewTrend[0]?.revenue || 0;
  const lastRev = reviewTrend[reviewTrend.length - 1]?.revenue || 0;
  const trendChange = firstRev > 0 ? ((lastRev - firstRev) / firstRev) * 100 : 0;
  const isTrendUp = lastRev >= firstRev;

  const catColors = ['#0d9488', '#2563eb', '#d97706', '#64748b', '#0891b2', '#10b981', '#db2777', '#4f46e5'];

  const greyIcon = 'bg-slate-100 text-slate-500';

  return (
    <div className="flex-1 overflow-y-auto bg-slate-50 p-4 sm:p-6">
      {/* Header */}
      <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-2">
          <div className={`flex h-9 w-9 items-center justify-center rounded-xl ${greyIcon}`}>
            <BarChart3 className="h-5 w-5" strokeWidth={1.5} />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-800">Analitik Penjualan</h2>
            <p className="mt-0.5 text-sm text-slate-500">Pantau performa dan tren bisnis Anda</p>
          </div>
        </div>
        <div className="flex gap-1.5 rounded-xl bg-white p-1 shadow-sm ring-1 ring-slate-200">
          {rangeLabels.map((r) => (
            <button
              key={r.id}
              onClick={() => setDateRange(r.id)}
              className={`rounded-lg px-3.5 py-2 text-xs font-semibold transition-all ${
                dateRange === r.id ? 'bg-teal-600 text-white shadow-md shadow-teal-600/20' : 'text-slate-500 hover:bg-slate-100'
              }`}
            >
              {r.label}
            </button>
          ))}
        </div>
      </div>

      {/* Summary cards */}
      <div className="mb-5 grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-3 xl:grid-cols-6">
        {summaryCards.map((card) => {
          const Icon = card.icon;
          return (
            <div key={card.label} className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
              <div className="mb-2 flex items-center justify-between">
                <span className="text-xs font-medium text-slate-500">{card.label}</span>
                <div className={`rounded-lg p-1.5 ${greyIcon}`}>
                  <Icon className="h-4 w-4" strokeWidth={1.5} />
                </div>
              </div>
              <p className="text-lg font-bold text-slate-800">{card.value}</p>
            </div>
          );
        })}
      </div>

      {/* Revenue trend chart - trading style */}
      <div className="mb-4 rounded-xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
        <div className="mb-5 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-800">Tren Pendapatan</h3>
            <p className="mt-0.5 text-xs text-slate-400">7 hari terakhir</p>
          </div>
          <div className="flex items-center gap-3">
            <div className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-bold ${
              isTrendUp ? 'bg-teal-50 text-teal-600' : 'bg-rose-50 text-rose-600'
            }`}>
              {isTrendUp ? <TrendingUp className="h-3.5 w-3.5" /> : <TrendingDown className="h-3.5 w-3.5" />}
              {isTrendUp ? '+' : ''}{trendChange.toFixed(1)}%
            </div>
            <span className="flex items-center gap-1.5 text-xs text-slate-600">
              <div className="h-2.5 w-2.5 rounded-full bg-teal-600" /> Pendapatan
            </span>
          </div>
        </div>

        {/* Trading-style SVG chart */}
        <div className="relative">
          <svg viewBox={`0 0 ${trendW} ${trendH}`} preserveAspectRatio="none" className="w-full" style={{ height: '200px' }}>
            <defs>
              <linearGradient id="trendGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={isTrendUp ? '#0d9488' : '#f43f5e'} stopOpacity="0.2" />
                <stop offset="100%" stopColor={isTrendUp ? '#0d9488' : '#f43f5e'} stopOpacity="0" />
              </linearGradient>
            </defs>

            {/* Grid lines */}
            {[0.2, 0.4, 0.6, 0.8].map((p) => (
              <line key={p} x1="0" y1={trendH * p} x2={trendW} y2={trendH * p} stroke="#f1f5f9" strokeWidth="0.3" strokeDasharray="2 2" />
            ))}

            {/* Area fill */}
            <path d={trendAreaPath} fill="url(#trendGradient)" />

            {/* Smooth line */}
            <path
              d={trendLinePath}
              fill="none"
              stroke={isTrendUp ? '#0d9488' : '#f43f5e'}
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />

            {/* Data points */}
            {trendPoints.map((p, i) => (
              <g key={i}>
                <circle cx={p.x} cy={p.y} r="2" fill="#fff" stroke={isTrendUp ? '#0d9488' : '#f43f5e'} strokeWidth="1" />
                {i === trendPoints.length - 1 && (
                  <circle cx={p.x} cy={p.y} r="3.5" fill={isTrendUp ? '#0d9488' : '#f43f5e'} opacity="0.3">
                    <animate attributeName="r" values="3.5;6;3.5" dur="2s" repeatCount="indefinite" />
                    <animate attributeName="opacity" values="0.3;0;0.3" dur="2s" repeatCount="indefinite" />
                  </circle>
                )}
              </g>
            ))}
          </svg>

          {/* Tooltip overlay */}
          <div className="absolute inset-0 flex">
            {reviewTrend.map((day, i) => (
              <div key={i} className="group relative flex-1">
                <div className="absolute inset-0 cursor-pointer" />
                <div className="pointer-events-none absolute bottom-full left-1/2 z-10 mb-2 hidden -translate-x-1/2 whitespace-nowrap rounded-lg bg-slate-800 px-3 py-2 text-xs text-white shadow-lg group-hover:block">
                  <p className="font-semibold">{day.label}</p>
                  <p className="text-teal-300">{formatCurrency(day.revenue, symbol)}</p>
                  {day.reviewCount > 0 && (
                    <p className="text-amber-300">Rating: {day.avgRating.toFixed(1)} ({day.reviewCount} ulasan)</p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Day labels with mini up/down indicators */}
        <div className="mt-2 flex justify-between">
          {reviewTrend.map((day, i) => {
            const prevRev = i > 0 ? reviewTrend[i - 1].revenue : day.revenue;
            const dayUp = day.revenue >= prevRev;
            return (
              <div key={i} className="flex-1 text-center">
                <p className="text-[10px] font-medium text-slate-400">{day.label}</p>
                <p className={`text-[9px] font-semibold ${day.revenue > 0 ? (dayUp ? 'text-teal-600' : 'text-rose-400') : 'text-slate-300'}`}>
                  {formatCurrency(day.revenue, symbol)}
                </p>
              </div>
            );
          })}
        </div>
      </div>

      {/* Sentiment + Payment donut */}
      <div className="mb-4 grid grid-cols-1 gap-4 lg:grid-cols-2">
        {/* Rating performance */}
        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
          <div className="mb-5 flex items-center gap-2">
            <div className={`flex h-9 w-9 items-center justify-center rounded-xl ${greyIcon}`}>
              <Star className="h-5 w-5" strokeWidth={1.5} />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-800">Performa Rating</h3>
              <p className="text-xs text-slate-400">Dari {sentimentData.total} ulasan pelanggan</p>
            </div>
          </div>
          {sentimentData.total === 0 ? (
            <div className="flex h-40 items-center justify-center text-sm text-slate-400">Belum ada ulasan</div>
          ) : (
            <div className="flex flex-col items-center gap-5 sm:flex-row sm:gap-6">
              <div className="relative flex-shrink-0">
                <svg viewBox="0 0 120 120" className="h-28 w-28">
                  <defs>
                    <linearGradient id="gaugeGrad" x1="0" y1="0" x2="1" y2="1">
                      <stop offset="0%" stopColor="#0d9488" />
                      <stop offset="100%" stopColor="#0891b2" />
                    </linearGradient>
                  </defs>
                  <circle cx="60" cy="60" r={gaugeRadius} fill="none" stroke="#f1f5f9" strokeWidth="10" />
                  <circle
                    cx="60" cy="60" r={gaugeRadius}
                    fill="none"
                    stroke="url(#gaugeGrad)"
                    strokeWidth="10"
                    strokeLinecap="round"
                    strokeDasharray={gaugeCircumference}
                    strokeDashoffset={gaugeOffset}
                    transform="rotate(-90 60 60)"
                    className="transition-all duration-1000"
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <p className="text-2xl font-bold text-slate-800">{sentimentData.avgRating.toFixed(1)}</p>
                  <div className="flex gap-0.5">
                    {[1, 2, 3, 4, 5].map((s) => (
                      <Star
                        key={s}
                        className={`h-2.5 w-2.5 ${s <= Math.round(sentimentData.avgRating) ? 'fill-teal-500 text-teal-500' : 'fill-slate-200 text-slate-200'}`}
                      />
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex-1 space-y-1.5 self-stretch">
                {[5, 4, 3, 2, 1].map((star) => {
                  const count = sentimentData.starCounts[star - 1];
                  const barPct = (count / maxStarCount) * 100;
                  return (
                    <div key={star} className="group flex items-center gap-2">
                      <div className="flex w-10 flex-shrink-0 items-center gap-0.5">
                        <span className="text-xs font-bold text-slate-600">{star}</span>
                        <Star className="h-3 w-3 fill-teal-500 text-teal-500" />
                      </div>
                      <div className="h-3 flex-1 overflow-hidden rounded-full bg-slate-100">
                        <div
                          className={`h-full rounded-full transition-all duration-700 ${
                            star >= 4 ? 'bg-gradient-to-r from-emerald-400 to-emerald-500' :
                            star === 3 ? 'bg-gradient-to-r from-slate-400 to-slate-500' :
                            'bg-gradient-to-r from-rose-400 to-rose-500'
                          }`}
                          style={{ width: `${barPct}%` }}
                        />
                      </div>
                      <span className="w-12 flex-shrink-0 text-right text-xs font-medium text-slate-500">{count}</span>
                    </div>
                  );
                })}
                <div className="flex gap-2 pt-2">
                  <div className="flex items-center gap-1.5 rounded-lg bg-emerald-50 px-2.5 py-1">
                    <div className="h-2 w-2 rounded-full bg-teal-600" />
                    <span className="text-xs font-semibold text-teal-700">{sentimentData.positive} Positif</span>
                  </div>
                  <div className="flex items-center gap-1.5 rounded-lg bg-amber-50 px-2.5 py-1">
                    <div className="h-2 w-2 rounded-full bg-slate-400" />
                    <span className="text-xs font-semibold text-slate-600">{sentimentData.neutral} Netral</span>
                  </div>
                  <div className="flex items-center gap-1.5 rounded-lg bg-rose-50 px-2.5 py-1">
                    <div className="h-2 w-2 rounded-full bg-rose-500" />
                    <span className="text-xs font-semibold text-rose-600">{sentimentData.negative} Negatif</span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Payment methods donut */}
        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
          <div className="mb-4 flex items-center gap-2">
            <div className={`flex h-9 w-9 items-center justify-center rounded-xl ${greyIcon}`}>
              <CreditCard className="h-5 w-5" strokeWidth={1.5} />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-800">Metode Pembayaran</h3>
              <p className="text-xs text-slate-400">Distribusi transaksi</p>
            </div>
          </div>
          {paymentStats.length === 0 ? (
            <div className="flex h-32 items-center justify-center text-sm text-slate-400">Belum ada data</div>
          ) : (
            <div className="flex items-center gap-5">
              <div className="relative flex-shrink-0">
                <svg viewBox="0 0 160 160" className="h-32 w-32">
                  {donutPaths.map((seg, i) => (
                    <path key={i} d={seg.d} fill={seg.color} className="transition-opacity hover:opacity-80" />
                  ))}
                  <circle cx="80" cy="80" r="35" fill="white" />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <p className="text-lg font-bold text-slate-800">{totalOrders}</p>
                  <p className="text-[10px] text-slate-400">pesanan</p>
                </div>
              </div>
              <div className="flex-1 space-y-2.5">
                {paymentStats.map((p) => {
                  const Icon = paymentIcons[p.method] || CreditCard;
                  const pct = totalOrders > 0 ? (p.count / totalOrders) * 100 : 0;
                  const color = paymentColors[p.method] || '#64748b';
                  return (
                    <div key={p.method} className="flex items-center gap-2">
                      <div className="flex h-7 w-7 items-center justify-center rounded-lg" style={{ backgroundColor: color + '20' }}>
                        <Icon className="h-4 w-4" style={{ color }} />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-medium capitalize text-slate-700">{p.method}</span>
                          <span className="text-xs font-semibold text-slate-800">{pct.toFixed(0)}%</span>
                        </div>
                        <p className="text-[10px] text-slate-400">{formatCurrency(p.revenue, symbol)} ({p.count}x)</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Best + Worst sellers */}
      <div className="mb-4 grid grid-cols-1 gap-4 lg:grid-cols-2">
        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
          <div className="mb-4 flex items-center gap-2">
            <div className={`flex h-9 w-9 items-center justify-center rounded-xl ${greyIcon}`}>
              <Trophy className="h-5 w-5" strokeWidth={1.5} />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-800">Produk Terlaris</h3>
              <p className="text-xs text-slate-400">Top 5 berdasarkan quantity</p>
            </div>
          </div>
          {bestSellers.length === 0 ? (
            <div className="flex h-32 items-center justify-center text-sm text-slate-400">Belum ada data</div>
          ) : (
            <div className="space-y-3">
              {bestSellers.map((product, i) => (
                <div key={product.name} className="group">
                  <div className="mb-1.5 flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <div className={`flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-lg text-xs font-bold ${
                        i === 0 ? 'bg-teal-100 text-teal-700' :
                        i === 1 ? 'bg-slate-200 text-slate-600' :
                        i === 2 ? 'bg-slate-100 text-slate-500' :
                        'bg-slate-100 text-slate-500'
                      }`}>
                        {i + 1}
                      </div>
                      <span className="truncate text-sm font-medium text-slate-800">{product.name}</span>
                      {product.reviewCount > 0 && (
                        <span className="flex items-center gap-0.5 text-xs text-teal-600">
                          <Star className="h-3 w-3 fill-teal-500 text-teal-500" />
                          {product.avgRating.toFixed(1)}
                        </span>
                      )}
                    </div>
                    <span className="flex-shrink-0 text-sm font-semibold text-emerald-600">{formatCurrency(product.revenue, symbol)}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="h-2 flex-1 overflow-hidden rounded-full bg-slate-100">
                      <div className="h-full rounded-full bg-gradient-to-r from-teal-500 to-teal-400 transition-all duration-500" style={{ width: `${(product.qty / maxQty) * 100}%` }} />
                    </div>
                    <span className="w-16 flex-shrink-0 text-right text-xs text-slate-500">{product.qty} terjual</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
          <div className="mb-4 flex items-center gap-2">
            <div className={`flex h-9 w-9 items-center justify-center rounded-xl ${greyIcon}`}>
              <Flame className="h-5 w-5" strokeWidth={1.5} />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-800">Perlu Perhatian</h3>
              <p className="text-xs text-slate-400">Produk kurang laris</p>
            </div>
          </div>
          {worstSellers.length === 0 ? (
            <div className="flex h-32 items-center justify-center text-sm text-slate-400">Belum ada data</div>
          ) : (
            <div className="space-y-3">
              {worstSellers.map((product) => (
                <div key={product.name} className="group">
                  <div className="mb-1.5 flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <div className="flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-lg bg-slate-100">
                        <ArrowDownRight className="h-4 w-4 text-slate-400" strokeWidth={1.5} />
                      </div>
                      <span className="truncate text-sm font-medium text-slate-800">{product.name}</span>
                      {product.reviewCount > 0 && (
                        <span className="flex items-center gap-0.5 text-xs text-teal-600">
                          <Star className="h-3 w-3 fill-teal-500 text-teal-500" />
                          {product.avgRating.toFixed(1)}
                        </span>
                      )}
                    </div>
                    <span className="flex-shrink-0 text-sm font-semibold text-slate-500">{formatCurrency(product.revenue, symbol)}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="h-2 flex-1 overflow-hidden rounded-full bg-slate-100">
                      <div className="h-full rounded-full bg-gradient-to-r from-rose-400 to-rose-300 transition-all duration-500" style={{ width: `${Math.max((product.qty / maxQty) * 100, 3)}%` }} />
                    </div>
                    <span className="w-16 flex-shrink-0 text-right text-xs text-slate-500">{product.qty} terjual</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Hourly sales */}
      <div className="mb-4 rounded-xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
        <div className="mb-5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className={`flex h-9 w-9 items-center justify-center rounded-xl ${greyIcon}`}>
              <Clock className="h-5 w-5" strokeWidth={1.5} />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-800">Penjualan per Jam</h3>
              <p className="text-xs text-slate-400">Pola transaksi harian</p>
            </div>
          </div>
          {peakHour && (
            <div className="flex items-center gap-2 rounded-xl bg-slate-100 px-3 py-2">
              <TrendingUp className="h-4 w-4 text-slate-500" strokeWidth={1.5} />
              <div>
                <p className="text-[10px] text-slate-400">Jam Teramai</p>
                <p className="text-xs font-bold text-slate-700">{formatHour(peakHour.hour)} · {formatCurrency(peakHour.revenue, symbol)}</p>
              </div>
            </div>
          )}
        </div>
        {activeHours.length === 0 ? (
          <div className="flex h-24 items-center justify-center text-sm text-slate-400">Belum ada data</div>
        ) : (
          <div className="flex items-end justify-between gap-1" style={{ height: '160px' }}>
            {hourlyStats.map((h) => {
              const heightPct = (h.revenue / maxHourRevenue) * 100;
              const intensity = h.count > 0 ? Math.max(0.3, heightPct / 100) : 0;
              return (
                <div key={h.hour} className="group relative flex flex-1 flex-col items-center justify-end">
                  <div
                    className="w-full rounded-t transition-all duration-300 hover:brightness-110"
                    style={{
                      height: `${heightPct}%`,
                      minHeight: h.revenue > 0 ? '3px' : '0px',
                      background: h.count > 0
                        ? `linear-gradient(to top, rgba(13,148,136,${intensity}), rgba(20,184,166,${intensity * 0.8}))`
                        : 'transparent',
                    }}
                  />
                  <div className="pointer-events-none absolute bottom-full mb-1 hidden whitespace-nowrap rounded-lg bg-slate-800 px-2.5 py-1.5 text-[10px] text-white shadow-lg group-hover:block z-10">
                    <p className="font-semibold">{formatHour(h.hour)}</p>
                    <p className="text-teal-300">{formatCurrency(h.revenue, symbol)}</p>
                    <p className="text-slate-400">{h.count} pesanan</p>
                  </div>
                  {h.hour % 3 === 0 && <span className="mt-1.5 text-[9px] text-slate-400">{h.hour}</span>}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Category breakdown */}
      <div className="mb-4 rounded-xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
        <div className="mb-4 flex items-center gap-2">
          <div className={`flex h-9 w-9 items-center justify-center rounded-xl ${greyIcon}`}>
            <Tags className="h-5 w-5" strokeWidth={1.5} />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-800">Pendapatan per Kategori</h3>
            <p className="text-xs text-slate-400">Breakdown revenue & profit</p>
          </div>
        </div>
        {categoryStats.length === 0 ? (
          <div className="flex h-24 items-center justify-center text-sm text-slate-400">Belum ada data</div>
        ) : (
          <div className="space-y-4">
            {categoryStats.map((cat, i) => {
              const color = catColors[i % catColors.length];
              return (
                <div key={cat.name}>
                  <div className="mb-2 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="h-3 w-3 rounded-sm" style={{ backgroundColor: color }} />
                      <span className="text-sm font-medium text-slate-700">{cat.name}</span>
                      <span className="rounded-full bg-slate-100 px-2 py-0.5 text-[10px] text-slate-500">{cat.qty} item</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="flex items-center gap-1 text-xs text-emerald-600">
                        <ArrowUpRight className="h-3 w-3" strokeWidth={1.5} />
                        {formatCurrency(cat.profit, symbol)}
                      </span>
                      <span className="text-sm font-semibold text-slate-800">{formatCurrency(cat.revenue, symbol)}</span>
                    </div>
                  </div>
                  <div className="h-3 overflow-hidden rounded-full bg-slate-100">
                    <div
                      className="h-full rounded-full transition-all duration-700"
                      style={{
                        width: `${(cat.revenue / maxCatRevenue) * 100}%`,
                        background: `linear-gradient(to right, ${color}, ${color}dd)`,
                      }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Full product performance table */}
      <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
        <div className="mb-4 flex items-center gap-2">
          <div className={`flex h-9 w-9 items-center justify-center rounded-xl ${greyIcon}`}>
            <Package className="h-5 w-5" strokeWidth={1.5} />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-800">Performa Semua Produk</h3>
            <p className="text-xs text-slate-400">{productStats.length} produk</p>
          </div>
        </div>
        {productStats.length === 0 ? (
          <div className="flex h-24 items-center justify-center text-sm text-slate-400">Belum ada data</div>
        ) : (
          <>
            <div className="space-y-2 lg:hidden">
              {productStats.map((p, i) => (
                <div key={p.name} className="rounded-xl border border-slate-100 p-3.5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-400">#{i + 1}</span>
                      <span className="text-sm font-medium text-slate-800">{p.name}</span>
                    </div>
                    <span className="text-sm font-semibold text-emerald-600">{formatCurrency(p.revenue, symbol)}</span>
                  </div>
                  <div className="mt-2 flex flex-wrap items-center gap-3 text-xs">
                    <span className="text-slate-500">{p.qty} terjual</span>
                    <span className={p.profit >= 0 ? 'text-emerald-600' : 'text-rose-500'}>
                      Profit: {formatCurrency(p.profit, symbol)} ({p.margin.toFixed(0)}%)
                    </span>
                    {p.reviewCount > 0 && (
                      <span className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-semibold ${
                        p.avgRating >= 4 ? 'bg-emerald-50 text-emerald-600' :
                        p.avgRating >= 3 ? 'bg-amber-50 text-amber-600' :
                        'bg-rose-50 text-rose-600'
                      }`}>
                        <Star className="h-3 w-3 fill-current" />
                        {p.avgRating.toFixed(1)}
                        <span className="opacity-60">({p.reviewCount})</span>
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>

            <div className="hidden overflow-x-auto lg:block">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-slate-100 text-left text-xs text-slate-500">
                    <th className="pb-3 pr-2 font-semibold">#</th>
                    <th className="pb-3 pr-2 font-semibold">Produk</th>
                    <th className="pb-3 text-right font-semibold">Qty</th>
                    <th className="pb-3 text-right font-semibold">Pendapatan</th>
                    <th className="pb-3 text-right font-semibold">Modal</th>
                    <th className="pb-3 text-right font-semibold">Profit</th>
                    <th className="pb-3 text-right font-semibold">Margin</th>
                    <th className="pb-3 text-center font-semibold">Rating</th>
                  </tr>
                </thead>
                <tbody>
                  {productStats.map((p, i) => (
                    <tr key={p.name} className="border-b border-slate-50 transition hover:bg-slate-50/50 last:border-0">
                      <td className="py-3 pr-2 text-slate-400">{i + 1}</td>
                      <td className="py-3 pr-2 font-medium text-slate-800">{p.name}</td>
                      <td className="py-3 text-right text-slate-600">{p.qty}</td>
                      <td className="py-3 text-right font-semibold text-slate-800">{formatCurrency(p.revenue, symbol)}</td>
                      <td className="py-3 text-right text-slate-500">{formatCurrency(p.cost, symbol)}</td>
                      <td className={`py-3 text-right font-semibold ${p.profit >= 0 ? 'text-emerald-600' : 'text-rose-500'}`}>
                        {formatCurrency(p.profit, symbol)}
                      </td>
                      <td className="py-3 text-right">
                        <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium ${
                          p.margin >= 30 ? 'bg-emerald-50 text-emerald-600' :
                          p.margin >= 0 ? 'bg-amber-50 text-amber-600' :
                          'bg-rose-50 text-rose-600'
                        }`}>
                          {p.margin.toFixed(0)}%
                        </span>
                      </td>
                      <td className="py-3 text-center">
                        {p.reviewCount > 0 ? (
                          <span className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-semibold ${
                            p.avgRating >= 4 ? 'bg-emerald-50 text-emerald-600' :
                            p.avgRating >= 3 ? 'bg-amber-50 text-amber-600' :
                            'bg-rose-50 text-rose-600'
                          }`}>
                            <Star className="h-3 w-3 fill-current" />
                            {p.avgRating.toFixed(1)}
                            <span className="opacity-60">({p.reviewCount})</span>
                          </span>
                        ) : (
                          <span className="text-xs text-slate-300">—</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
