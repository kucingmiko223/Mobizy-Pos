import { useState, useEffect } from 'react';
import { Save, AlertCircle, Check } from 'lucide-react';
import { api, errorMessage } from '@/lib/api';
import { useStore } from '@/context/StoreContext';

export function SettingsView() {
  const { settings, refreshSettings } = useStore();
  const [storeName, setStoreName] = useState('');
  const [currencySymbol, setCurrencySymbol] = useState('');
  const [taxRate, setTaxRate] = useState('');
  const [receiptFooter, setReceiptFooter] = useState('');
  const [qrisUrl, setQrisUrl] = useState('');
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (settings) {
      setStoreName(settings.store_name);
      setCurrencySymbol(settings.currency_symbol);
      setTaxRate((settings.tax_rate * 100).toString());
      setReceiptFooter(settings.receipt_footer);
      setQrisUrl(settings.qris_url || '');
    }
  }, [settings]);

  const handleSave = async () => {
    setSaving(true);
    setError('');

    const rate = parseFloat(taxRate) || 0;
    if (rate < 0 || rate > 100) {
      setError('Tarif pajak harus antara 0 dan 100');
      setSaving(false);
      return;
    }

    try {
      await api.patch('/store', {
        store_name: storeName.trim() || 'MobizyPOS',
        currency_symbol: currencySymbol.trim() || 'Rp',
        tax_rate: rate / 100,
        receipt_footer: receiptFooter.trim(),
        qris_url: qrisUrl.trim() || null,
      });
    } catch (e) {
      setError(errorMessage(e));
      setSaving(false);
      return;
    }

    await refreshSettings();
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  if (!settings) {
    return (
      <div className="flex flex-1 items-center justify-center text-slate-400">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-blue-500/30 border-t-blue-500" />
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto bg-slate-50 p-4 sm:p-6">
      <h2 className="mb-5 text-xl font-bold text-slate-800">Pengaturan Toko</h2>

      <div className="max-w-lg rounded-xl border border-slate-200 bg-white p-4 shadow-sm sm:p-6">
        <div className="space-y-5">
          <div>
            <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-500">
              Nama Toko
            </label>
            <input
              type="text"
              value={storeName}
              onChange={(e) => setStoreName(e.target.value)}
              className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:border-blue-500 focus:bg-white"
            />
          </div>

          <div>
            <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-500">
              Simbol Mata Uang
            </label>
            <div className="flex items-center gap-3">
              <input
                type="text"
                value={currencySymbol}
                onChange={(e) => setCurrencySymbol(e.target.value)}
                maxLength={5}
                className="w-32 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:border-blue-500 focus:bg-white"
              />
              <span className="text-sm text-slate-400">Default: Rp (Rupiah)</span>
            </div>
          </div>

          <div>
            <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-500">
              Tarif Pajak (%)
            </label>
            <input
              type="number"
              step="0.01"
              value={taxRate}
              onChange={(e) => setTaxRate(e.target.value)}
              className="w-32 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:border-blue-500 focus:bg-white"
            />
          </div>

          <div>
            <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-500">
              URL QRIS (Kode QR Pembayaran)
            </label>
            <input
              type="text"
              value={qrisUrl}
              onChange={(e) => setQrisUrl(e.target.value)}
              className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:border-blue-500 focus:bg-white"
              placeholder="https://chart.googleapis.com/chart?cht=qr&chs=300x300&chl=..."
            />
            <p className="mt-1.5 text-xs text-slate-400">Tautan gambar QR untuk pembayaran QRIS. Pelanggan akan melihat QR ini saat checkout.</p>
            {qrisUrl && (
              <div className="mt-3 flex flex-col items-center gap-2 rounded-lg bg-slate-50 p-4">
                <img src={qrisUrl} alt="QRIS QR Code" className="h-32 w-32 rounded-lg border border-slate-200" onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }} />
                <span className="text-xs text-slate-400">Preview QRIS</span>
              </div>
            )}
          </div>

          <div>
            <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-500">
              Pesan Footer Struk
            </label>
            <textarea
              value={receiptFooter}
              onChange={(e) => setReceiptFooter(e.target.value)}
              rows={2}
              className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:border-blue-500 focus:bg-white"
            />
          </div>
        </div>

        {error && (
          <div className="mt-4 flex items-center gap-2 rounded-lg bg-red-50 px-4 py-2.5 text-sm text-red-600">
            <AlertCircle className="h-4 w-4 flex-shrink-0" />
            {error}
          </div>
        )}

        <div className="mt-6">
          <button
            onClick={handleSave}
            disabled={saving}
            className="flex items-center gap-2 rounded-xl bg-blue-600 px-5 py-2.5 text-sm font-bold text-white transition hover:bg-blue-700 disabled:opacity-40"
          >
            {saving ? (
              <div className="h-4 w-4 animate-spin rounded-full border-2 border-white/30 border-t-white" />
            ) : saved ? (
              <>
                <Check className="h-4 w-4" />
                Tersimpan!
              </>
            ) : (
              <>
                <Save className="h-4 w-4" />
                Simpan Pengaturan
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
