import { useEffect, useState } from 'react';
import { LayoutDashboard, DollarSign, ShoppingBag, TrendingUp, Clock, Award, Ban, TicketPercent, ChevronRight } from 'lucide-react';

import { api } from '@/lib/api';
import { useStore } from '@/context/StoreContext';
import { formatCurrency, formatTime } from '@/lib/format';
import type { Order, OrderItem } from '@/types';

export function Dashboard({ onShowRevenueDetail }: { onShowRevenueDetail?: () => void }) {
  const { settings } = useStore();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [topProducts, setTopProducts] = useState<
    { name: string; qty: number; revenue: number }[]
  >([]);
  const [voidCount, setVoidCount] = useState(0);
  const [totalDiscount, setTotalDiscount] = useState(0);

  const symbol = settings?.currency_symbol || 'Rp';

  useEffect(() => {
    (async () => {
      try {
        const data = await api.get<Order[]>('/orders', { limit: 500 });
        setOrders(data);
        setVoidCount(data.filter((o) => o.correction_type === 'void').length);
        setTotalDiscount(data.reduce((s, o) => s + Number(o.discount_amount || 0), 0));
      } catch (e) {
        console.error(e);
      }
      setLoading(false);
    })();
  }, []);

  useEffect(() => {
    (async () => {
      let data: OrderItem[];
      try {
        data = await api.get<OrderItem[]>('/orders/items', { status: 'completed' });
      } catch (e) {
        console.error(e);
        return;
      }
      if (data.length === 0) return;
      const sales: Record<string, { name: string; qty: number; revenue: number }> = {};
      for (const item of data) {
        if (!sales[item.product_name]) {
          sales[item.product_name] = { name: item.product_name, qty: 0, revenue: 0 };
        }
        sales[item.product_name].qty += item.quantity;
        sales[item.product_name].revenue += Number(item.subtotal);
      }
      const sorted = Object.values(sales).sort((a, b) => b.qty - a.qty).slice(0, 5);
      setTopProducts(sorted);
    })();
  }, []);

  if (loading) {
    return (
      <div className="flex flex-1 items-center justify-center text-slate-400">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-blue-500/30 border-t-blue-500" />
      </div>
    );
  }

  const now = new Date();
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const validOrders = orders.filter((o) => o.correction_type === 'none' || !o.correction_type);
  const todayOrders = validOrders.filter((o) => new Date(o.created_at) >= todayStart);
  const todayRevenue = todayOrders.reduce((s, o) => s + Number(o.total), 0);
  const totalRevenue = validOrders.reduce((s, o) => s + Number(o.total), 0);
  const totalOrders = validOrders.length;
  const avgOrder = totalOrders > 0 ? totalRevenue / totalOrders : 0;

  const last7Days: { label: string; revenue: number }[] = [];
  for (let i = 6; i >= 0; i--) {
    const dayStart = new Date(now);
    dayStart.setDate(dayStart.getDate() - i);
    dayStart.setHours(0, 0, 0, 0);
    const dayEnd = new Date(dayStart);
    dayEnd.setDate(dayEnd.getDate() + 1);
    const dayRevenue = validOrders
      .filter((o) => { const d = new Date(o.created_at); return d >= dayStart && d < dayEnd; })
      .reduce((s, o) => s + Number(o.total), 0);
    last7Days.push({
      label: dayStart.toLocaleDateString('id-ID', { weekday: 'short' }),
      revenue: dayRevenue,
    });
  }

  const maxDayRevenue = Math.max(...last7Days.map((d) => d.revenue), 1);
  const recentOrders = orders.slice(0, 8);

  const cards = [
    { label: 'Pendapatan Hari Ini', value: formatCurrency(todayRevenue, symbol), icon: DollarSign, sub: `${todayOrders.length} pesanan` },
    { label: 'Total Pendapatan', value: formatCurrency(totalRevenue, symbol), icon: TrendingUp, sub: 'Sepanjang waktu' },
    { label: 'Total Pesanan', value: totalOrders.toString(), icon: ShoppingBag, sub: 'Sepanjang waktu' },
    { label: 'Rata-rata Pesanan', value: formatCurrency(avgOrder, symbol), icon: Clock, sub: 'Per transaksi' },
    { label: 'Total Diskon', value: formatCurrency(totalDiscount, symbol), icon: TicketPercent, sub: 'Sepanjang waktu' },
    { label: 'Dibatalkan', value: voidCount.toString(), icon: Ban, sub: 'Sepanjang waktu' },
  ];

  return (
    <div className="flex-1 overflow-y-auto bg-slate-50 p-4 sm:p-6">
      <div className="mb-5 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-blue-50">
            <LayoutDashboard className="h-5 w-5 text-blue-600" />
          </div>
          <h2 className="text-xl font-bold text-slate-800">Dasbor</h2>
        </div>
        {onShowRevenueDetail && (
          <button
            onClick={onShowRevenueDetail}
            className="flex items-center gap-1.5 rounded-lg bg-blue-600 px-3 py-2 text-sm font-semibold text-white transition hover:bg-blue-700"
          >
            <TrendingUp className="h-4 w-4" strokeWidth={1.5} />
            <span className="hidden sm:inline">Lihat Detail Pendapatan</span>
            <span className="sm:hidden">Detail</span>
          </button>
        )}
      </div>

      <div className="mb-5 grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-3 xl:grid-cols-6">
        {cards.map((card) => {
          const Icon = card.icon;
          return (
            <div key={card.label} className="rounded-xl border border-slate-200 bg-white p-3 shadow-sm sm:p-4">
              <div className="mb-2 flex items-center justify-between sm:mb-3">
                <span className="text-xs font-medium text-slate-500">{card.label}</span>
                <div className="rounded-lg bg-slate-100 p-1.5 sm:p-2">
                  <Icon className="h-4 w-4 text-slate-500" strokeWidth={1.5} />
                </div>
              </div>
              <p className="text-lg font-bold text-slate-800 sm:text-xl">{card.value}</p>
              <p className="mt-1 text-xs text-slate-400">{card.sub}</p>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 gap-3 sm:gap-4 lg:grid-cols-2">
        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
          <h3 className="mb-4 text-sm font-bold text-slate-800">Pendapatan 7 Hari Terakhir</h3>
          <div className="flex items-end justify-between gap-2" style={{ height: '160px' }}>
            {last7Days.map((day, i) => (
              <div key={i} className="flex flex-1 flex-col items-center gap-2">
                <div className="flex w-full flex-1 items-end">
                  <div
                    className="w-full rounded-t-md bg-gradient-to-t from-blue-500 to-blue-400 transition-all hover:from-blue-600 hover:to-blue-500"
                    style={{ height: `${(day.revenue / maxDayRevenue) * 100}%`, minHeight: day.revenue > 0 ? '4px' : '0px' }}
                    title={formatCurrency(day.revenue, symbol)}
                  />
                </div>
                <span className="text-xs text-slate-500">{day.label}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
          <h3 className="mb-4 text-sm font-bold text-slate-800">Produk Terlaris</h3>
          {topProducts.length === 0 ? (
            <div className="flex h-32 items-center justify-center text-sm text-slate-400">Belum ada data</div>
          ) : (
            <div className="space-y-3">
              {topProducts.map((product, i) => (
                <div key={product.name} className="flex items-center gap-3">
                  <div className={`flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-lg text-xs font-bold ${i === 0 ? 'bg-amber-100 text-amber-700' : 'bg-slate-100 text-slate-600'}`}>
                    {i + 1}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium text-slate-800">{product.name}</p>
                    <p className="text-xs text-slate-500">{product.qty} terjual</p>
                  </div>
                  <span className="text-sm font-semibold text-blue-600">{formatCurrency(product.revenue, symbol)}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="mt-3 rounded-xl border border-slate-200 bg-white p-4 shadow-sm sm:mt-4 sm:p-5">
        <h3 className="mb-4 flex items-center gap-2 text-sm font-bold text-slate-800">
          <Award className="h-4 w-4 text-slate-500" strokeWidth={1.5} />
          Pesanan Terbaru
        </h3>
        {recentOrders.length === 0 ? (
          <div className="flex h-20 items-center justify-center text-sm text-slate-400">Belum ada pesanan</div>
        ) : (
          <>
            <div className="space-y-2 lg:hidden">
              {recentOrders.map((order) => (
                <div key={order.id} className="flex items-center justify-between rounded-lg border border-slate-100 px-3 py-2.5">
                  <div>
                    <p className="text-sm font-semibold text-slate-800">#{order.order_number}</p>
                    <p className="text-xs text-slate-500">{formatTime(order.created_at)} · {order.item_count} item</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-semibold text-blue-600">{formatCurrency(order.total, symbol)}</p>
                    <p className="text-xs capitalize text-slate-400">{order.payment_method}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="hidden overflow-x-auto lg:block">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-slate-100 text-left text-xs text-slate-500">
                    <th className="pb-2 font-medium">Pesanan</th>
                    <th className="pb-2 font-medium">Waktu</th>
                    <th className="pb-2 font-medium">Item</th>
                    <th className="pb-2 font-medium">Bayar</th>
                    <th className="pb-2 text-right font-medium">Total</th>
                  </tr>
                </thead>
                <tbody>
                  {recentOrders.map((order) => (
                    <tr key={order.id} className="border-b border-slate-50 last:border-0">
                      <td className="py-2.5 font-semibold text-slate-800">#{order.order_number}</td>
                      <td className="py-2.5 text-slate-500">{formatTime(order.created_at)}</td>
                      <td className="py-2.5 text-slate-500">{order.item_count}</td>
                      <td className="py-2.5">
                        <span className="rounded bg-slate-100 px-2 py-0.5 text-xs capitalize text-slate-600">{order.payment_method}</span>
                      </td>
                      <td className="py-2.5 text-right font-semibold text-blue-600">{formatCurrency(order.total, symbol)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
