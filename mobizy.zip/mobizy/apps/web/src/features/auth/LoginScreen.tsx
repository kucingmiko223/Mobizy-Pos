import { useState, type FormEvent } from 'react';
import { Loader2 } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { errorMessage } from '@/lib/api';
import { MobizyLogo } from '@/components/ui/MobizyLogo';

type Mode = 'login' | 'store' | 'customer';

const input = 'w-full rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-sm text-slate-800 outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-500/10';
const slugify = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 40);

export function LoginScreen() {
  const { login, registerStore, registerCustomer } = useAuth();
  const storeFromUrl = new URLSearchParams(window.location.search).get('store') ?? '';
  const [mode, setMode] = useState<Mode>(storeFromUrl ? 'customer' : 'login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [storeName, setStoreName] = useState('');
  const [slug, setSlug] = useState(storeFromUrl);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      if (mode === 'login') await login(email, password);
      else if (mode === 'store') await registerStore({ store_name: storeName, slug, display_name: name, email, password });
      else await registerCustomer({ store_slug: slug, display_name: name, email, password });
    } catch (err) {
      setError(errorMessage(err, 'Gagal masuk'));
    } finally {
      setBusy(false);
    }
  };

  const tabs: { id: Mode; label: string }[] = [
    { id: 'login', label: 'Masuk' },
    { id: 'store', label: 'Daftar Toko' },
    { id: 'customer', label: 'Pelanggan' },
  ];

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-4">
      <div className="w-full max-w-md">
        <div className="mb-6 flex flex-col items-center">
          <MobizyLogo size="xl" className="mb-4" />
          <h1 className="text-xl font-bold text-white">MobizyPOS</h1>
          <p className="mt-0.5 text-sm text-slate-400">Satu untuk semua UMKM</p>
        </div>

        <div className="rounded-2xl bg-white p-5 shadow-2xl">
          <div className="mb-4 grid grid-cols-3 gap-1 rounded-xl bg-slate-100 p-1">
            {tabs.map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => { setMode(t.id); setError(''); }}
                className={`rounded-lg py-2 text-sm font-medium transition ${mode === t.id ? 'bg-white text-blue-600 shadow' : 'text-slate-500 hover:text-slate-700'}`}
              >
                {t.label}
              </button>
            ))}
          </div>

          <form onSubmit={submit} className="space-y-3">
            {mode === 'store' && (
              <>
                <input className={input} placeholder="Nama toko" value={storeName} required
                  onChange={(e) => { setStoreName(e.target.value); setSlug(slugify(e.target.value)); }} />
                <input className={input} placeholder="alamat-toko (huruf kecil, angka, strip)" value={slug} required
                  onChange={(e) => setSlug(slugify(e.target.value))} />
              </>
            )}
            {mode === 'customer' && (
              <input className={input} placeholder="Kode toko" value={slug} required onChange={(e) => setSlug(slugify(e.target.value))} />
            )}
            {mode !== 'login' && (
              <input className={input} placeholder="Nama Anda" value={name} required onChange={(e) => setName(e.target.value)} />
            )}
            <input className={input} type="email" autoComplete="email" placeholder="Email" value={email} required onChange={(e) => setEmail(e.target.value)} />
            <input className={input} type="password" autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
              placeholder={mode === 'login' ? 'Password' : 'Password (min. 10 karakter)'} value={password} required minLength={mode === 'login' ? 1 : 10}
              onChange={(e) => setPassword(e.target.value)} />

            {error && <p role="alert" className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-600">{error}</p>}

            <button type="submit" disabled={busy}
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-blue-600 py-2.5 text-sm font-semibold text-white transition hover:bg-blue-700 disabled:opacity-60">
              {busy && <Loader2 className="h-4 w-4 animate-spin" />}
              {mode === 'login' ? 'Masuk' : mode === 'store' ? 'Buat Toko' : 'Daftar'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
