import { useState, useMemo } from 'react';
import { X, Banknote, CreditCard, Check, AlertCircle, TicketPercent, Building, Clock, QrCode, FileText } from 'lucide-react';
import { useStore } from '@/context/StoreContext';
import { useAuth } from '@/context/AuthContext';
import { api, errorMessage } from '@/lib/api';
import { calculatePricing } from '@mobizy/shared';
import { formatCurrency, formatDateTime } from '@/lib/format';
import { hapticSuccess } from '@/lib/feedback';
import type { PaymentMethod, Order, OrderItem, Voucher } from '@/types';

interface CheckoutModalProps {
  open: boolean;
  onClose: () => void;
  onComplete: (order: Order, items: OrderItem[]) => void;
}

export function CheckoutModal({ open, onClose, onComplete }: CheckoutModalProps) {
  const { cart, cartSubtotal, settings, clearCart, refreshProducts, vouchers, refreshVouchers } = useStore();
  const { role } = useAuth();
  const showProfit = role === 'owner' || role === 'admin'; // cost is not sent to cashiers
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('cash');
  const [amountPaid, setAmountPaid] = useState('');
  const [processing, setProcessing] = useState(false);
  const [error, setError] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [orderNotes, setOrderNotes] = useState('');
  const [voucherCode, setVoucherCode] = useState('');
  const [appliedVoucher, setAppliedVoucher] = useState<Voucher | null>(null);
  const [voucherError, setVoucherError] = useState('');
  const [scheduledTime, setScheduledTime] = useState('');
  const [qrisConfirmed, setQrisConfirmed] = useState(false);

  const symbol = settings?.currency_symbol || 'Rp';
  const taxRate = settings?.tax_rate || 0;
  const qrisUrl = settings?.qris_url || '';

  // Display-only: the server recomputes everything from product ids + quantities.
  const lines = useMemo(
    () => cart.map((item) => ({ unitPrice: item.product.price, quantity: item.quantity })),
    [cart]
  );
  const pricing = useMemo(
    () => calculatePricing({ lines, taxRate, voucher: appliedVoucher }),
    [lines, taxRate, appliedVoucher]
  );
  const discountAmount = pricing.discountAmount;
  const taxableAmount = pricing.taxableAmount;
  const taxAmount = pricing.taxAmount;
  const total = pricing.total;

  const parsedPaid = parseFloat(amountPaid) || 0;
  const changeDue = paymentMethod === 'cash' ? Math.max(0, parsedPaid - total) : 0;
  const canComplete =
    cart.length > 0 &&
    (paymentMethod !== 'cash' || parsedPaid >= total) &&
    (paymentMethod !== 'qris' || qrisConfirmed);

  if (!open) return null;

  const paymentMethods: { id: PaymentMethod; label: string; icon: typeof Banknote }[] = [
    { id: 'cash', label: 'Tunai', icon: Banknote },
    { id: 'card', label: 'Kartu', icon: CreditCard },
    { id: 'qris', label: 'QRIS', icon: QrCode },
    { id: 'transfer', label: 'Transfer', icon: Building },
  ];

  const quickAmounts = [
    total,
    Math.ceil(total / 5000) * 5000,
    Math.ceil(total / 10000) * 10000,
    Math.ceil(total / 50000) * 50000,
    Math.ceil(total / 100000) * 100000,
  ].filter((v, i, arr) => arr.indexOf(v) === i);

  const handleApplyVoucher = async () => {
    setVoucherError('');
    const code = voucherCode.trim().toUpperCase();
    if (!code) {
      setVoucherError('Masukkan kode voucher');
      return;
    }
    try {
      const res = await api.post<{ voucher: Voucher }>('/vouchers/validate', {
        code,
        items: cart.map((i) => ({ product_id: i.product.id, quantity: i.quantity })),
      });
      setAppliedVoucher(res.voucher);
    } catch (e) {
      setVoucherError(errorMessage(e, 'Voucher tidak valid'));
      setAppliedVoucher(null);
    }
  };

  const handleRemoveVoucher = () => {
    setAppliedVoucher(null);
    setVoucherCode('');
    setVoucherError('');
  };

  const handleCheckout = async () => {
    if (!canComplete || processing) return;
    setProcessing(true);
    setError('');

    try {
      const { order, items: insertedItems } = await api.post<{ order: Order; items: OrderItem[] }>('/orders', {
        items: cart.map((item) => ({ product_id: item.product.id, quantity: item.quantity })),
        payment_method: paymentMethod,
        amount_paid: paymentMethod === 'cash' ? parsedPaid : undefined,
        customer_name: customerName.trim(),
        notes: orderNotes.trim(),
        voucher_code: appliedVoucher?.code,
        scheduled_time: scheduledTime ? new Date(scheduledTime).toISOString() : null,
      });
      if (appliedVoucher) await refreshVouchers();

      clearCart();
      setAmountPaid('');
      setPaymentMethod('cash');
      setCustomerName('');
      setOrderNotes('');
      setAppliedVoucher(null);
      setVoucherCode('');
      setScheduledTime('');
      setQrisConfirmed(false);
      await refreshProducts();
      hapticSuccess();
      onComplete(order, insertedItems);
    } catch (err) {
      setError(errorMessage(err, 'Checkout gagal'));
      await refreshProducts(); // stock may have changed under us
    } finally {
      setProcessing(false);
    }
  };

  const handleClose = () => {
    if (!processing) {
      setError('');
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-slate-900/50 backdrop-blur-sm sm:items-center sm:p-4">
      <div className="w-full max-w-md rounded-t-2xl bg-white shadow-2xl animate-slide-in-up sm:rounded-2xl">
        <div className="flex items-center justify-between border-b border-slate-200 px-5 py-4 sm:px-6">
          <h2 className="text-lg font-bold text-slate-800">Pembayaran</h2>
          <button
            onClick={handleClose}
            disabled={processing}
            className="rounded-lg p-1 text-slate-400 transition hover:bg-slate-100 hover:text-slate-600 disabled:opacity-40"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="max-h-[75vh] overflow-y-auto px-5 py-5 sm:px-6">
          {/* Cart items summary */}
          <div className="mb-4 rounded-xl border border-slate-200 bg-slate-50 p-3">
            <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">
              Item Pesanan ({cart.length} produk)
            </p>
            <div className="max-h-32 space-y-1 overflow-y-auto">
              {cart.map((item) => (
                <div key={item.product.id} className="flex justify-between text-sm">
                  <span className="text-slate-700">
                    <span className="font-medium text-slate-800">{item.quantity}x</span> {item.product.name}
                  </span>
                  <span className="font-medium text-slate-700">{formatCurrency(item.product.price * item.quantity, symbol)}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Customer name */}
          <div className="mb-4">
            <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">
              Nama Pelanggan (opsional)
            </p>
            <input
              type="text"
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
              placeholder="Nama pelanggan..."
              className="w-full rounded-xl border border-slate-200 bg-slate-50 py-2.5 px-4 text-sm outline-none transition focus:border-blue-500 focus:bg-white"
            />
          </div>

          {/* Scheduled time */}
          <div className="mb-4">
            <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">
              <Clock className="mr-1 inline h-3 w-3" />
              Jadwal Pesanan (opsional)
            </p>
            <input
              type="datetime-local"
              value={scheduledTime}
              onChange={(e) => setScheduledTime(e.target.value)}
              className="w-full rounded-xl border border-slate-200 bg-slate-50 py-2.5 px-4 text-sm outline-none transition focus:border-blue-500 focus:bg-white"
            />
            {scheduledTime && (
              <p className="mt-1.5 flex items-center gap-1 text-xs text-blue-600">
                <Clock className="h-3 w-3" />
                Pesanan dijadwalkan: {formatDateTime(new Date(scheduledTime).toISOString())}
              </p>
            )}
          </div>

          {/* Order notes */}
          <div className="mb-4">
            <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">
              <FileText className="mr-1 inline h-3 w-3" />
              Catatan Pesanan (opsional)
            </p>
            <textarea
              value={orderNotes}
              onChange={(e) => setOrderNotes(e.target.value)}
              rows={2}
              placeholder="Contoh: Tanpa es, pedas, ambil sendiri..."
              className="w-full rounded-xl border border-slate-200 bg-slate-50 py-2.5 px-4 text-sm outline-none transition focus:border-blue-500 focus:bg-white"
            />
          </div>

          {/* Voucher section */}
          <div className="mb-5 rounded-xl border border-slate-200 bg-slate-50 p-3">
            <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">
              Voucher / Diskon
            </p>
            {appliedVoucher ? (
              <div className="flex items-center justify-between rounded-lg bg-emerald-50 px-3 py-2.5">
                <div className="flex items-center gap-2">
                  <TicketPercent className="h-4 w-4 text-emerald-600" />
                  <div>
                    <p className="text-sm font-semibold text-emerald-700">{appliedVoucher.name}</p>
                    <p className="text-xs text-emerald-600">
                      {appliedVoucher.discount_type === 'bogo'
                        ? 'Beli 1 Gratis 1'
                        : appliedVoucher.discount_type === 'percentage'
                          ? `${appliedVoucher.discount_value}% off`
                          : `${formatCurrency(appliedVoucher.discount_value, symbol)} off`}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-bold text-emerald-700">
                    -{formatCurrency(discountAmount, symbol)}
                  </span>
                  <button
                    onClick={handleRemoveVoucher}
                    disabled={processing}
                    className="rounded-lg p-1 text-emerald-400 transition hover:bg-emerald-100 hover:text-emerald-600"
                  >
                    <X className="h-4 w-4" />
                  </button>
                </div>
              </div>
            ) : (
              <>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <TicketPercent className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                    <input
                      type="text"
                      value={voucherCode}
                      onChange={(e) => setVoucherCode(e.target.value.toUpperCase())}
                      placeholder="Masukkan kode voucher..."
                      className="w-full rounded-lg border border-slate-200 bg-white py-2 pl-9 pr-3 text-sm font-medium uppercase tracking-wider outline-none focus:border-blue-500"
                      onKeyDown={(e) => e.key === 'Enter' && handleApplyVoucher()}
                    />
                  </div>
                  <button
                    onClick={handleApplyVoucher}
                    disabled={processing}
                    className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white transition hover:bg-blue-700 disabled:opacity-40"
                  >
                    Terapkan
                  </button>
                </div>
                {voucherError && (
                  <p className="mt-1.5 flex items-center gap-1 text-xs text-red-500">
                    <AlertCircle className="h-3 w-3" />
                    {voucherError}
                  </p>
                )}
                {vouchers.filter((v) => v.is_active).length > 0 && (
                  <div className="mt-2 flex flex-wrap gap-1.5">
                    {vouchers.filter((v) => v.is_active).slice(0, 4).map((v) => (
                      <button
                        key={v.id}
                        onClick={() => { setVoucherCode(v.code); }}
                        className="rounded-full border border-blue-200 bg-blue-50 px-2.5 py-1 text-xs font-medium text-blue-600 transition hover:bg-blue-100"
                      >
                        {v.code}
                      </button>
                    ))}
                  </div>
                )}
              </>
            )}
          </div>

          {/* Order summary */}
          <div className="mb-5 rounded-xl bg-slate-50 p-4">
            <div className="space-y-1.5 text-sm">
              <div className="flex justify-between text-slate-500">
                <span>Subtotal</span>
                <span>{formatCurrency(cartSubtotal, symbol)}</span>
              </div>
              {discountAmount > 0 && (
                <div className="flex justify-between text-emerald-600">
                  <span>Diskon</span>
                  <span>-{formatCurrency(discountAmount, symbol)}</span>
                </div>
              )}
              <div className="flex justify-between text-slate-500">
                <span>Pajak ({(taxRate * 100).toFixed(2)}%)</span>
                <span>{formatCurrency(taxAmount, symbol)}</span>
              </div>
              <div className="flex justify-between border-t border-slate-200 pt-2 text-base font-bold">
                <span className="text-slate-800">Total Bayar</span>
                <span className="text-blue-600">{formatCurrency(total, symbol)}</span>
              </div>
              {showProfit && (
              <>
              <div className="flex justify-between border-t border-slate-100 pt-1.5 text-xs">
                <span className="text-slate-400">Modal Barang</span>
                <span className="font-medium text-slate-500">{formatCurrency(cart.reduce((s, item) => s + item.product.cost * item.quantity, 0), symbol)}</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-slate-400">Estimasi Profit</span>
                <span className={`font-semibold ${total - cart.reduce((s, item) => s + item.product.cost * item.quantity, 0) >= 0 ? 'text-emerald-600' : 'text-rose-500'}`}>
                  {formatCurrency(total - cart.reduce((s, item) => s + item.product.cost * item.quantity, 0), symbol)}
                </span>
              </div>
              </>
              )}
            </div>
          </div>

          {/* Payment method selection */}
          <div className="mb-5">
            <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">
              Metode Pembayaran
            </p>
            <div className="grid grid-cols-4 gap-2">
              {paymentMethods.map((method) => {
                const Icon = method.icon;
                return (
                  <button
                    key={method.id}
                    onClick={() => { setPaymentMethod(method.id); setQrisConfirmed(false); }}
                    className={`flex flex-col items-center gap-1.5 rounded-xl border-2 py-2.5 transition sm:py-3 ${
                      paymentMethod === method.id
                        ? 'border-blue-500 bg-blue-50 text-blue-700'
                        : 'border-slate-200 text-slate-500 hover:border-slate-300'
                    }`}
                  >
                    <Icon className="h-5 w-5" />
                    <span className="text-xs font-medium">{method.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Cash payment: amount input */}
          {paymentMethod === 'cash' && (
            <div className="mb-5">
              <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">
                Uang Diterima
              </p>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-lg font-bold text-slate-400">
                  {symbol}
                </span>
                <input
                  type="number"
                  step="100"
                  value={amountPaid}
                  onChange={(e) => setAmountPaid(e.target.value)}
                  placeholder="0"
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 py-3 pl-12 pr-4 text-lg font-semibold text-slate-800 outline-none transition focus:border-blue-500 focus:bg-white focus:ring-2 focus:ring-blue-500/10"
                  autoFocus
                />
              </div>

              <div className="mt-2 flex gap-2 overflow-x-auto">
                {quickAmounts.map((amt) => (
                  <button
                    key={amt}
                    onClick={() => setAmountPaid(amt.toFixed(0))}
                    className="flex-1 whitespace-nowrap rounded-lg border border-slate-200 bg-white py-2 text-sm font-medium text-slate-600 transition hover:border-blue-400 hover:text-blue-600"
                  >
                    {formatCurrency(amt, symbol)}
                  </button>
                ))}
              </div>

              {parsedPaid > 0 && (
                <div className="mt-3 flex justify-between rounded-lg bg-blue-50 px-4 py-2.5">
                  <span className="text-sm font-medium text-blue-700">Kembalian</span>
                  <span className="text-sm font-bold text-blue-700">
                    {formatCurrency(changeDue, symbol)}
                  </span>
                </div>
              )}
            </div>
          )}

          {/* QRIS payment: QR code display */}
          {paymentMethod === 'qris' && (
            <div className="mb-5">
              <div className="flex flex-col items-center gap-3 rounded-xl border-2 border-blue-200 bg-blue-50 p-5">
                <div className="flex items-center gap-2 text-blue-700">
                  <QrCode className="h-5 w-5" />
                  <p className="text-sm font-bold">Scan QRIS untuk Pembayaran</p>
                </div>
                {qrisUrl ? (
                  <div className="rounded-xl bg-white p-3 shadow-sm">
                    <img
                      src={qrisUrl}
                      alt="QRIS QR Code"
                      className="h-44 w-44"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.style.display = 'none';
                        target.parentElement!.innerHTML = '<div class="flex h-44 w-44 items-center justify-center text-slate-400 text-xs text-center">QR tidak tersimpan.<br/>Atur di Pengaturan Toko.</div>';
                      }}
                    />
                  </div>
                ) : (
                  <div className="flex h-44 w-44 flex-col items-center justify-center rounded-xl bg-white text-center text-xs text-slate-400">
                    <QrCode className="mb-2 h-8 w-8" />
                    QR belum diatur.<br/>Atur URL QRIS di Pengaturan.
                  </div>
                )}
                <p className="text-lg font-bold text-blue-700">{formatCurrency(total, symbol)}</p>
                <label className="flex items-center gap-2 rounded-lg bg-white px-4 py-2.5 cursor-pointer transition hover:bg-blue-100">
                  <input
                    type="checkbox"
                    checked={qrisConfirmed}
                    onChange={(e) => setQrisConfirmed(e.target.checked)}
                    className="h-4 w-4 rounded border-blue-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="text-sm font-medium text-slate-700">Pembayaran telah diterima</span>
                </label>
              </div>
            </div>
          )}

          {/* Card / Transfer info */}
          {(paymentMethod === 'card' || paymentMethod === 'transfer') && (
            <div className="mb-5">
              <div className="rounded-xl border-2 border-slate-200 bg-slate-50 p-4 text-center">
                <p className="text-sm font-medium text-slate-600">
                  {paymentMethod === 'card' ? 'Proses pembayaran kartu melalui mesin EDC.' : 'Transfer ke rekening toko dan konfirmasi pembayaran.'}
                </p>
                <p className="mt-2 text-lg font-bold text-blue-600">{formatCurrency(total, symbol)}</p>
              </div>
            </div>
          )}

          {error && (
            <div className="mb-4 flex items-center gap-2 rounded-lg bg-red-50 px-4 py-2.5 text-sm text-red-600">
              <AlertCircle className="h-4 w-4 flex-shrink-0" />
              {error}
            </div>
          )}

          <div className="flex gap-3">
            <button
              onClick={handleClose}
              disabled={processing}
              className="flex-1 rounded-xl border border-slate-200 py-3 text-sm font-semibold text-slate-600 transition hover:bg-slate-50 disabled:opacity-40"
            >
              Batal
            </button>
            <button
              onClick={handleCheckout}
              disabled={!canComplete || processing}
              className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-blue-600 py-3 text-sm font-bold text-white transition hover:bg-blue-700 disabled:cursor-not-allowed disabled:opacity-40"
            >
              {processing ? (
                <>
                  <div className="h-4 w-4 animate-spin rounded-full border-2 border-white/30 border-t-white" />
                  Memproses...
                </>
              ) : (
                <>
                  <Check className="h-4 w-4" />
                  Konfirmasi Pesanan
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
