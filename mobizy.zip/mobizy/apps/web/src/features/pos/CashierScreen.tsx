import { useState } from 'react';
import { Search, Package, Clock, Zap } from 'lucide-react';
import { useStore } from '@/context/StoreContext';
import { formatCurrency } from '@/lib/format';
import { haptic } from '@/lib/feedback';

/** readOnly = browse the menu only (customers can't create sales). */
export function CashierScreen({ readOnly = false }: { readOnly?: boolean }) {
  const { products, categories, settings, addToCart } = useStore();
  const [search, setSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [tappedId, setTappedId] = useState<string | null>(null);

  const filteredProducts = (() => {
    let result = products;
    if (activeCategory !== 'all') {
      result = result.filter((p) => p.category_id === activeCategory);
    }
    if (search.trim()) {
      const q = search.toLowerCase();
      result = result.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.barcode?.includes(q) ||
          p.description.toLowerCase().includes(q)
      );
    }
    return result;
  })();

  const handleTap = (id: string) => {
    setTappedId(id);
    setTimeout(() => setTappedId(null), 300);
  };

  return (
    <div className="flex flex-1 flex-col overflow-hidden">
      {/* Search bar */}
      <div className="flex-shrink-0 border-b border-slate-200 bg-white px-4 py-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Cari produk berdasarkan nama atau barcode..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full rounded-xl border border-slate-200 bg-slate-50 py-2.5 pl-10 pr-4 text-sm text-slate-800 outline-none transition focus:border-blue-500 focus:bg-white focus:ring-2 focus:ring-blue-500/10"
          />
        </div>
      </div>

      {/* Category tabs */}
      <div className="flex flex-shrink-0 gap-2 overflow-x-auto border-b border-slate-200 bg-white px-4 py-2.5">
        <button
          onClick={() => setActiveCategory('all')}
          className={`flex-shrink-0 rounded-lg px-3.5 py-1.5 text-sm font-medium transition-all ${
            activeCategory === 'all'
              ? 'bg-blue-600 text-white shadow-md shadow-blue-600/20'
              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
          }`}
        >
          Semua
        </button>
        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setActiveCategory(cat.id)}
            className={`flex-shrink-0 rounded-lg px-3.5 py-1.5 text-sm font-medium transition-all ${
              activeCategory === cat.id
                ? 'bg-blue-600 text-white shadow-md shadow-blue-600/20'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            {cat.name}
          </button>
        ))}
      </div>

      {/* Product grid */}
      <div className="flex-1 overflow-y-auto bg-slate-50 p-3 pb-20 sm:p-4 lg:pb-4">
        {filteredProducts.length === 0 ? (
          <div className="flex h-full flex-col items-center justify-center text-slate-400">
            <Package className="mb-3 h-12 w-12" />
            <p className="text-sm font-medium">Produk tidak ditemukan</p>
            <p className="text-xs">Coba pencarian atau kategori lain</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3 sm:gap-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
            {filteredProducts.map((product) => (
              <button
                key={product.id}
                onClick={() => { if (readOnly) return; addToCart(product); haptic(); handleTap(product.id); }}
                disabled={!readOnly && product.stock <= 0}
                className={`group relative flex flex-col overflow-hidden rounded-xl border border-slate-200 bg-white p-2.5 text-left transition-all hover:border-blue-400 hover:shadow-lg active:scale-95 disabled:cursor-not-allowed disabled:opacity-50 sm:p-3 ${
                  tappedId === product.id ? 'ring-2 ring-blue-500 scale-95' : ''
                }`}
              >
                {tappedId === product.id && (
                  <div className="absolute inset-0 z-10 flex items-center justify-center bg-blue-500/10 rounded-xl animate-fade-in">
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-blue-600 text-white animate-bounce-in">
                      <Zap className="h-4 w-4" />
                    </div>
                  </div>
                )}

                {product.stock <= 5 && product.stock > 0 && (
                  <span className="absolute right-2 top-2 z-20 rounded-full bg-amber-100 px-2 py-0.5 text-xs font-medium text-amber-700 shadow-sm">
                    Sisa: {product.stock}
                  </span>
                )}
                {product.stock <= 0 && (
                  <span className="absolute right-2 top-2 z-20 rounded-full bg-red-100 px-2 py-0.5 text-xs font-medium text-red-700 shadow-sm">
                    Habis
                  </span>
                )}

                {/* Product image */}
                <div className="mb-2 flex h-16 items-center justify-center overflow-hidden rounded-lg bg-gradient-to-br from-slate-100 to-slate-200 sm:h-20">
                  {product.image_url ? (
                    <img
                      src={product.image_url}
                      alt={product.name}
                      className="h-full w-full object-cover transition-transform group-hover:scale-110"
                      loading="lazy"
                      onError={(e) => {
                        (e.target as HTMLImageElement).style.display = 'none';
                      }}
                    />
                  ) : (
                    <Package className="h-7 w-7 text-slate-400 sm:h-9 sm:w-9" />
                  )}
                </div>

                <p className="mb-1 line-clamp-2 text-xs font-semibold text-slate-800 sm:text-sm">
                  {product.name}
                </p>
                {product.description && (
                  <p className="mb-1 line-clamp-1 text-[10px] text-slate-400 sm:text-xs">
                    {product.description}
                  </p>
                )}
                <p className="mt-auto text-base font-bold text-blue-600 sm:text-lg">
                  {formatCurrency(product.price, settings?.currency_symbol)}
                </p>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
