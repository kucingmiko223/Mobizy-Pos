import { Receipt as ReceiptIcon, X, Printer, Clock, FileText, TicketPercent } from 'lucide-react';
import { useStore } from '@/context/StoreContext';
import { formatCurrency, formatDateTime } from '@/lib/format';
import type { Order, OrderItem } from '@/types';

interface ReceiptModalProps {
  open: boolean;
  order: Order | null;
  items: OrderItem[];
  onClose: () => void;
}

export function ReceiptModal({ open, order, items, onClose }: ReceiptModalProps) {
  const { settings, vouchers } = useStore();

  if (!open || !order) return null;

  const symbol = settings?.currency_symbol || 'Rp';
  const storeName = settings?.store_name || 'MobizyPOS';
  const footer = settings?.receipt_footer || 'Terima kasih!';
  const appliedVoucher = order.voucher_id ? vouchers.find((v) => v.id === order.voucher_id) : null;

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-slate-900/50 p-0 backdrop-blur-sm sm:items-center sm:p-4">
      <div className="w-full max-w-sm rounded-t-2xl bg-white shadow-2xl animate-slide-in-up sm:rounded-2xl">
        <div className="flex items-center justify-between border-b border-slate-200 px-5 py-4 sm:px-6">
          <div className="flex items-center gap-2">
            <ReceiptIcon className="h-5 w-5 text-blue-600" />
            <h2 className="text-lg font-bold text-slate-800">Struk</h2>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1 text-slate-400 transition hover:bg-slate-100 hover:text-slate-600"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="max-h-[65vh] overflow-y-auto px-5 py-5 sm:px-6">
          <div className="print-receipt mx-auto max-w-xs rounded-lg bg-white p-4 font-mono text-xs text-slate-800">
            <div className="mb-3 text-center">
              <p className="text-base font-bold">{storeName}</p>
              {order.customer_name && (
                <p className="text-slate-600">Pelanggan: {order.customer_name}</p>
              )}
              <p className="text-slate-500">{formatDateTime(order.created_at)}</p>
            </div>

            <div className="mb-3 border-t border-dashed border-slate-300 pt-3">
              <p className="flex justify-between">
                <span>Order #</span>
                <span className="font-semibold">{order.order_number}</span>
              </p>
              <p className="flex justify-between">
                <span>Bayar</span>
                <span className="font-semibold capitalize">{order.payment_method}</span>
              </p>
              {order.scheduled_time && (
                <p className="flex justify-between text-blue-600">
                  <span>Jadwal</span>
                  <span className="font-semibold">{formatDateTime(order.scheduled_time)}</span>
                </p>
              )}
            </div>

            <div className="mb-3 border-t border-dashed border-slate-300 pt-3">
              <div className="mb-1 flex justify-between font-bold">
                <span>Item</span>
                <span>Total</span>
              </div>
              {items.map((item) => (
                <div key={item.id} className="mb-1.5">
                  <div className="flex justify-between">
                    <span className="truncate pr-2">{item.product_name}</span>
                    <span className="font-semibold">
                      {formatCurrency(item.subtotal, symbol)}
                    </span>
                  </div>
                  <div className="text-slate-500">
                    {item.quantity} @ {formatCurrency(item.unit_price, symbol)}
                  </div>
                </div>
              ))}
            </div>

            {order.notes && (
              <div className="mb-3 border-t border-dashed border-slate-300 pt-3">
                <p className="flex items-start gap-1 text-slate-600">
                  <FileText className="h-3 w-3 flex-shrink-0 mt-0.5" />
                  <span>Catatan: {order.notes}</span>
                </p>
              </div>
            )}

            <div className="border-t border-dashed border-slate-300 pt-3">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span>{formatCurrency(order.subtotal, symbol)}</span>
              </div>
              {Number(order.discount_amount) > 0 && (
                <>
                  <div className="flex justify-between text-emerald-600">
                    <span className="flex items-center gap-1">
                      <TicketPercent className="h-3 w-3" />
                      Diskon
                    </span>
                    <span>-{formatCurrency(Number(order.discount_amount), symbol)}</span>
                  </div>
                  {appliedVoucher && (
                    <div className="flex justify-between text-emerald-500">
                      <span>Voucher</span>
                      <span className="text-[10px]">{appliedVoucher.code}</span>
                    </div>
                  )}
                </>
              )}
              <div className="flex justify-between">
                <span>Pajak</span>
                <span>{formatCurrency(order.tax_amount, symbol)}</span>
              </div>
              <div className="mt-1 flex justify-between border-t border-slate-300 pt-1 text-sm font-bold">
                <span>TOTAL</span>
                <span>{formatCurrency(order.total, symbol)}</span>
              </div>
              <div className="mt-2">
                <div className="flex justify-between">
                  <span>Dibayar</span>
                  <span>{formatCurrency(order.amount_paid, symbol)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Kembalian</span>
                  <span>{formatCurrency(order.change_due, symbol)}</span>
                </div>
              </div>
            </div>

            <div className="mt-4 border-t border-dashed border-slate-300 pt-3 text-center">
              <p className="text-slate-600">{footer}</p>
            </div>
          </div>
        </div>

        <div className="border-t border-slate-200 px-5 py-4 sm:px-6">
          <div className="flex gap-3">
            <button
              onClick={() => window.print()}
              className="flex flex-1 items-center justify-center gap-2 rounded-xl border border-slate-200 py-3 text-sm font-semibold text-slate-600 transition hover:bg-slate-50"
            >
              <Printer className="h-4 w-4" />
              Cetak
            </button>
            <button
              onClick={onClose}
              className="flex-1 rounded-xl bg-blue-600 py-3 text-sm font-bold text-white transition hover:bg-blue-700"
            >
              Transaksi Baru
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
