import { ShoppingCart, Plus, Minus, Trash2, X, ChevronDown, TicketPercent } from 'lucide-react';
import { useStore } from '@/context/StoreContext';
import { useAuth } from '@/context/AuthContext';
import { formatCurrency } from '@/lib/format';
import { haptic } from '@/lib/feedback';
import type { Voucher } from '@/types';

interface CartPanelProps {
  onCheckout: () => void;
  onClose?: () => void;
  appliedVoucher?: Voucher | null;
  discountAmount?: number;
}

export function CartPanel({ onCheckout, onClose, appliedVoucher, discountAmount = 0 }: CartPanelProps) {
  const { cart, cartCount, cartSubtotal, updateQuantity, removeFromCart, clearCart, settings } =
    useStore();

  const { role } = useAuth();
  // purchase cost is only sent to owner/admin, so profit can only be shown to them
  const showProfit = role === 'owner' || role === 'admin';
  const symbol = settings?.currency_symbol || 'Rp';
  const taxRate = settings?.tax_rate || 0;
  const taxableAmount = Math.max(0, cartSubtotal - discountAmount);
  const taxAmount = taxableAmount * taxRate;
  const total = taxableAmount + taxAmount;

  const totalCost = cart.reduce((s, item) => s + item.product.cost * item.quantity, 0);
  const estimatedProfit = total - totalCost;

  if (cart.length === 0) {
    return (
      <div className="flex max-h-[80vh] w-full flex-col items-center justify-center p-8 text-slate-400">
        <ShoppingCart className="mb-4 h-16 w-16" />
        <p className="text-base font-semibold text-slate-500">Keranjang Kosong</p>
        <p className="mt-1 text-sm">Klik produk untuk menambahkan</p>
        {onClose && (
          <button
            onClick={onClose}
            className="mt-4 rounded-lg border border-slate-200 px-4 py-2 text-sm font-medium text-slate-600 transition hover:bg-slate-50"
          >
            Tutup
          </button>
        )}
      </div>
    );
  }

  return (
    <div className="flex max-h-[80vh] flex-col">
      <div className="flex items-center justify-between border-b border-slate-200 px-4 py-3">
        <div className="flex items-center gap-2">
          <ShoppingCart className="h-5 w-5 text-blue-600" />
          <span className="text-sm font-bold text-slate-800">Pesanan</span>
          <span className="rounded-full bg-blue-100 px-2 py-0.5 text-xs font-semibold text-blue-700">
            {cartCount}
          </span>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={clearCart}
            className="flex items-center gap-1 rounded-lg px-2 py-1 text-xs font-medium text-red-500 transition hover:bg-red-50"
          >
            <X className="h-3.5 w-3.5" />
            Kosongkan
          </button>
          {onClose && (
            <button
              onClick={onClose}
              className="flex items-center gap-1 rounded-lg px-2 py-1 text-xs font-medium text-slate-500 transition hover:bg-slate-100 lg:hidden"
            >
              <ChevronDown className="h-4 w-4" />
            </button>
          )}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-2">
        {cart.map((item) => (
          <div
            key={item.product.id}
            className="flex items-center gap-2 border-b border-slate-100 py-2.5"
          >
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-medium text-slate-800">
                {item.product.name}
              </p>
              <p className="text-xs text-slate-500">
                {formatCurrency(item.product.price, symbol)} / pcs
              </p>
            </div>

            <div className="flex items-center gap-1">
              <button
                onClick={() => { haptic(8); updateQuantity(item.product.id, -1); }}
                className="flex h-7 w-7 items-center justify-center rounded-lg bg-slate-100 text-slate-600 transition hover:bg-slate-200"
              >
                <Minus className="h-3.5 w-3.5" />
              </button>
              <span className="w-8 text-center text-sm font-semibold text-slate-800">
                {item.quantity}
              </span>
              <button
                onClick={() => { haptic(8); updateQuantity(item.product.id, 1); }}
                disabled={item.quantity >= item.product.stock}
                className="flex h-7 w-7 items-center justify-center rounded-lg bg-slate-100 text-slate-600 transition hover:bg-slate-200 disabled:cursor-not-allowed disabled:opacity-40"
              >
                <Plus className="h-3.5 w-3.5" />
              </button>
            </div>

            <div className="w-16 text-right sm:w-20">
              <p className="text-sm font-bold text-slate-800">
                {formatCurrency(item.product.price * item.quantity, symbol)}
              </p>
            </div>

            <button
              onClick={() => removeFromCart(item.product.id)}
              className="flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-lg text-slate-300 transition hover:bg-red-50 hover:text-red-500"
            >
              <Trash2 className="h-3.5 w-3.5" />
            </button>
          </div>
        ))}
      </div>

      <div className="border-t border-slate-200 bg-slate-50 px-4 py-3">
        <div className="space-y-1.5 text-sm">
          <div className="flex justify-between text-slate-500">
            <span>Subtotal</span>
            <span className="font-medium text-slate-700">
              {formatCurrency(cartSubtotal, symbol)}
            </span>
          </div>
          {appliedVoucher && discountAmount > 0 && (
            <div className="flex justify-between text-emerald-600">
              <span className="flex items-center gap-1">
                <TicketPercent className="h-3.5 w-3.5" />
                {appliedVoucher.name}
              </span>
              <span className="font-medium">-{formatCurrency(discountAmount, symbol)}</span>
            </div>
          )}
          <div className="flex justify-between text-slate-500">
            <span>Pajak ({(taxRate * 100).toFixed(2)}%)</span>
            <span className="font-medium text-slate-700">
              {formatCurrency(taxAmount, symbol)}
            </span>
          </div>
          <div className="flex justify-between border-t border-slate-200 pt-2 text-base">
            <span className="font-bold text-slate-800">Total</span>
            <span className="font-bold text-blue-600">
              {formatCurrency(total, symbol)}
            </span>
          </div>
          {showProfit && (
            <div className="flex justify-between text-xs">
              <span className="text-slate-400">Estimasi Profit</span>
              <span className={`font-medium ${estimatedProfit >= 0 ? 'text-emerald-600' : 'text-rose-500'}`}>
                {formatCurrency(estimatedProfit, symbol)}
              </span>
            </div>
          )}
        </div>

        <button
          onClick={onCheckout}
          className="mt-3 w-full rounded-xl bg-blue-600 py-3 text-sm font-bold text-white transition hover:bg-blue-700 active:scale-[0.98]"
        >
          Bayar · {formatCurrency(total, symbol)}
        </button>
      </div>
    </div>
  );
}
