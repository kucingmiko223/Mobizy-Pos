import { useState, useEffect, useMemo } from 'react';
import {
  Plus, Trash2, X, Wallet, TrendingUp, TrendingDown, Calculator, AlertCircle,
  Receipt, BookOpen, Download, ArrowUpRight, ArrowDownRight, FileSpreadsheet,
  Filter, Scale, PieChart, BarChart3,
} from 'lucide-react';
import { api, errorMessage } from '@/lib/api';
import { useStore } from '@/context/StoreContext';
import { formatCurrency, formatDate, formatDateTime } from '@/lib/format';
import { exportToExcel, exportToCSV, type ExportColumn } from '@/lib/export';
import type { Expense, ExpenseCategory, Order } from '@/types';

const categoryLabels: Record<string, string> = {
  rent: 'Sewa',
  utilities: 'Listrik & Air',
  inventory: 'Restock',
  salary: 'Gaji',
  marketing: 'Marketing',
  other: 'Lainnya',
};

const categoryColors: Record<string, string> = {
  rent: 'bg-rose-100 text-rose-700',
  utilities: 'bg-amber-100 text-amber-700',
  inventory: 'bg-teal-100 text-teal-700',
  salary: 'bg-emerald-100 text-emerald-700',
  marketing: 'bg-cyan-100 text-cyan-700',
  other: 'bg-slate-100 text-slate-700',
};

const categoryBarColors: Record<string, string> = {
  rent: '#f43f5e',
  utilities: '#f59e0b',
  inventory: '#0d9488',
  salary: '#10b981',
  marketing: '#0891b2',
  other: '#64748b',
};

const paymentLabels: Record<string, string> = {
  cash: 'Tunai', card: 'Kartu', qris: 'QRIS', transfer: 'Transfer',
};

const paymentColors: Record<string, string> = {
  cash: '#0d9488', card: '#2563eb', qris: '#0891b2', transfer: '#d97706',
};

interface LedgerEntry {
  id: string;
  date: string;
  description: string;
  type: 'income' | 'expense';
  category: string;
  ref: string;
  debit: number;
  credit: number;
  balance: number;
}

type DateRange = 'today' | '7d' | '30d' | 'all';

export function Accounting({ onShowRevenueDetail }: { onShowRevenueDetail?: () => void }) {
  const { settings } = useStore();
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [orders, setOrders] = useState<{ id: string; created_at: string; total: number; order_number: number; customer_name: string; payment_method: string; subtotal: number; tax_amount: number }[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [revenue, setRevenue] = useState(0);
  const [profit, setProfit] = useState(0);
  const [period, setPeriod] = useState<DateRange>('30d');
  const [activeTab, setActiveTab] = useState<'summary' | 'ledger'>('summary');
  const [ledgerFilter, setLedgerFilter] = useState<'all' | 'income' | 'expense'>('all');

  const symbol = settings?.currency_symbol || 'Rp';
  const greyIcon = 'bg-slate-100 text-slate-500';

  useEffect(() => {
    (async () => {
      setLoading(true);
      const days = period === 'today' ? 0 : period === '7d' ? 7 : 30;
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - days);
      startDate.setHours(0, 0, 0, 0);
      const dateStr = startDate.toISOString();

      const from = period !== 'all' ? dateStr : undefined;
      const exp = await api.get<Expense[]>('/expenses', { from }).catch(() => [] as Expense[]);
      setExpenses(exp);

      const ord = await api.get<Order[]>('/orders', { from, limit: 1000 }).catch(() => [] as Order[]);
      const valid = ord.filter((o) => o.correction_type === 'none' || !o.correction_type);
      setOrders(valid.map(o => ({ id: o.id, created_at: o.created_at, total: Number(o.total), order_number: o.order_number, customer_name: o.customer_name || '', payment_method: o.payment_method, subtotal: Number(o.subtotal), tax_amount: Number(o.tax_amount) })));

      const totalRev = valid.reduce((s, o) => s + Number(o.total), 0);
      const totalExp = (exp || []).reduce((s, e) => s + Number(e.amount), 0);
      setRevenue(totalRev);
      setProfit(totalRev - totalExp);
      setLoading(false);
    })();
  }, [period]);

  const totalExpenses = expenses.reduce((s, e) => s + Number(e.amount), 0);
  const expensesByCategory = expenses.reduce((acc, e) => {
    acc[e.category] = (acc[e.category] || 0) + Number(e.amount);
    return acc;
  }, {} as Record<string, number>);

  const revenueByPayment = orders.reduce((acc, o) => {
    acc[o.payment_method] = (acc[o.payment_method] || 0) + o.total;
    return acc;
  }, {} as Record<string, number>);

  const totalTax = orders.reduce((s, o) => s + o.tax_amount, 0);
  const netSales = orders.reduce((s, o) => s + o.subtotal, 0);
  const grossProfit = revenue - totalExpenses;
  const profitMargin = revenue > 0 ? (grossProfit / revenue) * 100 : 0;
  const expenseRatio = revenue > 0 ? (totalExpenses / revenue) * 100 : 0;

  // Daily trend data (7 days)
  const dailyTrend = useMemo(() => {
    const now = new Date();
    const trend: { label: string; income: number; expense: number; net: number }[] = [];
    for (let i = 6; i >= 0; i--) {
      const dayStart = new Date(now);
      dayStart.setDate(dayStart.getDate() - i);
      dayStart.setHours(0, 0, 0, 0);
      const dayEnd = new Date(dayStart);
      dayEnd.setDate(dayEnd.getDate() + 1);
      const dayOrders = orders.filter((o) => { const d = new Date(o.created_at); return d >= dayStart && d < dayEnd; });
      const dayExpenses = expenses.filter((e) => { const d = new Date(e.expense_date + 'T00:00:00'); return d >= dayStart && d < dayEnd; });
      const inc = dayOrders.reduce((s, o) => s + o.total, 0);
      const exp = dayExpenses.reduce((s, e) => s + Number(e.amount), 0);
      trend.push({
        label: dayStart.toLocaleDateString('id-ID', { weekday: 'short' }),
        income: inc,
        expense: exp,
        net: inc - exp,
      });
    }
    return trend;
  }, [orders, expenses]);

  const maxTrendValue = Math.max(...dailyTrend.map(d => Math.max(d.income, d.expense)), 1);

  const handleDelete = async (id: string) => {
    try { await api.del(`/expenses/${id}`); } catch (e) { console.error(e); return; }
    setExpenses(prev => prev.filter(e => e.id !== id));
  };

  const ledgerEntries: LedgerEntry[] = useMemo(() => {
    const incomeEntries: LedgerEntry[] = orders.map(o => ({
      id: `inc-${o.id}`,
      date: o.created_at,
      description: `Pesanan #${o.order_number}${o.customer_name ? ` — ${o.customer_name}` : ''}`,
      type: 'income' as const,
      category: paymentLabels[o.payment_method] || o.payment_method,
      ref: `ORD-${String(o.order_number).padStart(5, '0')}`,
      debit: Number(o.total),
      credit: 0,
      balance: 0,
    }));
    const expenseEntries: LedgerEntry[] = expenses.map(e => ({
      id: `exp-${e.id}`,
      date: e.expense_date,
      description: e.description || categoryLabels[e.category] || 'Pengeluaran',
      type: 'expense' as const,
      category: categoryLabels[e.category] || e.category,
      ref: `EXP-${e.id.slice(0, 8).toUpperCase()}`,
      debit: 0,
      credit: Number(e.amount),
      balance: 0,
    }));
    const all = [...incomeEntries, ...expenseEntries].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    let runningBalance = 0;
    for (const entry of all) {
      runningBalance += entry.debit - entry.credit;
      entry.balance = runningBalance;
    }
    return all;
  }, [orders, expenses]);

  const filteredLedger = ledgerFilter === 'all' ? ledgerEntries : ledgerEntries.filter(e => e.type === ledgerFilter);
  const totalDebit = ledgerEntries.reduce((s, e) => s + e.debit, 0);
  const totalCredit = ledgerEntries.reduce((s, e) => s + e.credit, 0);

  // Pagination for ledger
  const [ledgerPage, setLedgerPage] = useState(0);
  const pageSize = 25;
  const pageCount = Math.ceil(filteredLedger.length / pageSize);
  const pagedLedger = filteredLedger.slice(ledgerPage * pageSize, (ledgerPage + 1) * pageSize);

  useEffect(() => { setLedgerPage(0); }, [ledgerFilter, activeTab]);

  const handleExportExcel = () => {
    const periodLabel = rangeLabels.find(p => p.id === period)?.label || 'Semua';
    const dateStr = new Date().toLocaleDateString('id-ID');

    const pnlColumns: ExportColumn[] = [
      { header: 'Kategori', key: 'label', width: 200 },
      { header: 'Jumlah', key: 'amount', width: 150 },
    ];
    const pnlRows = [
      ...Object.entries(revenueByPayment).map(([method, amt]) => ({ label: `Pendapatan - ${paymentLabels[method] || method}`, amount: amt })),
      { label: 'Total Pendapatan', amount: revenue },
      { label: '', amount: null as number | null },
      ...Object.entries(expensesByCategory).map(([cat, amt]) => ({ label: `Pengeluaran - ${categoryLabels[cat] || cat}`, amount: amt })),
      { label: 'Total Pengeluaran', amount: totalExpenses },
      { label: '', amount: null as number | null },
      { label: 'Laba Bersih', amount: grossProfit },
    ];

    const ledgerColumns: ExportColumn[] = [
      { header: 'Ref', key: 'ref', width: 100 },
      { header: 'Tanggal', key: 'date', width: 120 },
      { header: 'Deskripsi', key: 'description', width: 250 },
      { header: 'Kategori', key: 'category', width: 100 },
      { header: 'Debit', key: 'debit', width: 120 },
      { header: 'Kredit', key: 'credit', width: 120 },
      { header: 'Saldo', key: 'balance', width: 120 },
    ];
    const ledgerRows = [...ledgerEntries].reverse().map(e => ({
      ref: e.ref,
      date: formatDateTime(e.date),
      description: e.description,
      category: e.category,
      debit: e.debit || null,
      credit: e.credit || null,
      balance: e.balance,
    }));

    const expColumns: ExportColumn[] = [
      { header: 'Tanggal', key: 'date', width: 120 },
      { header: 'Kategori', key: 'category', width: 120 },
      { header: 'Deskripsi', key: 'description', width: 250 },
      { header: 'Jumlah', key: 'amount', width: 120 },
    ];
    const expRows = expenses.map(e => ({
      date: formatDate(e.expense_date),
      category: categoryLabels[e.category] || e.category,
      description: e.description || '',
      amount: Number(e.amount),
    }));

    exportToExcel(`Laporan-Keuangan-${period}`, [
      { title: `Laporan Laba Rugi — ${periodLabel}`, subtitle: `${settings?.store_name || 'MobizyPOS'} · ${dateStr}`, columns: pnlColumns, rows: pnlRows },
      { title: `Buku Besar — ${periodLabel}`, subtitle: `${ledgerEntries.length} transaksi`, columns: ledgerColumns, rows: ledgerRows, summaryRows: [
        { label: 'Total Debit', value: totalDebit },
        { label: 'Total Kredit', value: totalCredit },
        { label: 'Saldo Akhir', value: grossProfit },
      ]},
      { title: `Detail Pengeluaran — ${periodLabel}`, subtitle: `${expenses.length} transaksi`, columns: expColumns, rows: expRows, summaryRows: [{ label: 'Total Pengeluaran', value: totalExpenses }] },
    ]);
  };

  const handleExportCSV = () => {
    const columns: ExportColumn[] = [
      { header: 'Ref', key: 'ref' }, { header: 'Tanggal', key: 'date' }, { header: 'Deskripsi', key: 'description' },
      { header: 'Kategori', key: 'category' }, { header: 'Debit', key: 'debit' }, { header: 'Kredit', key: 'credit' }, { header: 'Saldo', key: 'balance' },
    ];
    const rows = [...ledgerEntries].reverse().map(e => ({
      ref: e.ref, date: formatDateTime(e.date), description: e.description, category: e.category,
      debit: e.debit || '', credit: e.credit || '', balance: e.balance,
    }));
    exportToCSV(`buku-besar-${period}-${new Date().toISOString().slice(0, 10)}`, columns, rows);
  };

  const rangeLabels: { id: DateRange; label: string }[] = [
    { id: 'today', label: 'Hari Ini' }, { id: '7d', label: '7 Hari' }, { id: '30d', label: '30 Hari' }, { id: 'all', label: 'Semua' },
  ];

  if (loading) {
    return (
      <div className="flex flex-1 items-center justify-center text-slate-400">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-teal-500/30 border-t-teal-500" />
      </div>
    );
  }

  // Smooth path helper for trend chart
  const trendW = 100, trendH = 100, trendPad = 10;
  const buildPath = (values: number[], maxVal: number) => {
    const points = values.map((v, i) => ({
      x: (i / (values.length - 1)) * trendW,
      y: trendH - trendPad - (v / maxVal) * (trendH - trendPad * 2),
    }));
    if (points.length < 2) return '';
    let path = `M ${points[0].x} ${points[0].y}`;
    for (let i = 0; i < points.length - 1; i++) {
      const p0 = points[i], p1 = points[i + 1];
      const cpX = (p0.x + p1.x) / 2;
      path += ` C ${cpX} ${p0.y} ${cpX} ${p1.y} ${p1.x} ${p1.y}`;
    }
    return path;
  };

  const incomePath = buildPath(dailyTrend.map(d => d.income), maxTrendValue);
  const expensePath = buildPath(dailyTrend.map(d => d.expense), maxTrendValue);
  const incomeAreaPath = `${incomePath} L ${trendW} ${trendH} L 0 ${trendH} Z`;

  const summaryCards = [
    { label: 'Pendapatan', value: formatCurrency(revenue, symbol), sub: `${orders.length} pesanan`, icon: TrendingUp },
    { label: 'Pengeluaran', value: formatCurrency(totalExpenses, symbol), sub: `${expenses.length} transaksi`, icon: TrendingDown },
    { label: 'Pajak Diterima', value: formatCurrency(totalTax, symbol), sub: 'Dari transaksi', icon: Receipt },
    { label: 'Laba Bersih', value: formatCurrency(grossProfit, symbol), sub: grossProfit >= 0 ? 'Surplus' : 'Defisit', icon: Wallet, highlight: grossProfit >= 0 ? 'text-emerald-600' : 'text-rose-600' },
  ];

  return (
    <div className="flex-1 overflow-y-auto bg-slate-50 p-4 sm:p-6">
      {/* Header */}
      <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-2">
          <div className={`flex h-9 w-9 items-center justify-center rounded-xl ${greyIcon}`}>
            <Calculator className="h-5 w-5" strokeWidth={1.5} />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-800">Akuntansi & Keuangan</h2>
            <p className="mt-0.5 text-sm text-slate-500">Kelola pengeluaran, buku besar, dan laporan keuangan</p>
          </div>
        </div>
        <div className="flex flex-wrap gap-1.5">
          <button
            onClick={() => onShowRevenueDetail?.()}
            className="flex items-center gap-2 rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm font-semibold text-slate-600 transition hover:border-teal-400 hover:text-teal-600"
          >
            <TrendingUp className="h-4 w-4" strokeWidth={1.5} />
            <span className="hidden sm:inline">Detail Pendapatan</span>
          </button>
          <button
            onClick={handleExportExcel}
            className="flex items-center gap-2 rounded-lg bg-teal-600 px-3 py-2 text-sm font-semibold text-white transition hover:bg-teal-700"
          >
            <FileSpreadsheet className="h-4 w-4" />
            <span className="hidden sm:inline">Export Excel</span>
          </button>
          <button
            onClick={() => setShowModal(true)}
            className="flex items-center gap-2 rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm font-semibold text-slate-600 transition hover:border-teal-400 hover:text-teal-600"
          >
            <Plus className="h-4 w-4" />
            <span className="hidden sm:inline">Pengeluaran</span>
          </button>
          <div className="flex gap-1.5 rounded-xl bg-white p-1 shadow-sm ring-1 ring-slate-200">
            {rangeLabels.map((r) => (
              <button
                key={r.id}
                onClick={() => setPeriod(r.id)}
                className={`rounded-lg px-3 py-2 text-xs font-semibold transition-all ${
                  period === r.id ? 'bg-teal-600 text-white shadow-md shadow-teal-600/20' : 'text-slate-500 hover:bg-slate-100'
                }`}
              >
                {r.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Tab switcher */}
      <div className="mb-4 flex gap-1.5 rounded-xl bg-white p-1 shadow-sm ring-1 ring-slate-200 sm:w-fit">
        <button
          onClick={() => setActiveTab('summary')}
          className={`flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-semibold transition ${
            activeTab === 'summary' ? 'bg-slate-800 text-white' : 'text-slate-500 hover:bg-slate-100'
          }`}
        >
          <Receipt className="h-4 w-4" strokeWidth={1.5} />
          Ringkasan
        </button>
        <button
          onClick={() => setActiveTab('ledger')}
          className={`flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-semibold transition ${
            activeTab === 'ledger' ? 'bg-slate-800 text-white' : 'text-slate-500 hover:bg-slate-100'
          }`}
        >
          <BookOpen className="h-4 w-4" strokeWidth={1.5} />
          Buku Besar
        </button>
      </div>

      {activeTab === 'summary' && (
        <>
          {/* Summary cards — matching Analytics style */}
          <div className="mb-4 grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">
            {summaryCards.map((card) => {
              const Icon = card.icon;
              return (
                <div key={card.label} className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
                  <div className="mb-2 flex items-center justify-between">
                    <span className="text-xs font-medium text-slate-500">{card.label}</span>
                    <div className={`rounded-lg p-1.5 ${greyIcon}`}>
                      <Icon className="h-4 w-4" strokeWidth={1.5} />
                    </div>
                  </div>
                  <p className={`text-lg font-bold ${card.highlight || 'text-slate-800'}`}>{card.value}</p>
                  <p className="mt-1 text-xs text-slate-400">{card.sub}</p>
                </div>
              );
            })}
          </div>

          {/* Cash flow trend chart — matching Analytics trend style */}
          <div className="mb-4 rounded-xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
            <div className="mb-5 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className={`flex h-9 w-9 items-center justify-center rounded-xl ${greyIcon}`}>
                  <BarChart3 className="h-5 w-5" strokeWidth={1.5} />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-800">Tren Arus Kas</h3>
                  <p className="text-xs text-slate-400">7 hari terakhir · Masuk vs Keluar</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <span className="flex items-center gap-1.5 text-xs text-slate-600">
                  <div className="h-2.5 w-2.5 rounded-full bg-teal-600" /> Masuk
                </span>
                <span className="flex items-center gap-1.5 text-xs text-slate-600">
                  <div className="h-2.5 w-2.5 rounded-full bg-rose-400" /> Keluar
                </span>
              </div>
            </div>

            <div className="relative">
              <svg viewBox={`0 0 ${trendW} ${trendH}`} preserveAspectRatio="none" className="w-full" style={{ height: '200px' }}>
                <defs>
                  <linearGradient id="incomeGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#0d9488" stopOpacity="0.2" />
                    <stop offset="100%" stopColor="#0d9488" stopOpacity="0" />
                  </linearGradient>
                </defs>
                {[0.2, 0.4, 0.6, 0.8].map((p) => (
                  <line key={p} x1="0" y1={trendH * p} x2={trendW} y2={trendH * p} stroke="#f1f5f9" strokeWidth="0.3" strokeDasharray="2 2" />
                ))}
                <path d={incomeAreaPath} fill="url(#incomeGrad)" />
                <path d={incomePath} fill="none" stroke="#0d9488" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                <path d={expensePath} fill="none" stroke="#f43f5e" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" strokeDasharray="1 1" />
                {dailyTrend.map((d, i) => {
                  const x = (i / (dailyTrend.length - 1)) * trendW;
                  const yInc = trendH - trendPad - (d.income / maxTrendValue) * (trendH - trendPad * 2);
                  return <circle key={i} cx={x} cy={yInc} r="2" fill="#fff" stroke="#0d9488" strokeWidth="1" />;
                })}
              </svg>
              <div className="absolute inset-0 flex">
                {dailyTrend.map((day, i) => (
                  <div key={i} className="group relative flex-1">
                    <div className="absolute inset-0 cursor-pointer" />
                    <div className="pointer-events-none absolute bottom-full left-1/2 z-10 mb-2 hidden -translate-x-1/2 whitespace-nowrap rounded-lg bg-slate-800 px-3 py-2 text-xs text-white shadow-lg group-hover:block">
                      <p className="font-semibold">{day.label}</p>
                      <p className="text-teal-300">Masuk: {formatCurrency(day.income, symbol)}</p>
                      <p className="text-rose-300">Keluar: {formatCurrency(day.expense, symbol)}</p>
                      <p className={day.net >= 0 ? 'text-emerald-300' : 'text-rose-300'}>Net: {formatCurrency(day.net, symbol)}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="mt-2 flex justify-between">
              {dailyTrend.map((day, i) => (
                <div key={i} className="flex-1 text-center">
                  <p className="text-[10px] font-medium text-slate-400">{day.label}</p>
                  <p className={`text-[9px] font-semibold ${day.net >= 0 ? 'text-teal-600' : 'text-rose-400'}`}>
                    {formatCurrency(day.net, symbol)}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* P&L Statement + Profit margin gauge */}
          <div className="mb-4 grid grid-cols-1 gap-4 lg:grid-cols-3">
            {/* P&L Statement - takes 2 cols */}
            <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5 lg:col-span-2">
              <div className="mb-4 flex items-center gap-2">
                <div className={`flex h-9 w-9 items-center justify-center rounded-xl ${greyIcon}`}>
                  <Scale className="h-5 w-5" strokeWidth={1.5} />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-800">Laporan Laba Rugi</h3>
                  <p className="text-xs text-slate-400">Breakdown pendapatan & pengeluaran</p>
                </div>
              </div>
              <div className="space-y-1">
                <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-teal-600">Pendapatan</p>
                {Object.entries(revenueByPayment).map(([method, amt]) => (
                  <div key={method} className="flex justify-between py-1 text-sm">
                    <span className="pl-4 text-slate-600">{paymentLabels[method] || method}</span>
                    <span className="font-medium text-slate-800">{formatCurrency(amt, symbol)}</span>
                  </div>
                ))}
                {Object.keys(revenueByPayment).length === 0 && (
                  <p className="py-1 pl-4 text-sm text-slate-400">Belum ada data</p>
                )}
                <div className="flex justify-between border-b border-slate-100 py-1.5 text-sm font-bold">
                  <span className="text-slate-700">Total Pendapatan</span>
                  <span className="text-teal-600">{formatCurrency(revenue, symbol)}</span>
                </div>

                <p className="mb-2 mt-4 text-xs font-semibold uppercase tracking-wide text-rose-600">Pengeluaran</p>
                {Object.entries(expensesByCategory).map(([cat, amt]) => (
                  <div key={cat} className="flex justify-between py-1 text-sm">
                    <span className="pl-4 text-slate-600">{categoryLabels[cat] || cat}</span>
                    <span className="font-medium text-slate-800">{formatCurrency(amt, symbol)}</span>
                  </div>
                ))}
                {Object.keys(expensesByCategory).length === 0 && (
                  <p className="py-1 pl-4 text-sm text-slate-400">Belum ada pengeluaran</p>
                )}
                <div className="flex justify-between border-b border-slate-100 py-1.5 text-sm font-bold">
                  <span className="text-slate-700">Total Pengeluaran</span>
                  <span className="text-rose-600">{formatCurrency(totalExpenses, symbol)}</span>
                </div>

                <div className="mt-3 flex justify-between rounded-lg bg-slate-50 px-4 py-3 text-base font-bold">
                  <span className="text-slate-800">Laba Bersih</span>
                  <span className={grossProfit >= 0 ? 'text-emerald-600' : 'text-rose-600'}>{formatCurrency(grossProfit, symbol)}</span>
                </div>
              </div>
            </div>

            {/* Profit margin gauge — matching Analytics gauge style */}
            <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
              <div className="mb-4 flex items-center gap-2">
                <div className={`flex h-9 w-9 items-center justify-center rounded-xl ${greyIcon}`}>
                  <PieChart className="h-5 w-5" strokeWidth={1.5} />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-800">Margin Keuntungan</h3>
                  <p className="text-xs text-slate-400">Rasio laba terhadap pendapatan</p>
                </div>
              </div>
              <div className="flex flex-col items-center">
                <div className="relative">
                  <svg viewBox="0 0 120 120" className="h-32 w-32">
                    <defs>
                      <linearGradient id="profitGrad" x1="0" y1="0" x2="1" y2="1">
                        <stop offset="0%" stopColor="#0d9488" />
                        <stop offset="100%" stopColor="#0891b2" />
                      </linearGradient>
                    </defs>
                    <circle cx="60" cy="60" r="52" fill="none" stroke="#f1f5f9" strokeWidth="10" />
                    <circle
                      cx="60" cy="60" r="52"
                      fill="none"
                      stroke="url(#profitGrad)"
                      strokeWidth="10"
                      strokeLinecap="round"
                      strokeDasharray={2 * Math.PI * 52}
                      strokeDashoffset={2 * Math.PI * 52 * (1 - Math.max(0, Math.min(1, profitMargin / 100)))}
                      transform="rotate(-90 60 60)"
                      className="transition-all duration-1000"
                    />
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <p className="text-2xl font-bold text-slate-800">{profitMargin.toFixed(0)}%</p>
                    <p className="text-[10px] text-slate-400">margin</p>
                  </div>
                </div>
                <div className="mt-4 w-full space-y-2">
                  <div className="flex items-center justify-between rounded-lg bg-slate-50 px-3 py-2">
                    <span className="text-xs text-slate-500">Rasio Pengeluaran</span>
                    <span className="text-xs font-bold text-rose-600">{expenseRatio.toFixed(0)}%</span>
                  </div>
                  <div className="flex items-center justify-between rounded-lg bg-slate-50 px-3 py-2">
                    <span className="text-xs text-slate-500">Penjualan Bersih</span>
                    <span className="text-xs font-bold text-slate-700">{formatCurrency(netSales, symbol)}</span>
                  </div>
                  <div className="flex items-center justify-between rounded-lg bg-slate-50 px-3 py-2">
                    <span className="text-xs text-slate-500">Pajak Terkumpul</span>
                    <span className="text-xs font-bold text-slate-700">{formatCurrency(totalTax, symbol)}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Expense by category — matching Analytics category bar style */}
          {Object.keys(expensesByCategory).length > 0 && (
            <div className="mb-4 rounded-xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
              <div className="mb-4 flex items-center gap-2">
                <div className={`flex h-9 w-9 items-center justify-center rounded-xl ${greyIcon}`}>
                  <PieChart className="h-5 w-5" strokeWidth={1.5} />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-800">Pengeluaran per Kategori</h3>
                  <p className="text-xs text-slate-400">Distribusi belanja operasional</p>
                </div>
              </div>
              <div className="space-y-4">
                {Object.entries(expensesByCategory).sort((a, b) => b[1] - a[1]).map(([cat, amt]) => {
                  const pct = totalExpenses > 0 ? (amt / totalExpenses) * 100 : 0;
                  const color = categoryBarColors[cat] || '#64748b';
                  return (
                    <div key={cat}>
                      <div className="mb-2 flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="h-3 w-3 rounded-sm" style={{ backgroundColor: color }} />
                          <span className="text-sm font-medium text-slate-700">{categoryLabels[cat] || cat}</span>
                          <span className="rounded-full bg-slate-100 px-2 py-0.5 text-[10px] text-slate-500">{pct.toFixed(0)}%</span>
                        </div>
                        <span className="text-sm font-semibold text-slate-800">{formatCurrency(amt, symbol)}</span>
                      </div>
                      <div className="h-3 overflow-hidden rounded-full bg-slate-100">
                        <div
                          className="h-full rounded-full transition-all duration-700"
                          style={{ width: `${pct}%`, background: `linear-gradient(to right, ${color}, ${color}dd)` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Expense list */}
          <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
            <div className="mb-4 flex items-center gap-2">
              <div className={`flex h-9 w-9 items-center justify-center rounded-xl ${greyIcon}`}>
                <Receipt className="h-5 w-5" strokeWidth={1.5} />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-800">Riwayat Pengeluaran</h3>
                <p className="text-xs text-slate-400">{expenses.length} transaksi tercatat</p>
              </div>
            </div>
            {expenses.length === 0 ? (
              <div className="flex h-20 items-center justify-center text-sm text-slate-400">Belum ada pengeluaran</div>
            ) : (
              <div className="space-y-2">
                {expenses.map((exp) => (
                  <div key={exp.id} className="flex items-center justify-between rounded-lg border border-slate-100 p-3 transition hover:border-slate-200 hover:bg-slate-50">
                    <div className="flex items-center gap-3">
                      <div className="flex h-9 w-9 items-center justify-center rounded-lg" style={{ backgroundColor: (categoryBarColors[exp.category] || '#64748b') + '20' }}>
                        <Wallet className="h-4 w-4" style={{ color: categoryBarColors[exp.category] || '#64748b' }} />
                      </div>
                      <div>
                        <p className="text-sm font-medium text-slate-800">{exp.description || categoryLabels[exp.category]}</p>
                        <div className="flex items-center gap-2">
                          <span className={`rounded px-1.5 py-0.5 text-xs ${categoryColors[exp.category] || categoryColors.other}`}>
                            {categoryLabels[exp.category] || exp.category}
                          </span>
                          <span className="text-xs text-slate-400">{formatDate(exp.expense_date)}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-sm font-bold text-rose-600">-{formatCurrency(exp.amount, symbol)}</span>
                      <button
                        onClick={() => handleDelete(exp.id)}
                        className="rounded-lg p-1.5 text-slate-300 transition hover:bg-red-50 hover:text-red-500"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </>
      )}

      {activeTab === 'ledger' && (
        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
          <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-2">
              <div className={`flex h-9 w-9 items-center justify-center rounded-xl ${greyIcon}`}>
                <BookOpen className="h-5 w-5" strokeWidth={1.5} />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-800">Buku Besar</h3>
                <p className="text-xs text-slate-400">{filteredLedger.length} transaksi · Saldo berjalan · Halaman {ledgerPage + 1} dari {Math.max(pageCount, 1)}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1 rounded-lg border border-slate-200 p-0.5">
                <Filter className="ml-1 h-3.5 w-3.5 text-slate-400" />
                {(['all', 'income', 'expense'] as const).map(f => (
                  <button
                    key={f}
                    onClick={() => setLedgerFilter(f)}
                    className={`rounded-md px-2.5 py-1 text-xs font-medium transition ${
                      ledgerFilter === f ? 'bg-slate-800 text-white' : 'text-slate-500 hover:bg-slate-100'
                    }`}
                  >
                    {f === 'all' ? 'Semua' : f === 'income' ? 'Masuk' : 'Keluar'}
                  </button>
                ))}
              </div>
              <button
                onClick={handleExportCSV}
                className="flex items-center gap-1.5 rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-semibold text-slate-600 transition hover:border-teal-400 hover:text-teal-600"
              >
                <Download className="h-3.5 w-3.5" strokeWidth={1.5} />
                CSV
              </button>
              <button
                onClick={handleExportExcel}
                className="flex items-center gap-1.5 rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-semibold text-slate-600 transition hover:border-teal-400 hover:text-teal-600"
              >
                <FileSpreadsheet className="h-3.5 w-3.5" strokeWidth={1.5} />
                Excel
              </button>
            </div>
          </div>

          {filteredLedger.length === 0 ? (
            <div className="flex h-24 items-center justify-center text-sm text-slate-400">Belum ada transaksi</div>
          ) : (
            <>
              {/* Mobile ledger cards */}
              <div className="space-y-2 lg:hidden">
                {pagedLedger.map((entry) => (
                  <div key={entry.id} className={`rounded-lg border p-3 ${entry.type === 'income' ? 'border-teal-100 bg-teal-50/30' : 'border-rose-100 bg-rose-50/30'}`}>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className={`flex h-7 w-7 items-center justify-center rounded-lg ${entry.type === 'income' ? 'bg-teal-100' : 'bg-rose-100'}`}>
                          {entry.type === 'income' ? <ArrowUpRight className="h-4 w-4 text-teal-600" strokeWidth={1.5} /> : <ArrowDownRight className="h-4 w-4 text-rose-600" strokeWidth={1.5} />}
                        </div>
                        <div>
                          <p className="text-sm font-medium text-slate-800">{entry.description}</p>
                          <p className="text-xs text-slate-400">{formatDate(entry.date)} · {entry.ref}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className={`text-sm font-bold ${entry.type === 'income' ? 'text-teal-600' : 'text-rose-600'}`}>
                          {entry.type === 'income' ? '+' : '-'}{formatCurrency(entry.debit || entry.credit, symbol)}
                        </p>
                        <p className="text-xs text-slate-400">Saldo: {formatCurrency(entry.balance, symbol)}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Desktop ledger table */}
              <div className="hidden overflow-x-auto lg:block">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-slate-200 bg-slate-50 text-left text-xs text-slate-600">
                      <th className="px-3 py-3 font-semibold">Ref</th>
                      <th className="px-3 py-3 font-semibold">Tanggal</th>
                      <th className="px-3 py-3 font-semibold">Deskripsi</th>
                      <th className="px-3 py-3 font-semibold">Kategori</th>
                      <th className="px-3 py-3 text-right font-semibold">Debit</th>
                      <th className="px-3 py-3 text-right font-semibold">Kredit</th>
                      <th className="px-3 py-3 text-right font-semibold">Saldo</th>
                    </tr>
                  </thead>
                  <tbody>
                    {pagedLedger.map((entry) => (
                      <tr key={entry.id} className="border-b border-slate-50 transition hover:bg-slate-50/50 last:border-0">
                        <td className="px-3 py-2.5 text-xs font-medium text-slate-400">{entry.ref}</td>
                        <td className="px-3 py-2.5 text-slate-500">{formatDate(entry.date)}</td>
                        <td className="px-3 py-2.5">
                          <div className="flex items-center gap-2">
                            {entry.type === 'income' ? (
                              <ArrowUpRight className="h-3.5 w-3.5 text-teal-500" strokeWidth={1.5} />
                            ) : (
                              <ArrowDownRight className="h-3.5 w-3.5 text-rose-500" strokeWidth={1.5} />
                            )}
                            <span className="font-medium text-slate-800">{entry.description}</span>
                          </div>
                        </td>
                        <td className="px-3 py-2.5">
                          <span className={`rounded px-1.5 py-0.5 text-xs font-medium ${
                            entry.type === 'income' ? 'bg-teal-50 text-teal-600' : 'bg-slate-100 text-slate-600'
                          }`}>
                            {entry.category}
                          </span>
                        </td>
                        <td className="px-3 py-2.5 text-right font-semibold text-teal-600">{entry.debit > 0 ? formatCurrency(entry.debit, symbol) : '—'}</td>
                        <td className="px-3 py-2.5 text-right font-semibold text-rose-600">{entry.credit > 0 ? formatCurrency(entry.credit, symbol) : '—'}</td>
                        <td className={`px-3 py-2.5 text-right font-bold ${entry.balance >= 0 ? 'text-slate-800' : 'text-rose-600'}`}>{formatCurrency(entry.balance, symbol)}</td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot>
                    <tr className="border-t-2 border-slate-200 bg-slate-50">
                      <td colSpan={4} className="px-3 py-3 text-right text-xs font-bold uppercase text-slate-500">Total</td>
                      <td className="px-3 py-3 text-right font-bold text-teal-600">{formatCurrency(totalDebit, symbol)}</td>
                      <td className="px-3 py-3 text-right font-bold text-rose-600">{formatCurrency(totalCredit, symbol)}</td>
                      <td className={`px-3 py-3 text-right font-bold ${grossProfit >= 0 ? 'text-teal-600' : 'text-rose-600'}`}>{formatCurrency(grossProfit, symbol)}</td>
                    </tr>
                  </tfoot>
                </table>
              </div>

              {/* Pagination */}
              {pageCount > 1 && (
                <div className="mt-4 flex items-center justify-between">
                  <button
                    onClick={() => setLedgerPage(p => Math.max(0, p - 1))}
                    disabled={ledgerPage === 0}
                    className="rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-semibold text-slate-600 transition hover:bg-slate-50 disabled:opacity-40"
                  >
                    ← Sebelumnya
                  </button>
                  <div className="flex items-center gap-1">
                    {Array.from({ length: Math.min(pageCount, 7) }, (_, i) => {
                      const page = i;
                      return (
                        <button
                          key={page}
                          onClick={() => setLedgerPage(page)}
                          className={`flex h-7 w-7 items-center justify-center rounded-lg text-xs font-semibold transition ${
                            ledgerPage === page ? 'bg-teal-600 text-white' : 'text-slate-500 hover:bg-slate-100'
                          }`}
                        >
                          {page + 1}
                        </button>
                      );
                    })}
                  </div>
                  <button
                    onClick={() => setLedgerPage(p => Math.min(pageCount - 1, p + 1))}
                    disabled={ledgerPage >= pageCount - 1}
                    className="rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-semibold text-slate-600 transition hover:bg-slate-50 disabled:opacity-40"
                  >
                    Berikutnya →
                  </button>
                </div>
              )}
            </>
          )}
        </div>
      )}

      {showModal && (
        <ExpenseModal onClose={() => setShowModal(false)} onSaved={() => { setShowModal(false); }} symbol={symbol} />
      )}
    </div>
  );
}

function ExpenseModal({ onClose, onSaved, symbol }: { onClose: () => void; onSaved: () => void; symbol: string }) {
  const [category, setCategory] = useState<ExpenseCategory>('inventory');
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [expenseDate, setExpenseDate] = useState(new Date().toISOString().slice(0, 10));
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const handleSave = async () => {
    setSaving(true);
    setError('');
    const amt = parseFloat(amount) || 0;
    if (amt <= 0) { setError('Jumlah harus lebih dari 0'); setSaving(false); return; }
    try {
      await api.post('/expenses', { category, description: description.trim(), amount: amt, expense_date: expenseDate });
    } catch (e) { setError(errorMessage(e)); setSaving(false); return; }
    setSaving(false);
    onSaved();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-slate-900/50 backdrop-blur-sm sm:items-center sm:p-4">
      <div className="w-full max-w-md rounded-t-2xl bg-white shadow-2xl animate-slide-in-up sm:rounded-2xl">
        <div className="flex items-center justify-between border-b border-slate-200 px-5 py-4 sm:px-6">
          <h2 className="text-lg font-bold text-slate-800">Tambah Pengeluaran</h2>
          <button onClick={onClose} disabled={saving} className="rounded-lg p-1 text-slate-400 transition hover:bg-slate-100 hover:text-slate-600 disabled:opacity-40">
            <X className="h-5 w-5" />
          </button>
        </div>
        <div className="px-5 py-5 sm:px-6">
          <div className="space-y-4">
            <div>
              <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">Kategori</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as ExpenseCategory)}
                className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:border-teal-500 focus:bg-white"
              >
                {Object.entries(categoryLabels).map(([key, label]) => (
                  <option key={key} value={key}>{label}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">Deskripsi</label>
              <input
                type="text"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:border-teal-500 focus:bg-white"
                placeholder="Contoh: Sewa toko Oktober"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">Jumlah ({symbol || 'Rp'})</label>
                <input
                  type="number"
                  step="1000"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:border-teal-500 focus:bg-white"
                  placeholder="0"
                  autoFocus
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">Tanggal</label>
                <input
                  type="date"
                  value={expenseDate}
                  onChange={(e) => setExpenseDate(e.target.value)}
                  className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:border-teal-500 focus:bg-white"
                />
              </div>
            </div>
          </div>
          {error && (
            <div className="mt-4 flex items-center gap-2 rounded-lg bg-red-50 px-4 py-2.5 text-sm text-red-600">
              <AlertCircle className="h-4 w-4 flex-shrink-0" />
              {error}
            </div>
          )}
          <div className="mt-5 flex gap-3">
            <button onClick={onClose} disabled={saving} className="flex-1 rounded-xl border border-slate-200 py-2.5 text-sm font-semibold text-slate-600 transition hover:bg-slate-50 disabled:opacity-40">
              Batal
            </button>
            <button onClick={handleSave} disabled={saving} className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-teal-600 py-2.5 text-sm font-bold text-white transition hover:bg-teal-700 disabled:opacity-40">
              {saving ? <div className="h-4 w-4 animate-spin rounded-full border-2 border-white/30 border-t-white" /> : 'Simpan'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
