import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { UserPlus, Loader2 } from 'lucide-react';
import { api, errorMessage } from '@/lib/api';
import { useAuth } from '@/context/AuthContext';
import type { StaffUser } from '@/types';

const field = 'w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:border-blue-500 focus:bg-white';
const roleLabel: Record<string, string> = { owner: 'Pemilik', admin: 'Admin', cashier: 'Kasir', customer: 'Pelanggan' };

export function TeamManagement() {
  const { role: myRole } = useAuth();
  const [users, setUsers] = useState<StaffUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<'cashier' | 'admin'>('cashier');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    try { setUsers(await api.get<StaffUser[]>('/users')); } catch (e) { setError(errorMessage(e)); }
    setLoading(false);
  }, []);
  useEffect(() => { load(); }, [load]);

  const add = async (e: FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setError('');
    try {
      await api.post('/users', { display_name: name, email, password, role });
      setName(''); setEmail(''); setPassword('');
      await load();
    } catch (err) {
      setError(errorMessage(err));
    }
    setSaving(false);
  };

  const toggle = async (u: StaffUser) => {
    try { await api.patch(`/users/${u.id}`, { is_active: !u.is_active }); await load(); } catch (e) { setError(errorMessage(e)); }
  };

  const canEdit = (u: StaffUser) => u.role === 'cashier' || (u.role === 'admin' && myRole === 'owner');

  return (
    <div className="flex-1 overflow-y-auto bg-slate-50 p-4 sm:p-6">
      <div className="mx-auto max-w-2xl space-y-5">
        <h2 className="text-lg font-bold text-slate-800">Tim</h2>

        <form onSubmit={add} className="space-y-3 rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
          <h3 className="flex items-center gap-2 text-sm font-bold text-slate-800"><UserPlus className="h-4 w-4" /> Tambah akun</h3>
          <input className={field} placeholder="Nama" value={name} required onChange={(e) => setName(e.target.value)} />
          <input className={field} type="email" placeholder="Email" value={email} required onChange={(e) => setEmail(e.target.value)} />
          <input className={field} type="password" placeholder="Password awal (min. 10 karakter)" value={password} required minLength={10} autoComplete="new-password" onChange={(e) => setPassword(e.target.value)} />
          <select className={field} value={role} onChange={(e) => setRole(e.target.value as 'cashier' | 'admin')}>
            <option value="cashier">Kasir</option>
            {myRole === 'owner' && <option value="admin">Admin</option>}
          </select>
          {error && <p role="alert" className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-600">{error}</p>}
          <button disabled={saving} className="flex items-center gap-2 rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-700 disabled:opacity-60">
            {saving && <Loader2 className="h-4 w-4 animate-spin" />} Simpan
          </button>
        </form>

        <div className="divide-y divide-slate-100 rounded-xl border border-slate-200 bg-white shadow-sm">
          {loading && <p className="p-4 text-sm text-slate-400">Memuat...</p>}
          {users.map((u) => (
            <div key={u.id} className="flex items-center gap-3 p-3.5">
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-semibold text-slate-800">{u.display_name}</p>
                <p className="truncate text-xs text-slate-500">{u.email} · {roleLabel[u.role]}</p>
              </div>
              {!u.is_active && <span className="rounded bg-slate-100 px-2 py-0.5 text-xs text-slate-500">Nonaktif</span>}
              {canEdit(u) && (
                <button onClick={() => toggle(u)} className="rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-medium text-slate-600 hover:bg-slate-50">
                  {u.is_active ? 'Nonaktifkan' : 'Aktifkan'}
                </button>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
