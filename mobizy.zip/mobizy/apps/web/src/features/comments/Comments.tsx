import { useEffect, useState } from 'react';
import { MessageSquare, Star, Send, Trash2, X, ThumbsUp, ThumbsDown, Meh } from 'lucide-react';
import { api, errorMessage } from '@/lib/api';
import { useStore } from '@/context/StoreContext';
import { formatDateTime } from '@/lib/format';
import type { Comment, UserRole } from '@/types';

export function Comments({ role }: { role: UserRole }) {
  const { products } = useStore();
  const [comments, setComments] = useState<Comment[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);

  const [authorName, setAuthorName] = useState('');
  const [content, setContent] = useState('');
  const [rating, setRating] = useState(5);
  const [productId, setProductId] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [filterProduct, setFilterProduct] = useState('all');
  const [filterRating, setFilterRating] = useState('all');

  const canManage = role !== 'customer'; // staff get filters
  const canDelete = role === 'owner' || role === 'admin'; // only managers may delete reviews
  const isCustomer = role === 'customer';

  const fetchComments = async () => {
    try {
      const data = await api.get<Comment[]>('/comments');
      setComments(filterProduct === 'all' ? data : data.filter((c) => c.product_id === filterProduct));
    } catch (e) {
      console.error(e);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchComments();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filterProduct]);

  const handleSubmit = async () => {
    if (!content.trim()) {
      setError('Tulis komentar terlebih dahulu');
      return;
    }
    setSubmitting(true);
    setError('');

    try {
      await api.post('/comments', {
        author_name: authorName.trim() || undefined,
        content: content.trim(),
        rating,
        product_id: productId || null,
      });
    } catch (e) {
      setError(errorMessage(e));
      setSubmitting(false);
      return;
    }

    setAuthorName('');
    setContent('');
    setRating(5);
    setProductId('');
    setShowForm(false);
    setSubmitting(false);
    await fetchComments();
  };

  const handleDelete = async (id: string) => {
    try {
      await api.del(`/comments/${id}`);
    } catch (e) {
      console.error(e);
      return;
    }
    await fetchComments();
  };

  const avgRating =
    comments.length > 0
      ? (comments.reduce((s, c) => s + c.rating, 0) / comments.length).toFixed(1)
      : '0.0';

  const positiveCount = comments.filter((c) => c.rating >= 4).length;
  const neutralCount = comments.filter((c) => c.rating === 3).length;
  const negativeCount = comments.filter((c) => c.rating <= 2).length;

  const productName = (id: string | null) => {
    if (!id) return null;
    return products.find((p) => p.id === id)?.name || null;
  };

  const filtered = filterRating === 'all' ? comments : comments.filter((c) => {
    if (filterRating === 'positive') return c.rating >= 4;
    if (filterRating === 'neutral') return c.rating === 3;
    if (filterRating === 'negative') return c.rating <= 2;
    return true;
  });

  if (loading) {
    return (
      <div className="flex flex-1 items-center justify-center text-slate-400">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-teal-500/30 border-t-teal-500" />
      </div>
    );
  }

  return (
    <div className="flex flex-1 flex-col overflow-hidden">
      {/* Header */}
      <div className="border-b border-slate-200 bg-white px-4 py-3 sm:px-5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <MessageSquare className="h-5 w-5 text-teal-600" />
            <h2 className="text-lg font-bold text-slate-800">Ulasan & Komentar</h2>
          </div>
          <button
            onClick={() => setShowForm(true)}
            className="flex items-center gap-2 rounded-lg bg-teal-600 px-3 py-2 text-sm font-semibold text-white transition hover:bg-teal-700 sm:px-4"
          >
            <Send className="h-4 w-4" />
            <span className="hidden sm:inline">Tulis Ulasan</span>
          </button>
        </div>

        {/* Sentiment summary */}
        <div className="mt-3 grid grid-cols-4 gap-2">
          <div className="flex items-center gap-2 rounded-lg bg-amber-50 px-3 py-2">
            <Star className="h-4 w-4 fill-amber-400 text-amber-400" />
            <div>
              <p className="text-sm font-bold text-slate-700">{avgRating}</p>
              <p className="text-[10px] text-slate-400">Rating</p>
            </div>
          </div>
          <div className="flex items-center gap-2 rounded-lg bg-emerald-50 px-3 py-2">
            <ThumbsUp className="h-4 w-4 text-emerald-600" />
            <div>
              <p className="text-sm font-bold text-emerald-700">{positiveCount}</p>
              <p className="text-[10px] text-emerald-500">Positif</p>
            </div>
          </div>
          <div className="flex items-center gap-2 rounded-lg bg-slate-100 px-3 py-2">
            <Meh className="h-4 w-4 text-slate-500" />
            <div>
              <p className="text-sm font-bold text-slate-600">{neutralCount}</p>
              <p className="text-[10px] text-slate-400">Netral</p>
            </div>
          </div>
          <div className="flex items-center gap-2 rounded-lg bg-rose-50 px-3 py-2">
            <ThumbsDown className="h-4 w-4 text-rose-600" />
            <div>
              <p className="text-sm font-bold text-rose-700">{negativeCount}</p>
              <p className="text-[10px] text-rose-400">Negatif</p>
            </div>
          </div>
        </div>

        {/* Filters - only for admin/cashier */}
        {canManage && (
          <div className="mt-3 flex flex-col gap-2 sm:flex-row">
            <select
              value={filterProduct}
              onChange={(e) => setFilterProduct(e.target.value)}
              className="flex-1 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm outline-none focus:border-teal-500 focus:bg-white"
            >
              <option value="all">Semua Produk</option>
              {products.map((p) => (
                <option key={p.id} value={p.id}>{p.name}</option>
              ))}
            </select>
            <select
              value={filterRating}
              onChange={(e) => setFilterRating(e.target.value)}
              className="flex-1 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm outline-none focus:border-teal-500 focus:bg-white sm:flex-none sm:w-40"
            >
              <option value="all">Semua Rating</option>
              <option value="positive">Positif (4-5)</option>
              <option value="neutral">Netral (3)</option>
              <option value="negative">Negatif (1-2)</option>
            </select>
          </div>
        )}
      </div>

      {/* Comments list */}
      <div className="flex-1 overflow-y-auto bg-slate-50 p-4 sm:p-5">
        {filtered.length === 0 ? (
          <div className="flex h-full flex-col items-center justify-center text-slate-400">
            <MessageSquare className="mb-3 h-12 w-12" />
            <p className="text-sm font-medium">Belum ada ulasan</p>
            <p className="text-xs">Jadilah yang pertama memberi ulasan</p>
          </div>
        ) : (
          <div className="mx-auto max-w-2xl space-y-3">
            {filtered.map((comment) => {
              const pName = productName(comment.product_id);
              const sentiment = comment.rating >= 4 ? 'positive' : comment.rating === 3 ? 'neutral' : 'negative';
              const sentimentCls = sentiment === 'positive' ? 'bg-emerald-50 text-emerald-600' : sentiment === 'neutral' ? 'bg-slate-100 text-slate-500' : 'bg-rose-50 text-rose-600';
              const SentimentIcon = sentiment === 'positive' ? ThumbsUp : sentiment === 'neutral' ? Meh : ThumbsDown;
              return (
                <div
                  key={comment.id}
                  className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm transition hover:shadow-md animate-fade-in"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-3">
                      <div className="flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-teal-400 to-teal-600 text-sm font-bold text-white">
                        {comment.author_name.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <p className="text-sm font-semibold text-slate-800">{comment.author_name}</p>
                          {pName && (
                            <span className="rounded bg-slate-100 px-1.5 py-0.5 text-xs text-slate-500">{pName}</span>
                          )}
                        </div>
                        <div className="mt-0.5 flex items-center gap-1">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <Star
                              key={star}
                              className={`h-3.5 w-3.5 ${star <= comment.rating ? 'fill-teal-500 text-teal-500' : 'text-slate-200'}`}
                            />
                          ))}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-1">
                      <span className={`flex items-center gap-1 rounded-lg px-2 py-0.5 text-xs ${sentimentCls}`}>
                        <SentimentIcon className="h-3 w-3" />
                      </span>
                      {canDelete && (
                        <button
                          onClick={() => handleDelete(comment.id)}
                          className="rounded-lg p-1.5 text-slate-300 transition hover:bg-red-50 hover:text-red-500"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      )}
                    </div>
                  </div>
                  <p className="mt-2.5 text-sm text-slate-600">{comment.content}</p>
                  <p className="mt-2 text-xs text-slate-400">{formatDateTime(comment.created_at)}</p>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* New comment modal */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-slate-900/50 backdrop-blur-sm sm:items-center sm:p-4">
          <div className="w-full max-w-md rounded-t-2xl bg-white shadow-2xl animate-slide-in-up sm:rounded-2xl">
            <div className="flex items-center justify-between border-b border-slate-200 px-5 py-4 sm:px-6">
              <h2 className="text-lg font-bold text-slate-800">Tulis Ulasan</h2>
              <button
                onClick={() => setShowForm(false)}
                disabled={submitting}
                className="rounded-lg p-1 text-slate-400 transition hover:bg-slate-100 hover:text-slate-600 disabled:opacity-40"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="px-5 py-5 sm:px-6">
              <div className="space-y-4">
                <div>
                  <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">Nama</label>
                  <input
                    type="text"
                    value={authorName}
                    onChange={(e) => setAuthorName(e.target.value)}
                    placeholder="Anonim"
                    className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:border-teal-500 focus:bg-white"
                  />
                </div>

                <div>
                  <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">Produk (opsional)</label>
                  <select
                    value={productId}
                    onChange={(e) => setProductId(e.target.value)}
                    className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:border-teal-500 focus:bg-white"
                  >
                    <option value="">Umum / Toko</option>
                    {products.map((p) => (
                      <option key={p.id} value={p.id}>{p.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-500">Rating</label>
                  <div className="flex items-center gap-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button key={star} onClick={() => setRating(star)} className="transition active:scale-90">
                        <Star className={`h-7 w-7 ${star <= rating ? 'fill-teal-500 text-teal-500' : 'text-slate-300'}`} />
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">Komentar</label>
                  <textarea
                    value={content}
                    onChange={(e) => setContent(e.target.value)}
                    rows={3}
                    placeholder="Tulis ulasan atau komentar..."
                    className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:border-teal-500 focus:bg-white"
                  />
                </div>
              </div>

              {error && (
                <div className="mt-3 rounded-lg bg-red-50 px-4 py-2.5 text-sm text-red-600">{error}</div>
              )}

              <div className="mt-5 flex gap-3">
                <button
                  onClick={() => setShowForm(false)}
                  disabled={submitting}
                  className="flex-1 rounded-xl border border-slate-200 py-2.5 text-sm font-semibold text-slate-600 transition hover:bg-slate-50 disabled:opacity-40"
                >
                  Batal
                </button>
                <button
                  onClick={handleSubmit}
                  disabled={submitting}
                  className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-teal-600 py-2.5 text-sm font-bold text-white transition hover:bg-teal-700 disabled:opacity-40"
                >
                  {submitting ? (
                    <div className="h-4 w-4 animate-spin rounded-full border-2 border-white/30 border-t-white" />
                  ) : (
                    <><Send className="h-4 w-4" /> Kirim Ulasan</>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
