import { useState } from 'react';
import { Plus, Pencil, Trash2, X, TicketPercent, AlertCircle, Copy, Gift } from 'lucide-react';
import { api, errorMessage } from '@/lib/api';
import { useStore } from '@/context/StoreContext';
import { formatCurrency } from '@/lib/format';
import type { Voucher } from '@/types';

export function VoucherManagement() {
  const { vouchers, settings, refreshVouchers } = useStore();
  const [editing, setEditing] = useState<Voucher | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState<Voucher | null>(null);

  const symbol = settings?.currency_symbol || 'Rp';

  const openAdd = () => {
    setEditing(null);
    setShowModal(true);
  };

  const openEdit = (voucher: Voucher) => {
    setEditing(voucher);
    setShowModal(true);
  };

  const handleDelete = async () => {
    if (!confirmDelete) return;
    try {
      await api.del(`/vouchers/${confirmDelete.id}`);
    } catch (e) {
      console.error(e);
      return;
    }
    setConfirmDelete(null);
    await refreshVouchers();
  };

  const toggleActive = async (voucher: Voucher) => {
    try {
      await api.patch(`/vouchers/${voucher.id}`, { is_active: !voucher.is_active });
    } catch (e) {
      console.error(e);
    }
    await refreshVouchers();
  };

  const isExpired = (v: Voucher) => v.valid_until && new Date(v.valid_until) < new Date();
  const isExhausted = (v: Voucher) => v.usage_limit !== null && v.used_count >= v.usage_limit;

  return (
    <div className="flex flex-1 flex-col overflow-hidden">
      <div className="flex items-center justify-between border-b border-slate-200 bg-white px-4 py-3 sm:px-5">
        <div className="flex items-center gap-2">
          <TicketPercent className="h-5 w-5 text-blue-600" />
          <h2 className="text-lg font-bold text-slate-800">Voucher & Diskon</h2>
        </div>
        <button
          onClick={openAdd}
          className="flex items-center gap-2 rounded-lg bg-blue-600 px-3 py-2 text-sm font-semibold text-white transition hover:bg-blue-700 sm:px-4"
        >
          <Plus className="h-4 w-4" />
          <span className="hidden sm:inline">Tambah Voucher</span>
        </button>
      </div>

      <div className="flex-1 overflow-y-auto bg-slate-50 p-3 sm:p-5">
        {vouchers.length === 0 ? (
          <div className="flex h-full flex-col items-center justify-center text-slate-400">
            <TicketPercent className="mb-3 h-12 w-12" />
            <p className="text-sm font-medium">Belum ada voucher</p>
            <p className="text-xs">Buat voucher diskon pertama Anda</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {vouchers.map((voucher) => {
              const expired = isExpired(voucher);
              const exhausted = isExhausted(voucher);
              const inactive = !voucher.is_active;
              const statusBad = expired || exhausted || inactive;

              return (
                <div
                  key={voucher.id}
                  className={`rounded-xl border bg-white p-4 shadow-sm transition ${
                    statusBad ? 'border-slate-200 opacity-60' : 'border-slate-200 hover:shadow-md'
                  }`}
                >
                  <div className="mb-3 flex items-start justify-between">
                    <div className="flex items-center gap-2">
                      <div className={`flex h-10 w-10 items-center justify-center rounded-lg ${
                        statusBad ? 'bg-slate-100' : voucher.discount_type === 'bogo' ? 'bg-emerald-50' : 'bg-blue-50'
                      }`}>
                        {voucher.discount_type === 'bogo'
                          ? <Gift className={`h-5 w-5 ${statusBad ? 'text-slate-400' : 'text-emerald-600'}`} />
                          : <TicketPercent className={`h-5 w-5 ${statusBad ? 'text-slate-400' : 'text-blue-600'}`} />}
                      </div>
                      <div>
                        <p className="text-sm font-bold text-slate-800">{voucher.name}</p>
                        <p className="text-xs text-slate-400">{voucher.description}</p>
                      </div>
                    </div>
                    <div className="flex gap-1">
                      <button
                        onClick={() => openEdit(voucher)}
                        className="rounded-lg p-1.5 text-slate-400 transition hover:bg-blue-50 hover:text-blue-600"
                      >
                        <Pencil className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => setConfirmDelete(voucher)}
                        className="rounded-lg p-1.5 text-slate-400 transition hover:bg-red-50 hover:text-red-500"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>

                  <div className="mb-3 rounded-lg bg-slate-50 p-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-xs text-slate-400">Kode Voucher</p>
                        <p className="text-lg font-bold tracking-wider text-blue-600">{voucher.code}</p>
                      </div>
                      <button
                        onClick={() => navigator.clipboard?.writeText(voucher.code)}
                        className="rounded-lg p-2 text-slate-400 transition hover:bg-slate-200 hover:text-slate-600"
                        title="Salin kode"
                      >
                        <Copy className="h-4 w-4" />
                      </button>
                    </div>
                  </div>

                  <div className="space-y-1.5 text-xs">
                    <div className="flex justify-between">
                      <span className="text-slate-400">Diskon</span>
                      <span className="font-semibold text-slate-700">
                        {voucher.discount_type === 'bogo'
                          ? 'Beli 1 Gratis 1'
                          : voucher.discount_type === 'percentage'
                            ? `${voucher.discount_value}%`
                            : formatCurrency(voucher.discount_value, symbol)}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Min. Belanja</span>
                      <span className="font-medium text-slate-600">
                        {voucher.min_purchase > 0 ? formatCurrency(voucher.min_purchase, symbol) : '—'}
                      </span>
                    </div>
                    {voucher.max_discount && (
                      <div className="flex justify-between">
                        <span className="text-slate-400">Maks. Diskon</span>
                        <span className="font-medium text-slate-600">
                          {formatCurrency(voucher.max_discount, symbol)}
                        </span>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <span className="text-slate-400">Terpakai</span>
                      <span className="font-medium text-slate-600">
                        {voucher.used_count}{voucher.usage_limit ? ` / ${voucher.usage_limit}` : ''}
                      </span>
                    </div>
                  </div>

                  <div className="mt-3 flex items-center justify-between border-t border-slate-100 pt-3">
                    {expired ? (
                      <span className="rounded-full bg-red-100 px-2.5 py-0.5 text-xs font-medium text-red-700">Kedaluwarsa</span>
                    ) : exhausted ? (
                      <span className="rounded-full bg-amber-100 px-2.5 py-0.5 text-xs font-medium text-amber-700">Habis</span>
                    ) : inactive ? (
                      <span className="rounded-full bg-slate-100 px-2.5 py-0.5 text-xs font-medium text-slate-500">Nonaktif</span>
                    ) : (
                      <span className="rounded-full bg-emerald-100 px-2.5 py-0.5 text-xs font-medium text-emerald-700">Aktif</span>
                    )}
                    <button
                      onClick={() => toggleActive(voucher)}
                      className="text-xs font-medium text-blue-600 transition hover:text-blue-700"
                    >
                      {voucher.is_active ? 'Nonaktifkan' : 'Aktifkan'}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {showModal && (
        <VoucherModal
          voucher={editing}
          onClose={() => setShowModal(false)}
          onSaved={async () => {
            setShowModal(false);
            await refreshVouchers();
          }}
        />
      )}

      {confirmDelete && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-slate-900/50 backdrop-blur-sm sm:items-center sm:p-4">
          <div className="w-full max-w-sm rounded-t-2xl bg-white p-5 shadow-2xl sm:rounded-2xl sm:p-6">
            <div className="mb-4 flex items-center gap-3">
              <div className="rounded-lg bg-red-50 p-2">
                <AlertCircle className="h-5 w-5 text-red-500" />
              </div>
              <h3 className="text-base font-bold text-slate-800">Hapus Voucher</h3>
            </div>
            <p className="mb-5 text-sm text-slate-600">
              Hapus voucher "{confirmDelete.name}" ({confirmDelete.code})? Tindakan ini tidak bisa dibatalkan.
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setConfirmDelete(null)}
                className="flex-1 rounded-xl border border-slate-200 py-2.5 text-sm font-semibold text-slate-600 transition hover:bg-slate-50"
              >
                Batal
              </button>
              <button
                onClick={handleDelete}
                className="flex-1 rounded-xl bg-red-500 py-2.5 text-sm font-bold text-white transition hover:bg-red-600"
              >
                Hapus
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

interface VoucherModalProps {
  voucher: Voucher | null;
  onClose: () => void;
  onSaved: () => void;
}

function VoucherModal({ voucher, onClose, onSaved }: VoucherModalProps) {
  const [code, setCode] = useState(voucher?.code || '');
  const [name, setName] = useState(voucher?.name || '');
  const [description, setDescription] = useState(voucher?.description || '');
  const [discountType, setDiscountType] = useState<'percentage' | 'fixed' | 'bogo'>(voucher?.discount_type || 'percentage');
  const [discountValue, setDiscountValue] = useState(voucher?.discount_value?.toString() || '');
  const [minPurchase, setMinPurchase] = useState(voucher?.min_purchase?.toString() || '0');
  const [maxDiscount, setMaxDiscount] = useState(voucher?.max_discount?.toString() || '');
  const [usageLimit, setUsageLimit] = useState(voucher?.usage_limit?.toString() || '');
  const [validUntil, setValidUntil] = useState(
    voucher?.valid_until ? new Date(voucher.valid_until).toISOString().slice(0, 10) : ''
  );
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const handleSave = async () => {
    setSaving(true);
    setError('');

    if (!code.trim()) {
      setError('Kode voucher wajib diisi');
      setSaving(false);
      return;
    }
    if (!name.trim()) {
      setError('Nama voucher wajib diisi');
      setSaving(false);
      return;
    }

    const dv = parseFloat(discountValue) || 0;
    if (discountType !== 'bogo' && dv <= 0) {
      setError('Nilai diskon harus lebih dari 0');
      setSaving(false);
      return;
    }
    if (discountType === 'percentage' && dv > 100) {
      setError('Persentase diskon maksimal 100%');
      setSaving(false);
      return;
    }

    const data = {
      code: code.trim().toUpperCase(),
      name: name.trim(),
      description: description.trim(),
      discount_type: discountType,
      discount_value: discountType === 'bogo' ? 0 : dv,
      min_purchase: parseFloat(minPurchase) || 0,
      max_discount: discountType === 'bogo' ? null : (maxDiscount ? parseFloat(maxDiscount) : null),
      usage_limit: usageLimit ? parseInt(usageLimit) : null,
      valid_until: validUntil ? new Date(validUntil).toISOString() : null,
    };

    try {
      if (voucher) await api.patch(`/vouchers/${voucher.id}`, data);
      else await api.post('/vouchers', data);
    } catch (e) {
      setError(errorMessage(e));
      setSaving(false);
      return;
    }

    setSaving(false);
    onSaved();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-slate-900/50 backdrop-blur-sm sm:items-center sm:p-4">
      <div className="w-full max-w-lg rounded-t-2xl bg-white shadow-2xl sm:rounded-2xl">
        <div className="flex items-center justify-between border-b border-slate-200 px-5 py-4 sm:px-6">
          <h2 className="text-lg font-bold text-slate-800">
            {voucher ? 'Edit Voucher' : 'Tambah Voucher'}
          </h2>
          <button
            onClick={onClose}
            disabled={saving}
            className="rounded-lg p-1 text-slate-400 transition hover:bg-slate-100 hover:text-slate-600 disabled:opacity-40"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="max-h-[65vh] overflow-y-auto px-5 py-5 sm:px-6">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
                Kode Voucher
              </label>
              <input
                type="text"
                value={code}
                onChange={(e) => setCode(e.target.value.toUpperCase())}
                className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm font-bold uppercase tracking-wider outline-none focus:border-blue-500 focus:bg-white"
                placeholder="HEMAT10"
              />
            </div>

            <div>
              <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
                Nama Voucher
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm outline-none focus:border-blue-500 focus:bg-white"
                placeholder="Diskon Hemat"
              />
            </div>

            <div className="col-span-2">
              <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
                Deskripsi
              </label>
              <input
                type="text"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm outline-none focus:border-blue-500 focus:bg-white"
                placeholder="Diskon 10% untuk minimal belanja Rp 50.000"
              />
            </div>

            <div>
              <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
                Tipe Diskon
              </label>
              <div className="flex gap-2">
                <button
                  onClick={() => setDiscountType('percentage')}
                  className={`flex-1 rounded-lg border-2 py-2 text-xs font-medium transition ${
                    discountType === 'percentage'
                      ? 'border-blue-500 bg-blue-50 text-blue-700'
                      : 'border-slate-200 text-slate-500'
                  }`}
                >
                  Persentase
                </button>
                <button
                  onClick={() => setDiscountType('fixed')}
                  className={`flex-1 rounded-lg border-2 py-2 text-xs font-medium transition ${
                    discountType === 'fixed'
                      ? 'border-blue-500 bg-blue-50 text-blue-700'
                      : 'border-slate-200 text-slate-500'
                  }`}
                >
                  Tetap
                </button>
                <button
                  onClick={() => setDiscountType('bogo')}
                  className={`flex-1 rounded-lg border-2 py-2 text-xs font-medium transition ${
                    discountType === 'bogo'
                      ? 'border-emerald-500 bg-emerald-50 text-emerald-700'
                      : 'border-slate-200 text-slate-500'
                  }`}
                >
                  Beli 1 Gratis 1
                </button>
              </div>
            </div>

            {discountType !== 'bogo' && (
            <div>
              <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
                Nilai Diskon {discountType === 'percentage' ? '(%)' : '(Rp)'}
              </label>
              <input
                type="number"
                step="0.01"
                value={discountValue}
                onChange={(e) => setDiscountValue(e.target.value)}
                className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm outline-none focus:border-blue-500 focus:bg-white"
                placeholder={discountType === 'percentage' ? '10' : '50000'}
              />
            </div>
            )}

            {discountType === 'bogo' && (
            <div className="col-span-2 rounded-lg bg-emerald-50 p-3 text-sm text-emerald-700">
              <p className="font-semibold">Cara kerja Beli 1 Gratis 1:</p>
              <p className="mt-1 text-xs">Pelanggan membeli 2 item atau lebih, item termurah akan gratis. Berlaku jika subtotal mencapai minimum belanja.</p>
            </div>
            )}

            <div>
              <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
                Min. Belanja (Rp)
              </label>
              <input
                type="number"
                value={minPurchase}
                onChange={(e) => setMinPurchase(e.target.value)}
                className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm outline-none focus:border-blue-500 focus:bg-white"
                placeholder="0"
              />
            </div>

            {discountType !== 'bogo' && (
            <div>
              <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
                Maks. Diskon (Rp) — opsional
              </label>
              <input
                type="number"
                value={maxDiscount}
                onChange={(e) => setMaxDiscount(e.target.value)}
                className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm outline-none focus:border-blue-500 focus:bg-white"
                placeholder="Tanpa batas"
              />
            </div>
            )}

            <div>
              <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
                Batas Penggunaan — opsional
              </label>
              <input
                type="number"
                value={usageLimit}
                onChange={(e) => setUsageLimit(e.target.value)}
                className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm outline-none focus:border-blue-500 focus:bg-white"
                placeholder="Tanpa batas"
              />
            </div>

            <div className="col-span-2">
              <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
                Berlaku Sampai — opsional
              </label>
              <input
                type="date"
                value={validUntil}
                onChange={(e) => setValidUntil(e.target.value)}
                className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm outline-none focus:border-blue-500 focus:bg-white"
              />
            </div>
          </div>

          {error && (
            <div className="mt-4 flex items-center gap-2 rounded-lg bg-red-50 px-4 py-2.5 text-sm text-red-600">
              <AlertCircle className="h-4 w-4 flex-shrink-0" />
              {error}
            </div>
          )}
        </div>

        <div className="flex gap-3 border-t border-slate-200 px-5 py-4 sm:px-6">
          <button
            onClick={onClose}
            disabled={saving}
            className="flex-1 rounded-xl border border-slate-200 py-2.5 text-sm font-semibold text-slate-600 transition hover:bg-slate-50 disabled:opacity-40"
          >
            Batal
          </button>
          <button
            onClick={handleSave}
            disabled={saving}
            className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-blue-600 py-2.5 text-sm font-bold text-white transition hover:bg-blue-700 disabled:opacity-40"
          >
            {saving ? (
              <div className="h-4 w-4 animate-spin rounded-full border-2 border-white/30 border-t-white" />
            ) : voucher ? (
              'Simpan Perubahan'
            ) : (
              'Tambah Voucher'
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
