import { useState, useEffect } from 'react';
import { TrendingUp, ArrowLeft, Calendar, Banknote, CreditCard, QrCode, Building, Download } from 'lucide-react';
import { api } from '@/lib/api';
import { useStore } from '@/context/StoreContext';
import { formatCurrency, formatDateTime, formatDate } from '@/lib/format';
import type { Order } from '@/types';

type Period = 'today' | '7d' | '30d' | 'all';

const paymentIcons: Record<string, typeof Banknote> = {
  cash: Banknote, card: CreditCard, qris: QrCode, transfer: Building,
};

const paymentLabels: Record<string, string> = {
  cash: 'Tunai', card: 'Kartu', qris: 'QRIS', transfer: 'Transfer',
};

interface RevenueDetailProps {
  onBack: () => void;
}

export function RevenueDetail({ onBack }: RevenueDetailProps) {
  const { settings } = useStore();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [period, setPeriod] = useState<Period>('30d');

  const symbol = settings?.currency_symbol || 'Rp';

  useEffect(() => {
    (async () => {
      setLoading(true);
      let from: string | undefined;
      if (period !== 'all') {
        const days = period === 'today' ? 0 : period === '7d' ? 7 : 30;
        const start = new Date();
        start.setDate(start.getDate() - days);
        start.setHours(0, 0, 0, 0);
        from = start.toISOString();
      }
      try {
        setOrders(await api.get<Order[]>('/orders', { from, limit: 500 }));
      } catch (e) {
        console.error(e);
      }
      setLoading(false);
    })();
  }, [period]);

  const validOrders = orders.filter((o) => o.correction_type === 'none' || !o.correction_type);
  const totalRevenue = validOrders.reduce((s, o) => s + Number(o.total), 0);
  const totalSubtotal = validOrders.reduce((s, o) => s + Number(o.subtotal), 0);
  const totalTax = validOrders.reduce((s, o) => s + Number(o.tax_amount), 0);
  const totalDiscount = validOrders.reduce((s, o) => s + Number(o.discount_amount || 0), 0);
  const avgOrder = validOrders.length > 0 ? totalRevenue / validOrders.length : 0;

  const paymentBreakdown: Record<string, { count: number; revenue: number }> = {};
  for (const o of validOrders) {
    const key = o.payment_method;
    if (!paymentBreakdown[key]) paymentBreakdown[key] = { count: 0, revenue: 0 };
    paymentBreakdown[key].count += 1;
    paymentBreakdown[key].revenue += Number(o.total);
  }

  const dailyMap: Record<string, { revenue: number; count: number }> = {};
  for (const o of validOrders) {
    const day = new Date(o.created_at).toLocaleDateString('id-ID', { day: '2-digit', month: 'short' });
    if (!dailyMap[day]) dailyMap[day] = { revenue: 0, count: 0 };
    dailyMap[day].revenue += Number(o.total);
    dailyMap[day].count += 1;
  }
  const dailyData = Object.entries(dailyMap).slice(0, 14).reverse();
  const maxDailyRevenue = Math.max(...dailyData.map((d) => d[1].revenue), 1);

  const periodLabels: { id: Period; label: string }[] = [
    { id: 'today', label: 'Hari Ini' },
    { id: '7d', label: '7 Hari' },
    { id: '30d', label: '30 Hari' },
    { id: 'all', label: 'Semua' },
  ];

  if (loading) {
    return (
      <div className="flex flex-1 items-center justify-center text-slate-400">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-blue-500/30 border-t-blue-500" />
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto bg-slate-50 p-4 sm:p-6">
      {/* Header */}
      <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="flex items-center justify-center rounded-lg p-1.5 text-slate-400 transition hover:bg-slate-100 hover:text-slate-600"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-blue-50">
            <TrendingUp className="h-5 w-5 text-blue-600" />
          </div>
          <h2 className="text-xl font-bold text-slate-800">Detail Pendapatan</h2>
        </div>
        <div className="flex gap-1.5 rounded-xl bg-white p-1 shadow-sm ring-1 ring-slate-200">
          {periodLabels.map((r) => (
            <button
              key={r.id}
              onClick={() => setPeriod(r.id)}
              className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition ${
                period === r.id ? 'bg-blue-600 text-white shadow-md shadow-blue-600/20' : 'text-slate-500 hover:bg-slate-100'
              }`}
            >
              {r.label}
            </button>
          ))}
        </div>
      </div>

      {/* Summary cards */}
      <div className="mb-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
          <div className="mb-2 flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Total Pendapatan</span>
            <div className="rounded-lg bg-blue-50 p-1.5">
              <TrendingUp className="h-4 w-4 text-blue-600" />
            </div>
          </div>
          <p className="text-xl font-bold text-slate-800">{formatCurrency(totalRevenue, symbol)}</p>
          <p className="mt-1 text-xs text-slate-400">{validOrders.length} pesanan valid</p>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
          <div className="mb-2 flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Rata-rata Pesanan</span>
            <div className="rounded-lg bg-amber-50 p-1.5">
              <Calendar className="h-4 w-4 text-amber-600" />
            </div>
          </div>
          <p className="text-xl font-bold text-slate-800">{formatCurrency(avgOrder, symbol)}</p>
          <p className="mt-1 text-xs text-slate-400">Per transaksi</p>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
          <div className="mb-2 flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Total Pajak</span>
            <div className="rounded-lg bg-cyan-50 p-1.5">
              <Building className="h-4 w-4 text-cyan-600" />
            </div>
          </div>
          <p className="text-xl font-bold text-slate-800">{formatCurrency(totalTax, symbol)}</p>
          <p className="mt-1 text-xs text-slate-400">Dari penjualan</p>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
          <div className="mb-2 flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Total Diskon</span>
            <div className="rounded-lg bg-emerald-50 p-1.5">
              <TrendingUp className="h-4 w-4 text-emerald-600" />
            </div>
          </div>
          <p className="text-xl font-bold text-emerald-600">{formatCurrency(totalDiscount, symbol)}</p>
          <p className="mt-1 text-xs text-slate-400">Diberikan ke pelanggan</p>
        </div>
      </div>

      {/* Daily revenue chart */}
      {dailyData.length > 0 && (
        <div className="mb-5 rounded-xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
          <h3 className="mb-4 text-sm font-bold text-slate-800">Pendapatan Harian</h3>
          <div className="flex items-end justify-between gap-1.5" style={{ height: '180px' }}>
            {dailyData.map(([day, info], i) => (
              <div key={i} className="flex flex-1 flex-col items-center gap-1.5">
                <div className="flex w-full flex-1 items-end">
                  <div
                    className="w-full rounded-t bg-blue-500 transition-all hover:bg-blue-600"
                    style={{ height: `${(info.revenue / maxDailyRevenue) * 100}%`, minHeight: info.revenue > 0 ? '4px' : '0px' }}
                    title={`${formatCurrency(info.revenue, symbol)} · ${info.count} pesanan`}
                  />
                </div>
                <span className="text-[10px] text-slate-400">{day}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Payment method breakdown */}
      <div className="mb-5 rounded-xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
        <h3 className="mb-4 text-sm font-bold text-slate-800">Pendapatan per Metode Pembayaran</h3>
        {Object.keys(paymentBreakdown).length === 0 ? (
          <div className="flex h-20 items-center justify-center text-sm text-slate-400">Belum ada data</div>
        ) : (
          <div className="space-y-3">
            {Object.entries(paymentBreakdown).sort((a, b) => b[1].revenue - a[1].revenue).map(([method, data]) => {
              const Icon = paymentIcons[method] || Banknote;
              const pct = totalRevenue > 0 ? (data.revenue / totalRevenue) * 100 : 0;
              return (
                <div key={method}>
                  <div className="mb-1.5 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-blue-50">
                        <Icon className="h-4 w-4 text-blue-600" />
                      </div>
                      <span className="text-sm font-medium text-slate-700">{paymentLabels[method] || method}</span>
                      <span className="rounded-full bg-slate-100 px-2 py-0.5 text-xs text-slate-500">{data.count} pesanan</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-slate-400">{pct.toFixed(0)}%</span>
                      <span className="text-sm font-semibold text-slate-800">{formatCurrency(data.revenue, symbol)}</span>
                    </div>
                  </div>
                  <div className="h-2.5 overflow-hidden rounded-full bg-slate-100">
                    <div className="h-full rounded-full bg-blue-500 transition-all duration-500" style={{ width: `${pct}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Revenue breakdown: subtotal, tax, discount */}
      <div className="mb-5 rounded-xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
        <h3 className="mb-4 text-sm font-bold text-slate-800">Rincian Pendapatan</h3>
        <div className="space-y-2.5 text-sm">
          <div className="flex justify-between border-b border-slate-100 pb-2.5">
            <span className="text-slate-500">Subtotal Penjualan</span>
            <span className="font-semibold text-slate-800">{formatCurrency(totalSubtotal, symbol)}</span>
          </div>
          <div className="flex justify-between border-b border-slate-100 pb-2.5">
            <span className="text-slate-500">Pajak Diterima</span>
            <span className="font-semibold text-slate-800">+{formatCurrency(totalTax, symbol)}</span>
          </div>
          <div className="flex justify-between border-b border-slate-100 pb-2.5">
            <span className="text-slate-500">Diskon Diberikan</span>
            <span className="font-semibold text-emerald-600">-{formatCurrency(totalDiscount, symbol)}</span>
          </div>
          <div className="flex justify-between pt-1 text-base font-bold">
            <span className="text-slate-800">Total Pendapatan</span>
            <span className="text-blue-600">{formatCurrency(totalRevenue, symbol)}</span>
          </div>
        </div>
      </div>

      {/* Transaction list */}
      <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
        <h3 className="mb-4 text-sm font-bold text-slate-800">Riwayat Transaksi Pendapatan</h3>
        {validOrders.length === 0 ? (
          <div className="flex h-20 items-center justify-center text-sm text-slate-400">Belum ada transaksi</div>
        ) : (
          <>
            {/* Mobile cards */}
            <div className="space-y-2 lg:hidden">
              {validOrders.slice(0, 50).map((order) => {
                const PayIcon = paymentIcons[order.payment_method] || Banknote;
                return (
                  <div key={order.id} className="flex items-center justify-between rounded-lg border border-slate-100 px-3 py-2.5">
                    <div className="flex items-center gap-2.5">
                      <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-blue-50">
                        <PayIcon className="h-4 w-4 text-blue-600" />
                      </div>
                      <div>
                        <p className="text-sm font-semibold text-slate-800">#{order.order_number}</p>
                        <p className="text-xs text-slate-500">{formatDate(order.created_at)} · {order.item_count} item</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-bold text-blue-600">{formatCurrency(order.total, symbol)}</p>
                      {Number(order.discount_amount) > 0 && (
                        <p className="text-xs text-emerald-600">-{formatCurrency(Number(order.discount_amount), symbol)}</p>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Desktop table */}
            <div className="hidden overflow-x-auto lg:block">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-slate-100 text-left text-xs text-slate-500">
                    <th className="pb-2 font-medium">Pesanan</th>
                    <th className="pb-2 font-medium">Tanggal</th>
                    <th className="pb-2 font-medium">Item</th>
                    <th className="pb-2 font-medium">Bayar</th>
                    <th className="pb-2 text-right font-medium">Subtotal</th>
                    <th className="pb-2 text-right font-medium">Diskon</th>
                    <th className="pb-2 text-right font-medium">Pajak</th>
                    <th className="pb-2 text-right font-medium">Total</th>
                  </tr>
                </thead>
                <tbody>
                  {validOrders.slice(0, 50).map((order) => (
                    <tr key={order.id} className="border-b border-slate-50 last:border-0">
                      <td className="py-2.5 font-semibold text-slate-800">#{order.order_number}</td>
                      <td className="py-2.5 text-slate-500">{formatDate(order.created_at)}</td>
                      <td className="py-2.5 text-slate-500">{order.item_count}</td>
                      <td className="py-2.5">
                        <span className="rounded bg-slate-100 px-2 py-0.5 text-xs capitalize text-slate-600">{order.payment_method}</span>
                      </td>
                      <td className="py-2.5 text-right text-slate-600">{formatCurrency(order.subtotal, symbol)}</td>
                      <td className="py-2.5 text-right text-emerald-600">{Number(order.discount_amount) > 0 ? `-${formatCurrency(Number(order.discount_amount), symbol)}` : '—'}</td>
                      <td className="py-2.5 text-right text-slate-500">{formatCurrency(order.tax_amount, symbol)}</td>
                      <td className="py-2.5 text-right font-bold text-blue-600">{formatCurrency(order.total, symbol)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
