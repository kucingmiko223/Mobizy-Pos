import { useState, useEffect } from 'react';
import {
  Receipt, ChevronRight, ChevronLeft, Search, X, RotateCcw, Ban,
  AlertCircle, TicketPercent, Clock, FileText, TrendingUp, Calendar,
  Banknote, CreditCard, QrCode, Building,
} from 'lucide-react';
import { api, errorMessage } from '@/lib/api';
import { useStore } from '@/context/StoreContext';
import { useAuth } from '@/context/AuthContext';
import { formatCurrency, formatDateTime, formatDate } from '@/lib/format';
import type { Order, OrderItem, CorrectionType } from '@/types';

const paymentIcons: Record<string, typeof Banknote> = {
  cash: Banknote, card: CreditCard, qris: QrCode, transfer: Building,
};

type FilterTab = 'all' | 'today' | 'completed' | 'voided';

export function OrderHistory() {
  const { settings, refreshProducts } = useStore();
  const [orders, setOrders] = useState<Order[]>([]);
  const [search, setSearch] = useState('');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [orderItems, setOrderItems] = useState<OrderItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterTab, setFilterTab] = useState<FilterTab>('all');
  const [showCorrection, setShowCorrection] = useState(false);
  const [correctionType, setCorrectionType] = useState<CorrectionType>('void');
  const [correctionReason, setCorrectionReason] = useState('');
  const [processing, setProcessing] = useState(false);
  const [correctionError, setCorrectionError] = useState('');
  const { role } = useAuth();
  const canVoidRefund = role === 'owner' || role === 'admin'; // enforced again on the server

  const symbol = settings?.currency_symbol || 'Rp';

  const fetchOrders = async () => {
    try {
      setOrders(await api.get<Order[]>('/orders', { limit: 200 }));
    } catch (e) {
      console.error(e);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchOrders();
  }, []);

  const openOrder = async (order: Order) => {
    setSelectedOrder(order);
    try {
      const data = await api.get<{ order: Order; items: OrderItem[] }>(`/orders/${order.id}`);
      setOrderItems(data.items);
    } catch (e) {
      console.error(e);
    }
  };

  const handleCorrection = async () => {
    if (!selectedOrder || processing) return;
    if (!correctionReason.trim()) return;
    setProcessing(true);
    setCorrectionError('');

    try {
      // The server marks the order, restocks items (once) and rejects repeats.
      const updatedOrder = await api.post<Order>(`/orders/${selectedOrder.id}/correct`, {
        type: correctionType,
        reason: correctionReason.trim(),
      });
      if (correctionType === 'void' || correctionType === 'refund') await refreshProducts();
      setShowCorrection(false);
      setCorrectionReason('');
      setSelectedOrder(updatedOrder);
      await fetchOrders();
    } catch (err) {
      setCorrectionError(errorMessage(err, 'Koreksi gagal'));
    } finally {
      setProcessing(false);
    }
  };

  const now = new Date();
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());

  const filtered = orders.filter((o) => {
    const matchesSearch =
      o.order_number.toString().includes(search) ||
      o.payment_method.toLowerCase().includes(search.toLowerCase()) ||
      (o.customer_name || '').toLowerCase().includes(search.toLowerCase());

    if (!matchesSearch) return false;

    if (filterTab === 'today') return new Date(o.created_at) >= todayStart;
    if (filterTab === 'completed') return o.correction_type === 'none' || !o.correction_type;
    if (filterTab === 'voided') return o.correction_type === 'void';
    return true;
  });

  const validOrders = orders.filter((o) => o.correction_type === 'none' || !o.correction_type);
  const totalRevenue = validOrders.reduce((s, o) => s + Number(o.total), 0);
  const voidCount = orders.filter((o) => o.correction_type === 'void').length;
  const todayOrders = validOrders.filter((o) => new Date(o.created_at) >= todayStart);
  const todayRevenue = todayOrders.reduce((s, o) => s + Number(o.total), 0);

  const correctionBadge = (order: Order) => {
    if (order.correction_type === 'void') return { label: 'Dibatalkan', cls: 'bg-red-100 text-red-700' };
    if (order.correction_type === 'refund') return { label: 'Refund', cls: 'bg-amber-100 text-amber-700' };
    if (order.correction_type === 'adjust') return { label: 'Dikoreksi', cls: 'bg-blue-100 text-blue-700' };
    return null;
  };

  const filterTabs: { id: FilterTab; label: string }[] = [
    { id: 'all', label: 'Semua' },
    { id: 'today', label: 'Hari Ini' },
    { id: 'completed', label: 'Selesai' },
    { id: 'voided', label: 'Dibatalkan' },
  ];

  if (loading) {
    return (
      <div className="flex flex-1 items-center justify-center text-slate-400">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-blue-500/30 border-t-blue-500" />
      </div>
    );
  }

  return (
    <div className="flex flex-1 overflow-hidden">
      {/* Order list */}
      <div className={`flex w-full flex-col border-r border-slate-200 lg:w-1/2 ${selectedOrder ? 'hidden lg:flex' : ''}`}>
        <div className="border-b border-slate-200 bg-white px-4 py-4 sm:px-5">
          <div className="mb-4 flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-blue-50">
              <Receipt className="h-5 w-5 text-blue-600" />
            </div>
            <h2 className="text-xl font-bold text-slate-800">Riwayat Pesanan</h2>
          </div>

          {/* Summary stats - clean row */}
          <div className="mb-4 grid grid-cols-3 gap-2">
            <div className="rounded-xl border border-slate-200 bg-white px-3 py-2.5">
              <p className="text-xs text-slate-500">Penjualan Hari Ini</p>
              <p className="mt-0.5 text-base font-bold text-blue-600">{formatCurrency(todayRevenue, symbol)}</p>
              <p className="text-xs text-slate-400">{todayOrders.length} pesanan</p>
            </div>
            <div className="rounded-xl border border-slate-200 bg-white px-3 py-2.5">
              <p className="text-xs text-slate-500">Total Penjualan</p>
              <p className="mt-0.5 text-base font-bold text-slate-800">{formatCurrency(totalRevenue, symbol)}</p>
              <p className="text-xs text-slate-400">{validOrders.length} pesanan</p>
            </div>
            <div className="rounded-xl border border-slate-200 bg-white px-3 py-2.5">
              <p className="text-xs text-slate-500">Dibatalkan</p>
              <p className="mt-0.5 text-base font-bold text-rose-600">{voidCount}</p>
              <p className="text-xs text-slate-400">pesanan</p>
            </div>
          </div>

          {/* Filter tabs */}
          <div className="mb-3 flex gap-1.5">
            {filterTabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setFilterTab(tab.id)}
                className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition ${
                  filterTab === tab.id ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-500 hover:bg-slate-200'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Cari nomor pesanan, pelanggan, metode bayar..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full rounded-lg border border-slate-200 bg-slate-50 py-2 pl-9 pr-3 text-sm outline-none focus:border-blue-500 focus:bg-white"
            />
          </div>
        </div>

        {/* Order list items */}
        <div className="flex-1 overflow-y-auto bg-slate-50">
          {filtered.length === 0 ? (
            <div className="flex h-full flex-col items-center justify-center text-slate-400">
              <Receipt className="mb-2 h-10 w-10" />
              <p className="text-sm">Belum ada pesanan</p>
            </div>
          ) : (
            <div className="space-y-2 p-3">
              {filtered.map((order) => {
                const badge = correctionBadge(order);
                const PayIcon = paymentIcons[order.payment_method] || Receipt;
                const isSelected = selectedOrder?.id === order.id;
                return (
                  <button
                    key={order.id}
                    onClick={() => openOrder(order)}
                    className={`w-full rounded-xl border bg-white p-3.5 text-left transition ${
                      isSelected
                        ? 'border-blue-400 ring-1 ring-blue-200'
                        : 'border-slate-200 hover:border-slate-300 hover:shadow-sm'
                    } ${order.correction_type === 'void' ? 'opacity-60' : ''}`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <p className="text-sm font-bold text-slate-800">#{order.order_number}</p>
                          {badge && (
                            <span className={`rounded px-1.5 py-0.5 text-xs font-medium ${badge.cls}`}>
                              {badge.label}
                            </span>
                          )}
                        </div>
                        <p className="mt-0.5 text-xs text-slate-500">{formatDateTime(order.created_at)}</p>
                        {order.customer_name && (
                          <p className="mt-0.5 text-xs text-slate-400">Pelanggan: {order.customer_name}</p>
                        )}
                      </div>
                      <div className="flex-shrink-0 text-right">
                        <p className="text-sm font-bold text-blue-600">{formatCurrency(order.total, symbol)}</p>
                      </div>
                    </div>

                    <div className="mt-2 flex items-center gap-2 text-xs text-slate-500">
                      <span className="flex items-center gap-1 rounded-lg bg-slate-100 px-2 py-1">
                        <PayIcon className="h-3 w-3" />
                        <span className="capitalize">{order.payment_method}</span>
                      </span>
                      <span className="rounded-lg bg-slate-100 px-2 py-1">{order.item_count} item</span>
                      {order.scheduled_time && (
                        <span className="flex items-center gap-0.5 rounded-lg bg-blue-100 px-2 py-1 text-blue-700">
                          <Clock className="h-3 w-3" /> Dijadwalkan
                        </span>
                      )}
                      {Number(order.discount_amount) > 0 && (
                        <span className="flex items-center gap-0.5 rounded-lg bg-emerald-100 px-2 py-1 text-emerald-700">
                          <TicketPercent className="h-3 w-3" /> Diskon
                        </span>
                      )}
                      {order.notes && (
                        <span className="flex items-center gap-0.5 rounded-lg bg-amber-100 px-2 py-1 text-amber-700">
                          <FileText className="h-3 w-3" /> Catatan
                        </span>
                      )}
                      <ChevronRight className="ml-auto h-4 w-4 text-slate-300" />
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Order detail */}
      <div className={`flex flex-1 flex-col bg-slate-50 ${selectedOrder ? 'flex' : 'hidden lg:flex'}`}>
        {selectedOrder ? (
          <>
            <div className="border-b border-slate-200 bg-white px-4 py-4 sm:px-6">
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-3">
                  <button
                    onClick={() => setSelectedOrder(null)}
                    className="mt-0.5 flex items-center justify-center rounded-lg p-1 text-slate-400 transition hover:bg-slate-100 hover:text-slate-600 lg:hidden"
                  >
                    <ChevronLeft className="h-5 w-5" />
                  </button>
                  <div>
                    <h3 className="text-lg font-bold text-slate-800">Pesanan #{selectedOrder.order_number}</h3>
                    <p className="mt-0.5 flex items-center gap-1.5 text-sm text-slate-500">
                      <Calendar className="h-3.5 w-3.5" />
                      {formatDateTime(selectedOrder.created_at)}
                    </p>
                    {selectedOrder.customer_name && (
                      <p className="mt-1 text-sm text-slate-600">Pelanggan: {selectedOrder.customer_name}</p>
                    )}
                    {selectedOrder.scheduled_time && (
                      <p className="mt-1 flex items-center gap-1 text-sm text-blue-600">
                        <Clock className="h-3.5 w-3.5" />
                        Dijadwalkan: {formatDateTime(selectedOrder.scheduled_time)}
                      </p>
                    )}
                    {selectedOrder.notes && (
                      <p className="mt-1 flex items-start gap-1 text-sm text-amber-700">
                        <FileText className="mt-0.5 h-3.5 w-3.5 flex-shrink-0" />
                        Catatan: {selectedOrder.notes}
                      </p>
                    )}
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-xl font-bold text-blue-600 sm:text-2xl">{formatCurrency(selectedOrder.total, symbol)}</p>
                  <div className="mt-1 flex items-center justify-end gap-1.5">
                    {(() => {
                      const PayIcon = paymentIcons[selectedOrder.payment_method] || Receipt;
                      return <PayIcon className="h-3.5 w-3.5 text-slate-400" />;
                    })()}
                    <p className="text-xs capitalize text-slate-500">{selectedOrder.payment_method}</p>
                  </div>
                </div>
              </div>

              {selectedOrder.correction_type && selectedOrder.correction_type !== 'none' && (
                <div className="mt-3 flex items-center gap-2 rounded-lg bg-amber-50 px-3 py-2">
                  <AlertCircle className="h-4 w-4 text-amber-600" />
                  <span className="text-sm font-medium text-amber-700">
                    Pesanan {correctionBadge(selectedOrder)?.label}: {selectedOrder.correction_reason}
                  </span>
                </div>
              )}
            </div>

            <div className="flex-1 overflow-y-auto p-4 sm:p-6">
              {/* Items card */}
              <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
                <h4 className="mb-3 text-sm font-bold text-slate-800">Detail Item</h4>
                {orderItems.map((item) => (
                  <div key={item.id} className="flex items-center justify-between border-b border-slate-100 py-2.5 last:border-0">
                    <div>
                      <p className="text-sm font-medium text-slate-800">{item.product_name}</p>
                      <p className="text-xs text-slate-500">{item.quantity} x {formatCurrency(item.unit_price, symbol)}</p>
                    </div>
                    <span className="text-sm font-semibold text-slate-700">{formatCurrency(item.subtotal, symbol)}</span>
                  </div>
                ))}

                <div className="mt-4 space-y-1.5 border-t border-slate-200 pt-3 text-sm">
                  <div className="flex justify-between text-slate-500">
                    <span>Subtotal</span>
                    <span>{formatCurrency(selectedOrder.subtotal, symbol)}</span>
                  </div>
                  {Number(selectedOrder.discount_amount) > 0 && (
                    <div className="flex justify-between text-emerald-600">
                      <span className="flex items-center gap-1">
                        <TicketPercent className="h-3.5 w-3.5" /> Diskon
                      </span>
                      <span>-{formatCurrency(Number(selectedOrder.discount_amount), symbol)}</span>
                    </div>
                  )}
                  <div className="flex justify-between text-slate-500">
                    <span>Pajak</span>
                    <span>{formatCurrency(selectedOrder.tax_amount, symbol)}</span>
                  </div>
                  <div className="flex justify-between border-t border-slate-200 pt-1.5 text-base font-bold">
                    <span className="text-slate-800">Total</span>
                    <span className="text-blue-600">{formatCurrency(selectedOrder.total, symbol)}</span>
                  </div>
                  <div className="flex justify-between text-slate-500">
                    <span>Dibayar</span>
                    <span>{formatCurrency(selectedOrder.amount_paid, symbol)}</span>
                  </div>
                  <div className="flex justify-between text-slate-500">
                    <span>Kembalian</span>
                    <span>{formatCurrency(selectedOrder.change_due, symbol)}</span>
                  </div>
                </div>
              </div>

              {/* Correction actions */}
              {(!selectedOrder.correction_type || selectedOrder.correction_type === 'none') && (
                <div className="mt-4 rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
                  <h4 className="mb-3 text-sm font-bold text-slate-800">Koreksi Tagihan</h4>
                  <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
                    {canVoidRefund && <button
                      onClick={() => { setCorrectionType('void'); setCorrectionError(''); setShowCorrection(true); }}
                      className="flex items-center gap-2 rounded-lg border border-red-200 bg-red-50 px-3 py-2.5 text-sm font-semibold text-red-600 transition hover:bg-red-100"
                    >
                      <Ban className="h-4 w-4" /> Batalkan
                    </button>}
                    {canVoidRefund && <button
                      onClick={() => { setCorrectionType('refund'); setCorrectionError(''); setShowCorrection(true); }}
                      className="flex items-center gap-2 rounded-lg border border-amber-200 bg-amber-50 px-3 py-2.5 text-sm font-semibold text-amber-600 transition hover:bg-amber-100"
                    >
                      <RotateCcw className="h-4 w-4" /> Refund
                    </button>}
                    <button
                      onClick={() => { setCorrectionType('adjust'); setCorrectionError(''); setShowCorrection(true); }}
                      className="flex items-center gap-2 rounded-lg border border-blue-200 bg-blue-50 px-3 py-2.5 text-sm font-semibold text-blue-600 transition hover:bg-blue-100"
                    >
                      <AlertCircle className="h-4 w-4" /> Koreksi
                    </button>
                  </div>
                </div>
              )}
            </div>
          </>
        ) : (
          <div className="flex h-full flex-col items-center justify-center text-slate-400">
            <Receipt className="mb-3 h-12 w-12" />
            <p className="text-sm font-medium">Pilih pesanan untuk melihat detail</p>
          </div>
        )}
      </div>

      {/* Correction modal */}
      {showCorrection && selectedOrder && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-slate-900/50 backdrop-blur-sm sm:items-center sm:p-4">
          <div className="w-full max-w-md rounded-t-2xl bg-white shadow-2xl sm:rounded-2xl">
            <div className="flex items-center justify-between border-b border-slate-200 px-5 py-4 sm:px-6">
              <h2 className="text-lg font-bold text-slate-800">
                {correctionType === 'void' ? 'Batalkan Pesanan' : correctionType === 'refund' ? 'Refund Pesanan' : 'Koreksi Pesanan'}
              </h2>
              <button
                onClick={() => setShowCorrection(false)}
                disabled={processing}
                className="rounded-lg p-1 text-slate-400 transition hover:bg-slate-100 hover:text-slate-600 disabled:opacity-40"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="px-5 py-5 sm:px-6">
              <div className="mb-4 rounded-lg bg-slate-50 p-3">
                <p className="text-sm text-slate-600">Pesanan #{selectedOrder.order_number} — {formatCurrency(selectedOrder.total, symbol)}</p>
                <p className="mt-1 text-xs text-slate-400">
                  {correctionType === 'void' && 'Pesanan akan dibatalkan dan stok produk dikembalikan.'}
                  {correctionType === 'refund' && 'Pesanan akan direfund dan stok produk dikembalikan.'}
                  {correctionType === 'adjust' && 'Menandai pesanan dengan catatan koreksi tanpa mengubah stok.'}
                </p>
              </div>

              <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-500">Alasan Koreksi</label>
              <textarea
                value={correctionReason}
                onChange={(e) => setCorrectionReason(e.target.value)}
                rows={3}
                placeholder="Jelaskan alasan koreksi..."
                className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:border-blue-500 focus:bg-white"
                autoFocus
              />
              {correctionError && <p role="alert" className="mt-2 rounded-lg bg-red-50 px-3 py-2 text-sm text-red-600">{correctionError}</p>}

              <div className="mt-5 flex gap-3">
                <button onClick={() => setShowCorrection(false)} disabled={processing} className="flex-1 rounded-xl border border-slate-200 py-2.5 text-sm font-semibold text-slate-600 transition hover:bg-slate-50 disabled:opacity-40">
                  Batal
                </button>
                <button
                  onClick={handleCorrection}
                  disabled={!correctionReason.trim() || processing}
                  className={`flex-1 rounded-xl py-2.5 text-sm font-bold text-white transition disabled:opacity-40 ${
                    correctionType === 'void' ? 'bg-red-500 hover:bg-red-600' :
                    correctionType === 'refund' ? 'bg-amber-500 hover:bg-amber-600' :
                    'bg-blue-600 hover:bg-blue-700'
                  }`}
                >
                  {processing ? (
                    <div className="mx-auto h-4 w-4 animate-spin rounded-full border-2 border-white/30 border-t-white" />
                  ) : correctionType === 'void' ? 'Batalkan' : correctionType === 'refund' ? 'Proses Refund' : 'Koreksi'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
