// Entity types live in @mobizy/shared so web and API can never disagree.
export * from '@mobizy/shared';
import type { Product } from '@mobizy/shared';

export interface CartItem {
  product: Product;
  quantity: number;
}

export type ViewType = 'cashier' | 'orders' | 'analytics' | 'vouchers' | 'accounting' | 'comments' | 'dashboard' | 'products' | 'settings' | 'team' | 'customer';

export type PaymentMethod = 'cash' | 'card' | 'qris' | 'transfer';

export type CorrectionType = 'none' | 'void' | 'refund' | 'adjust';

export type ExpenseCategory = 'rent' | 'utilities' | 'inventory' | 'salary' | 'marketing' | 'other';
