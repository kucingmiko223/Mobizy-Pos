# MobizyPOS

Multi-store point-of-sale for small shops. React + Vite web app, Hono + Drizzle API, plain Postgres.

```
apps/web         React UI, organised by feature (pos, orders, products, vouchers, ...)
apps/api         Hono API: sessions, roles, per-store data, transactional checkout (routes/ has one file per resource)
packages/shared  Types, request validation (zod) and the price/discount calculation used by both sides
deploy/          nginx config (serves the web app and proxies /api)
docs/            API reference, security notes
```

## Quick start (no Docker)

Needs Node 20+ and a Postgres database.

```bash
npm install                       # creates package-lock.json: commit it
cp apps/api/.env.example apps/api/.env   # set DATABASE_URL
npm run db:migrate                # creates the empty schema, no data
npm run dev                       # API on :8787, web on :5173 (Vite proxies /api)
```

Open http://localhost:5173 and create your store from the **Daftar Toko** tab. A fresh database contains no data at all.

### Optional: first store from the command line, or demo data

```bash
# real, empty store + owner (password printed once if OWNER_PASSWORD is not set)
STORE_NAME="Toko Saya" STORE_SLUG=toko-saya OWNER_NAME="Budi" OWNER_EMAIL=budi@example.com npm run db:create-store

# demo store with sample products, vouchers, owner and cashier logins (development only)
npm run db:seed

# wipe the database back to empty (development only; asks for RESET_CONFIRM=<database name>)
RESET_CONFIRM=mobizy npm run db:reset && npm run db:migrate
```

## Quick start (Docker)

```bash
cp .env.example .env              # set POSTGRES_PASSWORD
docker compose up --build         # web on http://localhost:8080
```

Create the first store from the **Daftar Toko** tab. The database starts empty.
Login cookies are `Secure` in production, so use HTTPS (or `localhost`) when deploying.

## Accounts and roles

| Role | Can do |
|---|---|
| owner | Everything for their store; exactly one per store, created at sign-up |
| admin | Products, vouchers, settings, expenses, reports, void/refund, cashier accounts |
| cashier | Ring up sales, view orders and dashboard, add notes to orders, read reviews |
| customer | Browse the menu and leave reviews (signs up with the store code) |

Every row belongs to a store (`store_id`) and every query filters on the signed-in user's store.

## Choosing a database host

Only `DATABASE_URL` changes: any managed Postgres, RDS, or your own server. Add `?sslmode=require` for hosted databases.

## Tests

```bash
npm test -w @mobizy/shared        # pricing rules, no database needed
npm test -w @mobizy/api           # integration tests, needs a migrated THROWAWAY database in DATABASE_URL
```

The API tests cover tenant isolation, server-side pricing, overselling under parallel checkouts, voucher limits under
parallel use, and double void.

## Not included (on purpose)

- Subscription billing: add a `plan`/`subscription_status` column on `stores` and a check in `requireAuth` (`apps/api/src/middleware/auth.ts`); webhook route goes beside `routes/auth.ts`.
- Email verification and password reset: needs an email provider. Add a `tokens` table and two routes in `routes/auth.ts`; `endSessions()` in `lib/session.ts` already signs a user out everywhere.
- Row-level security in Postgres as a second layer under the `store_id` filters.
- Rate limiting is in memory (one API instance). Use Redis if you run several.

See `docs/` for the API reference and security notes.
